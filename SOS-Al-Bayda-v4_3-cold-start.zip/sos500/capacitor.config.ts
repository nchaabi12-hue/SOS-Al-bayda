import type { CapacitorConfig } from '@capacitor/cli';

/**
 * SOS AL BAYDA — Capacitor config APK Android (v4.3-cold).
 *
 * Mode actuel : shell distant (`server.url`).
 *  - Mises à jour sans republier l'APK.
 *  - Cold-start hors ligne : après UNE ouverture avec réseau (Service Worker).
 *  - Téléphone neuf / données effacées : réseau obligatoire la 1ère fois.
 *
 * Mode embarqué (cold-start offline dès l'install) :
 *  1. Build statique client dans `www/`
 *  2. Retirer le bloc `server: { url: ... }`
 *  3. Pointer les appels API vers l'URL HTTPS absolue du backend
 * Voir GUIDE_ANDROID_SOS_AL_BAYDA.md § Cold-start.
 */
const appUrl = process.env.SOS_APP_URL?.trim();

if (!appUrl || !/^https:\/\//i.test(appUrl)) {
  throw new Error(
    'SOS_APP_URL doit être une URL HTTPS publique de SOS AL BAYDA (ex. https://sos.albayda.ma).',
  );
}

const config: CapacitorConfig = {
  appId: 'ma.sosalbayda.mobile',
  appName: 'SOS AL BAYDA',
  webDir: 'www',
  server: {
    url: appUrl,
    cleartext: false,
    androidScheme: 'https',
    // Évite de recharger inutilement quand l'app repasse au premier plan
    errorPath: undefined,
  },
  android: {
    allowMixedContent: false,
    backgroundColor: '#0f3d2e',
    // WebView plus tolérante aux coupures brèves au démarrage
    webContentsDebuggingEnabled: false,
  },
  plugins: {
    SplashScreen: {
      // Laisse le temps au SW / 1er paint sur réseau lent (terrain)
      launchShowDuration: 2200,
      launchAutoHide: true,
      backgroundColor: '#0f3d2e',
      showSpinner: false,
      androidScaleType: 'CENTER_CROP',
      splashFullScreen: true,
      splashImmersive: true,
    },
    Geolocation: {},
    PushNotifications: {
      presentationOptions: ['badge', 'sound', 'alert'],
    },
    LocalNotifications: {
      smallIcon: 'ic_stat_icon_config_sample',
      iconColor: '#1a7a4c',
    },
    Camera: {},
    Network: {},
    App: {},
  },
};

export default config;
