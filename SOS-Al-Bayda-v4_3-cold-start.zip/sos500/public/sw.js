/* SOS AL BAYDA — service worker v4.3-cold
 *
 * Objectif cold-start :
 *  - Après UNE ouverture avec réseau, l'app se rouvre hors ligne (même après kill).
 *  - Navigations : réseau d'abord (timeout court), sinon cache.
 *  - Assets (/assets/, brand, polices, CSS/JS) : cache d'abord.
 *  - API /_serverFn /api : JAMAIS en cache (passe par l'outbox app).
 */
const VERSION = "sos-albayda-v4.3-cold";
const ROUTES = ["/", "/points", "/tournee", "/constats", "/dispatch", "/economies", "/rapports"];
const NETWORK_TIMEOUT_MS = 3500;

const isDataRequest = (url) =>
  url.pathname.startsWith("/_serverFn") ||
  url.pathname.startsWith("/api/") ||
  url.pathname.startsWith("/_server");

const isStatic = (url) =>
  url.origin === self.location.origin
    ? url.pathname.startsWith("/assets/") ||
      url.pathname.startsWith("/brand/") ||
      url.pathname.startsWith("/__grok/") ||
      /\.(?:png|jpg|jpeg|svg|ico|webp|woff2?|css|js|map)$/.test(url.pathname)
    : url.hostname === "fonts.googleapis.com" || url.hostname === "fonts.gstatic.com";

const OFFLINE_HTML = `<!doctype html>
<html lang="fr"><head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"/>
<meta name="theme-color" content="#0f3d2e"/>
<title>SOS AL BAYDA — Hors ligne</title>
<style>
  :root{color-scheme:light}
  *{box-sizing:border-box}
  body{margin:0;min-height:100dvh;display:grid;place-items:center;font-family:system-ui,-apple-system,sans-serif;
    background:#0f3d2e;color:#e8f5ef;padding:1.5rem}
  main{max-width:22rem;text-align:center}
  .mark{width:64px;height:64px;margin:0 auto 1rem;border-radius:16px;background:#1a7a4c;
    display:grid;place-items:center;font-weight:800;font-size:1.25rem;letter-spacing:.06em}
  h1{font-size:1.25rem;margin:0 0 .5rem;letter-spacing:.12em}
  p{margin:.4rem 0;line-height:1.55;color:#b7d4c6;font-size:.95rem}
  button{margin-top:1.25rem;border:0;border-radius:12px;padding:.85rem 1.4rem;font-weight:700;
    background:#2ecc71;color:#0b2419;font-size:.95rem}
  small{display:block;margin-top:1rem;color:#7fa894;font-size:.75rem}
</style></head>
<body><main>
  <div class="mark">SOS</div>
  <h1>HORS LIGNE</h1>
  <p>Aucune copie locale de l'application n'est encore disponible sur cet appareil.</p>
  <p>Ouvrez SOS AL BAYDA <strong>une fois avec du réseau</strong> (dépôt / 4G). Ensuite, les ouvertures suivantes fonctionneront hors ligne.</p>
  <button type="button" onclick="location.reload()">Réessayer</button>
  <small>v4.3 · cold-start optimisé</small>
</main></body></html>`;

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(VERSION);
      await Promise.all(
        ROUTES.map((path) =>
          cache.add(new Request(path, { credentials: "same-origin" })).catch(() => undefined),
        ),
      );
      // Page de secours dédiée (utilisée si aucune route n'est en cache)
      await cache.put(
        "/__offline",
        new Response(OFFLINE_HTML, {
          headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" },
        }),
      );
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)));
      await self.clients.claim();
    })(),
  );
});

self.addEventListener("message", (event) => {
  const data = event.data;
  if (!data || data.type !== "CACHE_URLS" || !Array.isArray(data.urls)) return;
  event.waitUntil(
    (async () => {
      const cache = await caches.open(VERSION);
      await Promise.all(
        data.urls.map(async (href) => {
          try {
            const url = new URL(href, self.location.href);
            if (isDataRequest(url) || !isStatic(url)) return;
            if (await cache.match(url.href)) return;
            const res = await fetch(
              url.href,
              url.origin === self.location.origin ? undefined : { mode: "no-cors" },
            );
            if (res && (res.ok || res.type === "opaque")) await cache.put(url.href, res);
          } catch {
            /* hors ligne */
          }
        }),
      );
    })(),
  );
});

async function navigationResponse(request) {
  const cache = await caches.open(VERSION);
  const url = new URL(request.url);
  const key = url.pathname;

  try {
    const res = await Promise.race([
      fetch(request),
      new Promise((_, reject) => setTimeout(() => reject(new Error("timeout")), NETWORK_TIMEOUT_MS)),
    ]);
    if (res && res.ok && res.type === "basic") {
      // Mettre en cache la page HTML pour le prochain cold-start hors ligne
      cache.put(key, res.clone()).catch(() => undefined);
    }
    return res;
  } catch {
    return (
      (await cache.match(key, { ignoreSearch: true })) ||
      (await cache.match("/")) ||
      (await cache.match("/__offline")) ||
      new Response(OFFLINE_HTML, {
        status: 503,
        headers: { "Content-Type": "text/html; charset=utf-8" },
      })
    );
  }
}

async function staticResponse(request) {
  const cache = await caches.open(VERSION);
  const cached = await cache.match(request);
  if (cached) {
    // Revalidation en arrière-plan
    fetch(request)
      .then((res) => {
        if (res && res.ok) cache.put(request, res).catch(() => undefined);
      })
      .catch(() => undefined);
    return cached;
  }
  try {
    const res = await fetch(request);
    if (res && (res.ok || res.type === "opaque")) cache.put(request, res.clone()).catch(() => undefined);
    return res;
  } catch {
    return new Response("", { status: 504, statusText: "Offline" });
  }
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (isDataRequest(url)) return; // laisser le réseau (ou l'échec) à l'app / outbox

  if (req.mode === "navigate" || (req.headers.get("accept") || "").includes("text/html")) {
    event.respondWith(navigationResponse(req));
    return;
  }
  if (isStatic(url)) {
    event.respondWith(staticResponse(req));
  }
});
