# SOS AL BAYDA — évolution dispatch anomalies (v4.1)

- Catalogue initial complété à 500 emplacements avec coordonnées GPS.
- Les coordonnées des emplacements générés sont provisoires, calculées autour des centres de secteurs : elles doivent être vérifiées et corrigées sur le terrain avant utilisation comme adresse d'intervention réelle.
- **Mode validation GPS terrain** : bouton « Ma position » + badge GPS ✓ / GPS ? sur chaque point.
- Types de constats : dépôt sauvage, débordement de bacs, déchets verts, encombrants, salissures, défaut de balayage.
- **SLA variable par type** (ex. débordement 90 min, dépôt sauvage 120 min, défaut balayage 240 min) + priorité métier 1–5.
- Chaque nouveau constat reçoit une échéance, un indicateur visuel « À intervenir » puis « Délai dépassé », et un **historique d'audit**.
- Statuts : ouvert → assigné → en_intervention → clôturé / annule.
- Une équipe est proposée à partir de la proximité du centre de son secteur. Écran **/dispatch** pour affectation intelligente (urgence + charge + distance).
- Le calcul du véritable agent le plus proche nécessite que chaque agent partage sa position GPS en direct (basis `live-gps` déjà supporté côté ranking).
- Photos, description, date, secteur, coordonnées et statut sont conservés dans le constat.
- Android : PWA installable + **APK Capacitor** (mode shell HTTPS). Plugins : Geolocation, Camera, Push, LocalNotifications. Workflow GitHub Actions fourni.
- **v4.2** : file offline renforcée (badge sync, retry 45s, photos en mutation séparée).
