import { createFileRoute } from "@tanstack/react-router";
import { IncidentsPage } from "@/components/collecte/incidents-page";

export const Route = createFileRoute("/constats")({
  head: () => ({ meta: [{ title: "Constats & incidents · SOS Al Bayda" }] }),
  component: IncidentsPage,
});
