import { createFileRoute } from "@tanstack/react-router";
import { DispatchPage } from "@/components/collecte/dispatch-page";

export const Route = createFileRoute("/dispatch")({
  head: () => ({ meta: [{ title: "Dispatch · SOS Al Bayda" }] }),
  component: DispatchPage,
});
