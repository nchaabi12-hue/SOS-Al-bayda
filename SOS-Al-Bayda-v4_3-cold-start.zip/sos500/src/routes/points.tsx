import { createFileRoute } from "@tanstack/react-router";
import { PointsPage } from "@/components/collecte/points-page";

export const Route = createFileRoute("/points")({
  head: () => ({ meta: [{ title: "Points de collecte · SOS Al Bayda" }] }),
  component: PointsPage,
});
