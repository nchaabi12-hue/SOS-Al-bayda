import { createFileRoute } from "@tanstack/react-router";
import { ReportPage } from "@/components/collecte/report-page";

export const Route = createFileRoute("/rapports")({
  head: () => ({ meta: [{ title: "Rapports · SOS Al Bayda" }] }),
  component: ReportPage,
});
