import { createFileRoute } from "@tanstack/react-router";
import { SavingsPage } from "@/components/collecte/savings-page";

export const Route = createFileRoute("/economies")({
  head: () => ({ meta: [{ title: "Économies · SOS Al Bayda" }] }),
  component: SavingsPage,
});
