import { createFileRoute } from "@tanstack/react-router";
import { DashboardPage } from "@/components/collecte/dashboard-page";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Tableau de bord · SOS Al Bayda" }] }),
  component: DashboardPage,
});
