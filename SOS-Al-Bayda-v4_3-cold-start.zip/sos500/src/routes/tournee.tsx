import { createFileRoute } from "@tanstack/react-router";
import { TourPage } from "@/components/collecte/tour-page";

export const Route = createFileRoute("/tournee")({
  head: () => ({ meta: [{ title: "Tournée du jour · SOS Al Bayda" }] }),
  component: TourPage,
});
