import type { ReactNode } from "react";
import { useEffect } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { FileText, Flag, LayoutDashboard, MapPin, Radio, Route, TrendingUp } from "lucide-react";
import { APP } from "@/lib/collecte/config";
import { flushPendingMutations, hydrate, initStorage, refreshFromServer, refreshIfStale } from "@/lib/collecte/store";
import { SyncStatusBar } from "./sync-status";
import { useCollecte } from "./ui";

const NAV = [
  { to: "/", label: "Tableau de bord", short: "Accueil", icon: LayoutDashboard },
  { to: "/points", label: "Emplacements", short: "Lieux", icon: MapPin },
  { to: "/tournee", label: "Tournée du jour", short: "Tournée", icon: Route },
  { to: "/constats", label: "Constats & incidents", short: "Constats", icon: Flag },
  { to: "/dispatch", label: "Dispatch", short: "Dispatch", icon: Radio },
  { to: "/economies", label: "Économies", short: "Éco", icon: TrendingUp },
  { to: "/rapports", label: "Rapports", short: "Rapports", icon: FileText },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { toasts } = useCollecte();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    // Démarrage : relire la mémoire locale, puis rejouer la file AVANT de relire le serveur
    // (refreshFromServer s'en charge). Réseau déjà présent au lancement = envoi immédiat.
    void initStorage().then(() => {
      hydrate();
      void refreshFromServer();
    });
    // Retour du réseau : même séquence (rejouer, puis relire).
    const onOnline = () => {
      void refreshFromServer();
    };
    // Retour d'onglet / d'app : rejouer tout de suite ; relire seulement si la dernière lecture date.
    const onVisible = () => {
      if (document.visibilityState === "visible") {
        void flushPendingMutations().then(() => refreshIfStale(2 * 60_000));
      }
    };
    window.addEventListener("online", onOnline);
    document.addEventListener("visibilitychange", onVisible);

    // Stockage durable : sans ça Android peut purger IndexedDB + cache SW sous pression mémoire.
    void navigator.storage?.persist?.().catch(() => undefined);

    // Cold-start hors ligne : enregistrer le SW le plus tôt possible, puis pousser
    // tous les assets déjà chargés (JS/CSS hachés) dans le cache.
    let cacheTimer: number | undefined;
    let cacheTimer2: number | undefined;
    if ("serviceWorker" in navigator && !import.meta.env.DEV) {
      void navigator.serviceWorker
        .register("/sw.js", { scope: "/" })
        .then(() => navigator.serviceWorker.ready)
        .then((reg) => {
          const pushUrls = () => {
            const urls = performance.getEntriesByType("resource").map((e) => e.name);
            // Inclure aussi les routes HTML critiques pour le prochain cold-start.
            const routes = ["/", "/points", "/tournee", "/constats", "/dispatch", "/economies", "/rapports"];
            reg.active?.postMessage({ type: "CACHE_URLS", urls: [...urls, ...routes.map((r) => location.origin + r)] });
          };
          // 1er passage rapide (paint initial)
          cacheTimer = window.setTimeout(pushUrls, 800);
          // 2e passage après hydratation complète / lazy chunks
          cacheTimer2 = window.setTimeout(pushUrls, 5000);
        })
        .catch(() => undefined);
    }

    // Capacitor Network (APK) : plus fiable que navigator.onLine sur Android.
    let removeNetwork: (() => void) | undefined;
    void (async () => {
      try {
        const { Network } = await import("@capacitor/network");
        const status = await Network.getStatus();
        if (status.connected) void refreshFromServer();
        const handle = await Network.addListener("networkStatusChange", (s) => {
          if (s.connected) void refreshFromServer();
        });
        removeNetwork = () => {
          void handle.remove();
        };
      } catch {
        /* navigateur web ou plugin indisponible */
      }
    })();

    return () => {
      window.clearTimeout(cacheTimer);
      window.clearTimeout(cacheTimer2);
      window.removeEventListener("online", onOnline);
      document.removeEventListener("visibilitychange", onVisible);
      removeNetwork?.();
    };
  }, []);

  return (
    <div className="min-h-dvh bg-paper text-ink">
      <header className="safe-top sticky top-0 z-30 border-b border-line bg-surface">
        <div className="flex min-h-16 items-center justify-between px-4 md:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <img src="/brand/mark.png" alt="" className="h-9 w-auto max-w-[7.25rem] object-contain sm:h-10 sm:max-w-[9rem]" />
            <div className="min-w-0">
              <b className="block truncate font-display text-sm tracking-[0.18em]">SOS AL BAYDA</b>
              <small className="block truncate text-[10px] tracking-[0.14em] text-muted sm:text-xs">{APP.label}</small>
            </div>
          </div>
          <p className="hidden text-xs font-semibold text-faint sm:block">Suivi opérationnel · SOS AL BAYDA</p>
        </div>
        <div className="brand-bar" aria-hidden />
        <SyncStatusBar />
      </header>

      <div className="flex">
        <aside className="side-panel sticky top-[4.25rem] hidden w-60 shrink-0 flex-col gap-1 border-r border-line bg-surface px-3 py-6 md:flex">
          <p className="px-3 pb-3 text-xs font-extrabold tracking-widest text-faint">ESPACE OPÉRATIONNEL</p>
          {NAV.map((item) => {
            const active = pathname === item.to;
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                aria-current={active ? "page" : undefined}
                className={`flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm ${
                  active ? "bg-mint font-bold text-pine" : "text-muted hover:bg-mint hover:text-pine"
                }`}
              >
                <Icon className="size-4 shrink-0" strokeWidth={2.25} aria-hidden />
                <span>{item.label}</span>
              </Link>
            );
          })}
          <p className="mt-auto px-3 pt-6 text-xs text-faint">Synchronisation selon connexion et accès serveur.</p>
        </aside>

        <main className="min-w-0 flex-1 px-4 pt-6 pb-28 md:px-8 md:pt-8 md:pb-16">
          <div className="mx-auto w-full max-w-6xl">{children}</div>
        </main>
      </div>

      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-30 grid grid-cols-7 border-t border-line bg-surface md:hidden" aria-label="Navigation mobile">
        {NAV.map((item) => {
          const active = pathname === item.to;
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              aria-current={active ? "page" : undefined}
              className={`flex min-h-16 flex-col items-center justify-center gap-0.5 px-0.5 text-center text-xs leading-tight font-semibold ${
                active ? "text-pine" : "text-muted"
              }`}
            >
              <Icon className="size-5" strokeWidth={active ? 2.5 : 2} aria-hidden />
              {item.short}
            </Link>
          );
        })}
      </nav>

      <div className="pointer-events-none fixed inset-x-4 bottom-24 z-50 flex flex-col gap-2 md:inset-x-auto md:right-6 md:bottom-6 md:items-end" aria-live="polite">
        {toasts.map((t) => (
          <div
            key={t.id}
            role="status"
            className={`pointer-events-none rounded-xl px-4 py-3 text-sm font-semibold text-white shadow-lg ${
              t.kind === "error" ? "bg-danger" : "bg-toast"
            }`}
          >
            {t.message}
          </div>
        ))}
      </div>
    </div>
  );
}
