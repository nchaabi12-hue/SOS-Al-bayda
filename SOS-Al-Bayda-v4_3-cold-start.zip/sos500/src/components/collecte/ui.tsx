import { useEffect, type ReactNode } from "react";
import { useSyncExternalStore } from "react";
import { getServerSnapshot, getSnapshot, subscribe } from "@/lib/collecte/store";

export function useCollecte() {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}

export function PageHeader({
  eyebrow,
  title,
  sub,
  action,
}: {
  eyebrow: string;
  title: string;
  sub: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <p className="text-xs font-extrabold tracking-widest text-pine-2 uppercase">{eyebrow}</p>
        <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-ink">{title}</h1>
        <p className="mt-1 text-muted">{sub}</p>
      </div>
      {action}
    </div>
  );
}

export function StatCard({ label, value, note }: { label: string; value: string | number; note: string }) {
  return (
    <article className="rounded-2xl border border-line bg-surface px-4 py-4 shadow-sm">
      <p className="text-xs font-semibold text-muted">{label}</p>
      <p className="mt-2 font-display text-3xl font-extrabold tracking-tight text-ink">{value}</p>
      <p className="mt-1 text-xs text-faint">{note}</p>
    </article>
  );
}

export function Progress({ value }: { value: number }) {
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div
      className="mt-3 h-2 overflow-hidden rounded-full bg-mint"
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(pct)}
    >
      <span className="block h-full rounded-full bg-pine" style={{ width: `${pct}%` }} />
    </div>
  );
}

const PILL: Record<string, string> = {
  priority: "bg-amber-soft text-amber",
  collected: "bg-paper text-muted",
  skipped: "bg-amber-soft text-amber",
  toCollect: "bg-mint text-pine",
};

export function Pill({ kind, children }: { kind: string; children: ReactNode }) {
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-bold ${PILL[kind] ?? PILL.toCollect}`}>
      {children}
    </span>
  );
}

export function Modal({
  title,
  onClose,
  children,
  footer,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-40 grid place-items-center bg-ink/45 p-4"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="max-h-[calc(100dvh-2rem)] w-full max-w-lg overflow-auto rounded-2xl bg-surface shadow-xl"
      >
        <div className="flex items-center justify-between px-5 pt-4">
          <h2 className="text-lg font-bold">{title}</h2>
          <button type="button" className="grid size-11 place-items-center text-2xl text-muted" onClick={onClose} aria-label="Fermer">
            ×
          </button>
        </div>
        <div className="px-5 py-3">{children}</div>
        {footer ? <div className="flex flex-wrap justify-end gap-2 px-5 pb-5">{footer}</div> : null}
      </div>
    </div>
  );
}

export const fieldClass =
  "min-h-11 w-full rounded-xl border border-line bg-surface px-3 py-2 text-ink outline-none";

export const btnPrimary =
  "inline-flex min-h-11 items-center justify-center rounded-xl bg-pine px-4 font-bold text-white hover:bg-pine-2 disabled:opacity-55";

export const btnSecondary =
  "inline-flex min-h-11 items-center justify-center rounded-xl bg-mint px-4 font-bold text-pine hover:bg-mint disabled:opacity-55";

export const btnDanger =
  "inline-flex min-h-11 items-center justify-center rounded-xl bg-danger-soft px-4 font-bold text-danger";

export const btnSmall =
  "inline-flex min-h-11 items-center justify-center rounded-lg border border-line bg-surface px-3 text-sm font-semibold text-pine hover:bg-mint";
