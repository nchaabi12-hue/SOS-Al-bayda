import { MAP_BBOX, SECTORS } from "@/lib/collecte/config";
import { planTour } from "@/lib/collecte/geo";
import { recordSaving, resetTour, setSession, setUi, todayISO, toast } from "@/lib/collecte/store";
import { PageHeader, StatCard, btnPrimary, btnSecondary, fieldClass, useCollecte } from "./ui";
import { RouteSketch } from "./route-sketch";

export function TourPage() {
  const data = useCollecte();
  const toVisit = data.points.filter((p) => p.inTodayTour !== false && p.status !== "collected");
  const ordered = (data.session?.ids ?? [])
    .map((id) => data.points.find((p) => p.id === id))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));
  const session = data.session;
  const bbox = MAP_BBOX.join("%2C");
  const sketchPoints = toVisit.filter((p) => data.ui.tourSector === "Tous" || p.neighborhood === data.ui.tourSector);

  const optimize = () => {
    const selection = toVisit.filter((p) => data.ui.tourSector === "Tous" || p.neighborhood === data.ui.tourSector);
    if (!selection.length) {
      toast("Aucun point dans cette sélection");
      return;
    }
    const plan = planTour(selection);
    setSession({
      ids: plan.order.map((p) => p.id),
      km: plan.km,
      minutes: plan.minutes,
      savedKm: plan.savedKm,
      sector: data.ui.tourSector,
    });
    recordSaving({
      date: todayISO(),
      sector: data.ui.tourSector,
      km: plan.savedKm,
      points: plan.order.length,
    });
    toast("Ordre de tournée optimisé");
  };

  return (
    <>
      <PageHeader eyebrow="Exploitation" title="Tournée du jour" sub="Organisation et optimisation locale des circuits" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Points à visiter" value={toVisit.length} note="Hors points déjà collectés" />
        <StatCard label="Points dans la tournée" value={ordered.length} note="Ordre optimisé actuel" />
        <StatCard label="Distance estimée" value={session ? `${session.km} km` : "—"} note="Vol d'oiseau × 1,3" />
        <StatCard label="Temps estimé" value={session ? `${session.minutes} min` : "—"} note="25 km/h + 3 min / point" />
      </div>

      <section className="mt-5 rounded-2xl border border-line bg-surface p-4 shadow-sm md:p-5">
        <h2 className="mb-4 text-base font-bold">Préparer la tournée</h2>
        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap">
          <select
            className={`${fieldClass} sm:max-w-64`}
            aria-label="Secteur de la tournée"
            value={data.ui.tourSector}
            onChange={(e) => setUi({ tourSector: e.target.value })}
          >
            <option value="Tous">Tous les secteurs</option>
            {SECTORS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
          <button type="button" className={btnPrimary} onClick={optimize}>
            Optimiser l'ordre
          </button>
          <button
            type="button"
            className={btnSecondary}
            onClick={() => {
              resetTour();
              toast("Sélection réinitialisée");
            }}
          >
            Réinitialiser la sélection
          </button>
        </div>
        <p className="mt-3 text-sm text-muted">
          Plus proche voisin depuis le dépôt. La distance est une estimation, pas un itinéraire routier garanti.
        </p>

        <div className="mt-4">
          <RouteSketch points={sketchPoints.length ? sketchPoints : data.points} route={ordered} />
          <p className="mt-2 text-xs text-faint">Carré : dépôt. Numéros : ordre de passage. Points grisés : hors tournée optimisée.</p>
        </div>

        {ordered.length ? (
          <>
            <ol className="mt-4 list-decimal space-y-2 pl-5">
              {ordered.map((p) => (
                <li key={p.id} className="pl-1">
                  <span className="font-semibold">{p.name}</span>
                  <span className="text-muted"> — {p.neighborhood}</span>{" "}
                  <a
                    className="text-sm font-bold text-pine-2"
                    target="_blank"
                    rel="noopener noreferrer"
                    href={`https://www.openstreetmap.org/?mlat=${p.lat}&mlon=${p.lng}#map=18/${p.lat}/${p.lng}`}
                  >
                    Carte
                  </a>
                </li>
              ))}
            </ol>
            {session ? (
              <p className="mt-3 text-sm text-muted">
                Économie estimée par rapport à l'ordre de la liste : <b>{session.savedKm.toFixed(1)} km</b>.
              </p>
            ) : null}
          </>
        ) : (
          <p className="mt-4 rounded-xl bg-paper px-4 py-6 text-center text-muted">
            Aucune tournée optimisée. Choisissez un secteur puis lancez l'optimisation.
          </p>
        )}
      </section>

      <section className="mt-5 rounded-2xl border border-line bg-surface p-4 shadow-sm md:p-5">
        <h2 className="mb-1 text-base font-bold">Carte des rues</h2>
        <p className="mb-3 text-sm text-muted">OpenStreetMap — une connexion est nécessaire.</p>
        <iframe
          className="h-80 w-full rounded-xl border-0 bg-mint"
          title="Carte OpenStreetMap"
          loading="lazy"
          src={`https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik`}
        />
      </section>
    </>
  );
}
