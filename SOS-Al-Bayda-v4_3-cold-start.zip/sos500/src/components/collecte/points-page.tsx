import { useState } from "react";
import { SECTORS, STATUS_LABELS, type Point, type PointStatus } from "@/lib/collecte/config";
import { addPoint, deletePoint, isPriority, setPointStatus, setUi, toast, updatePoint, validatePointGps } from "@/lib/collecte/store";
import { GpsBadge, GpsValidatePanel } from "./gps-validation";
import { Modal, PageHeader, Pill, btnDanger, btnPrimary, btnSecondary, btnSmall, fieldClass, useCollecte } from "./ui";

function display(p: Point): { label: string; kind: string } {
  if (p.status === "collected") return { label: STATUS_LABELS.collected, kind: "collected" };
  if (p.status === "skipped") return { label: STATUS_LABELS.skipped, kind: "skipped" };
  if (isPriority(p)) return { label: STATUS_LABELS.priority, kind: "priority" };
  return { label: STATUS_LABELS.toCollect, kind: "toCollect" };
}

function Actions({ id, stacked }: { id: string; stacked?: boolean }) {
  const set = (status: PointStatus) => {
    setPointStatus(id, status);
    toast("État du point mis à jour");
  };
  const wrap = stacked ? "mt-3 grid grid-cols-2 gap-2" : "flex flex-wrap gap-1.5";
  return (
    <div className={wrap}>
      <button type="button" className={btnSmall} onClick={() => set("collected")}>
        Collecté
      </button>
      <button type="button" className={btnSmall} onClick={() => set("priority")}>
        Priorité
      </button>
      <button type="button" className={btnSmall} onClick={() => set("skipped")}>
        Ignorer
      </button>
      <button type="button" className={btnSmall} onClick={() => set("toCollect")}>
        Réinitialiser
      </button>
    </div>
  );
}

type Draft = {
  name: string;
  neighborhood: string;
  address: string;
  lat: string;
  lng: string;
  fillLevel: string;
};

function draftFrom(p?: Point): Draft {
  return {
    name: p?.name ?? "",
    neighborhood: p?.neighborhood ?? SECTORS[0],
    address: p?.address ?? "",
    lat: p ? String(p.lat) : "33.5920",
    lng: p ? String(p.lng) : "-7.5700",
    fillLevel: String(p?.fillLevel ?? 0),
  };
}

export function PointsPage() {
  const { points, ui } = useCollecte();
  const [editing, setEditing] = useState<Point | "new" | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft>(draftFrom());
  const [error, setError] = useState("");

  const q = ui.search.trim().toLowerCase();
  const list = points.filter(
    (p) =>
      (ui.sectorFilter === "Tous" || p.neighborhood === ui.sectorFilter) &&
      `${p.name} ${p.address} ${p.id}`.toLowerCase().includes(q),
  );

  const openNew = () => {
    setDraft(draftFrom());
    setError("");
    setEditing("new");
  };
  const openEdit = (p: Point) => {
    setDraft(draftFrom(p));
    setError("");
    setEditing(p);
  };

  const save = () => {
    const name = draft.name.trim();
    const lat = Number(draft.lat);
    const lng = Number(draft.lng);
    if (!name) {
      setError("Le nom est obligatoire.");
      return;
    }
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      setError("Coordonnées GPS invalides.");
      return;
    }
    const payload = {
      name,
      neighborhood: draft.neighborhood,
      address: draft.address.trim() || name,
      lat,
      lng,
      fillLevel: Number(draft.fillLevel) || 0,
    };
    if (editing && editing !== "new") {
      updatePoint(editing.id, payload);
      toast("Point mis à jour");
    } else {
      addPoint(payload);
      toast("Point ajouté");
    }
    setEditing(null);
  };

  const doomed = points.find((p) => p.id === confirmId);

  return (
    <>
      <PageHeader
        eyebrow="Base opérationnelle"
        title="Emplacements d’anomalies"
        sub={`${points.length} emplacements GPS · recherche et classement par secteur`}
        action={
          <button type="button" className={btnPrimary} onClick={openNew}>
            + Ajouter un point
          </button>
        }
      />

      <div className="mb-4 flex flex-col gap-2 sm:flex-row">
        <input
          className={fieldClass}
          type="search"
          placeholder="Rechercher un point..."
          aria-label="Rechercher un point"
          value={ui.search}
          onChange={(e) => setUi({ search: e.target.value })}
        />
        <select
          className={`${fieldClass} sm:max-w-56`}
          aria-label="Filtrer par secteur"
          value={ui.sectorFilter}
          onChange={(e) => setUi({ sectorFilter: e.target.value })}
        >
          <option>Tous</option>
          {SECTORS.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </div>

      {list.length === 0 ? (
        <p className="rounded-2xl border border-line bg-surface px-4 py-10 text-center text-muted">Aucun point trouvé</p>
      ) : (
        <>
          <ul className="grid gap-3 md:hidden">
            {list.map((p) => {
              const st = display(p);
              return (
                <li key={p.id} className="rounded-2xl border border-line bg-surface p-4 shadow-sm">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-bold">{p.name}</p>
                      <p className="text-sm text-muted">{p.address}</p>
                      <p className="mt-1 text-xs text-faint">
                        {p.id} · {p.neighborhood}
                      </p>
                      <a className="mt-1 inline-block text-xs font-semibold text-pine underline" href={`https://www.google.com/maps?q=${p.lat},${p.lng}`} target="_blank" rel="noreferrer">
                        GPS : {p.lat.toFixed(5)}, {p.lng.toFixed(5)} · Ouvrir la carte
                      </a>
                      <GpsBadge validated={!!p.gpsValidatedAt} />
                    </div>
                    <Pill kind={st.kind}>{st.label}</Pill>
                  </div>
                  <p className="mt-3 text-sm">
                    Remplissage <b>{p.fillLevel}%</b>
                  </p>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-mint">
                    <span className="block h-full bg-pine" style={{ width: `${p.fillLevel}%` }} />
                  </div>
                  <Actions id={p.id} stacked />
                  <button type="button" className={`${btnSecondary} mt-2 w-full`} onClick={() => openEdit(p)}>
                    Modifier
                  </button>
                </li>
              );
            })}
          </ul>

          <div className="hidden overflow-hidden rounded-2xl border border-line bg-surface shadow-sm md:block">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-paper text-left text-xs tracking-wide text-muted uppercase">
                  <th className="px-4 py-3 font-bold">Point</th>
                  <th className="px-4 py-3 font-bold">Secteur</th>
                  <th className="px-4 py-3 font-bold">Remplissage</th>
                  <th className="px-4 py-3 font-bold">État</th>
                  <th className="px-4 py-3 font-bold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {list.map((p) => {
                  const st = display(p);
                  return (
                    <tr key={p.id} className="border-t border-line align-top">
                      <td className="px-4 py-3">
                        <b>{p.name}</b>
                        <div className="text-muted">{p.address}</div>
                        <div className="text-xs text-faint">{p.id}</div>
                        <a className="text-xs font-semibold text-pine underline" href={`https://www.google.com/maps?q=${p.lat},${p.lng}`} target="_blank" rel="noreferrer">
                          GPS {p.lat.toFixed(5)}, {p.lng.toFixed(5)} · Carte
                        </a>
                        <GpsBadge validated={!!p.gpsValidatedAt} />
                      </td>
                      <td className="px-4 py-3">{p.neighborhood}</td>
                      <td className="px-4 py-3">{p.fillLevel}%</td>
                      <td className="px-4 py-3">
                        <Pill kind={st.kind}>{st.label}</Pill>
                      </td>
                      <td className="px-4 py-3">
                        <Actions id={p.id} />
                        <button type="button" className={`${btnSmall} mt-1.5`} onClick={() => openEdit(p)}>
                          Modifier
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}

      {editing ? (
        <Modal
          title={editing === "new" ? "Ajouter un point" : "Modifier le point"}
          onClose={() => setEditing(null)}
          footer={
            <>
              {editing !== "new" ? (
                <button
                  type="button"
                  className={btnDanger}
                  onClick={() => {
                    setConfirmId(editing.id);
                  }}
                >
                  Supprimer
                </button>
              ) : null}
              <button type="button" className={btnSecondary} onClick={() => setEditing(null)}>
                Annuler
              </button>
              <button type="button" className={btnPrimary} onClick={save}>
                Enregistrer
              </button>
            </>
          }
        >
          <form
            className="grid gap-3 sm:grid-cols-2"
            onSubmit={(e) => {
              e.preventDefault();
              save();
            }}
          >
            <label className="grid gap-1 text-xs font-bold text-muted sm:col-span-2">
              Nom du point
              <input className={fieldClass} required value={draft.name} placeholder="Ex. Benne Hay Adil 12" onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
            </label>
            <label className="grid gap-1 text-xs font-bold text-muted">
              Secteur
              <select className={fieldClass} value={draft.neighborhood} onChange={(e) => setDraft({ ...draft, neighborhood: e.target.value })}>
                {SECTORS.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </label>
            <label className="grid gap-1 text-xs font-bold text-muted">
              Remplissage ({draft.fillLevel}%)
              <input
                className="accent-pine"
                type="range"
                min={0}
                max={100}
                step={5}
                value={draft.fillLevel}
                onChange={(e) => setDraft({ ...draft, fillLevel: e.target.value })}
              />
              <span className="font-medium text-faint">À partir de 80 %, le point compte comme prioritaire.</span>
            </label>
            <label className="grid gap-1 text-xs font-bold text-muted">
              Latitude GPS
              <input className={fieldClass} inputMode="decimal" value={draft.lat} onChange={(e) => setDraft({ ...draft, lat: e.target.value })} />
            </label>
            <label className="grid gap-1 text-xs font-bold text-muted">
              Longitude GPS
              <input className={fieldClass} inputMode="decimal" value={draft.lng} onChange={(e) => setDraft({ ...draft, lng: e.target.value })} />
            </label>
            <GpsValidatePanel
              lat={draft.lat}
              lng={draft.lng}
              validated={editing !== "new" && editing !== null && !!(editing as Point).gpsValidatedAt}
              validatedAt={editing !== "new" && editing !== null ? (editing as Point).gpsValidatedAt : undefined}
              onApply={(lat, lng, accuracy) => {
                setDraft({ ...draft, lat: String(lat), lng: String(lng) });
                if (editing && editing !== "new") {
                  validatePointGps(editing.id, { lat, lng, accuracy, source: "device" });
                  toast("Position GPS validée");
                }
              }}
            />
            <label className="grid gap-1 text-xs font-bold text-muted sm:col-span-2">
              Adresse / repère
              <input className={fieldClass} value={draft.address} onChange={(e) => setDraft({ ...draft, address: e.target.value })} />
            </label>
            {error ? (
              <p className="text-sm font-semibold text-danger sm:col-span-2" role="alert">
                {error}
              </p>
            ) : null}
          </form>
        </Modal>
      ) : null}

      {doomed ? (
        <Modal
          title="Supprimer ce point ?"
          onClose={() => setConfirmId(null)}
          footer={
            <>
              <button type="button" className={btnSecondary} onClick={() => setConfirmId(null)}>
                Annuler
              </button>
              <button
                type="button"
                className={btnDanger}
                onClick={() => {
                  deletePoint(doomed.id);
                  setConfirmId(null);
                  setEditing(null);
                  toast("Point supprimé");
                }}
              >
                Supprimer
              </button>
            </>
          }
        >
          <p>« {doomed.name} » sera retiré de la base locale.</p>
        </Modal>
      ) : null}
    </>
  );
}
