import { SAVINGS } from "@/lib/collecte/config";
import { PageHeader, StatCard, useCollecte } from "./ui";

export function SavingsPage() {
  const { savings } = useCollecte();
  const total = savings.reduce((sum, e) => sum + (Number(e.km) || 0), 0);
  const liters = total / SAVINGS.kmPerLiter;
  const history = [...savings].reverse();

  return (
    <>
      <PageHeader eyebrow="Performance" title="Économies" sub="Historique des distances estimées économisées" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Kilomètres économisés" value={`${total.toFixed(1)} km`} note="Cumul enregistré" />
        <StatCard label="Équivalent carburant" value={`${liters.toFixed(2)} L`} note={`Hypothèse : ${SAVINGS.kmPerLiter} km / litre`} />
        <StatCard
          label="Équivalent financier"
          value={`${Math.round(liters * SAVINGS.madPerLiter)} MAD`}
          note={`Hypothèse : ${SAVINGS.madPerLiter} MAD / litre`}
        />
        <StatCard label="Journées enregistrées" value={savings.length} note="Historique local" />
      </div>
      <section className="mt-5 rounded-2xl border border-line bg-surface p-4 shadow-sm md:p-5">
        <h2 className="mb-2 text-base font-bold">Historique</h2>
        {history.length === 0 ? (
          <p className="rounded-xl bg-paper px-4 py-8 text-center text-muted">Aucune économie enregistrée pour le moment.</p>
        ) : (
          <ul>
            {history.map((e, i) => (
              <li key={`${e.date}-${e.sector}-${i}`} className="flex items-start justify-between gap-3 border-b border-line py-3 last:border-0">
                <span className="text-sm">
                  {e.date}
                  {e.sector ? ` · ${e.sector === "Tous" ? "Tous secteurs" : e.sector}` : ""}
                  {e.points ? ` · ${e.points} points` : ""}
                </span>
                <b className="shrink-0">{(Number(e.km) || 0).toFixed(1)} km</b>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
