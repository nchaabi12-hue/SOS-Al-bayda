import { useCallback, useState } from "react";
import { btnSecondary, btnSmall } from "./ui";

export type LivePos = { lat: number; lng: number; accuracy?: number; source: "browser" | "capacitor" };

export async function readDevicePosition(): Promise<LivePos> {
  try {
    const { Geolocation } = await import("@capacitor/geolocation");
    const pos = await Geolocation.getCurrentPosition({
      enableHighAccuracy: true,
      timeout: 12_000,
    });
    return {
      lat: pos.coords.latitude,
      lng: pos.coords.longitude,
      accuracy: pos.coords.accuracy,
      source: "capacitor",
    };
  } catch {
    // fallback browser
  }

  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Géolocalisation non disponible sur cet appareil"));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) =>
        resolve({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          source: "browser",
        }),
      (err) => reject(err),
      { enableHighAccuracy: true, timeout: 12_000, maximumAge: 5_000 },
    );
  });
}

export function useLivePosition() {
  const [pos, setPos] = useState<LivePos | null>(null);
  const [error, setError] = useState<string>("");
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const p = await readDevicePosition();
      setPos(p);
      return p;
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Impossible d'obtenir la position";
      setError(msg);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  return { pos, error, loading, refresh };
}

type Props = {
  lat: string;
  lng: string;
  onApply: (lat: number, lng: number, accuracy?: number) => void;
  validated?: boolean;
  validatedAt?: string;
};

export function GpsValidatePanel({ lat, lng, onApply, validated, validatedAt }: Props) {
  const { pos, error, loading, refresh } = useLivePosition();

  return (
    <div className="rounded-xl border border-dashed border-line bg-paper/60 p-3 sm:col-span-2">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs font-extrabold tracking-wide text-muted">GPS TERRAIN</p>
        {validated ? (
          <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-extrabold text-emerald-800">
            ✓ Validé{validatedAt ? ` · ${new Date(validatedAt).toLocaleDateString("fr-FR")}` : ""}
          </span>
        ) : (
          <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-extrabold text-amber-900">
            Provisoire
          </span>
        )}
      </div>

      <p className="mb-2 text-xs text-muted">
        Position enregistrée :{" "}
        <code className="text-ink">
          {lat || "—"}, {lng || "—"}
        </code>
      </p>

      <div className="flex flex-wrap gap-2">
        <button type="button" className={btnSecondary} disabled={loading} onClick={() => void refresh()}>
          {loading ? "Localisation…" : "Ma position"}
        </button>
        {pos && (
          <button
            type="button"
            className={btnSmall}
            onClick={() => onApply(pos.lat, pos.lng, pos.accuracy)}
          >
            Appliquer {pos.lat.toFixed(5)}, {pos.lng.toFixed(5)}
            {pos.accuracy != null ? ` (±${Math.round(pos.accuracy)} m)` : ""}
          </button>
        )}
      </div>
      {error && <p className="mt-2 text-xs font-semibold text-red-700">{error}</p>}
      {pos && (
        <p className="mt-2 text-[11px] text-faint">
          Source : {pos.source === "capacitor" ? "Capacitor (APK)" : "Navigateur"} · précision{" "}
          {pos.accuracy != null ? `±${Math.round(pos.accuracy)} m` : "n/d"}
        </p>
      )}
    </div>
  );
}

export function GpsBadge({ validated }: { validated?: boolean }) {
  if (validated) {
    return (
      <span className="ml-1 inline-flex items-center rounded-full bg-emerald-100 px-1.5 py-0.5 text-[10px] font-bold text-emerald-800">
        GPS ✓
      </span>
    );
  }
  return (
    <span className="ml-1 inline-flex items-center rounded-full bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-900">
      GPS ?
    </span>
  );
}
