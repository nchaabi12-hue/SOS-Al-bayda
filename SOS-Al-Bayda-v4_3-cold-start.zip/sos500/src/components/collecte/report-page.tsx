import { useState } from "react";
import { STATUS_LABELS } from "@/lib/collecte/config";
import { downloadText, exportBackup, importBackup, shareText, statsOf, toCsv, toast } from "@/lib/collecte/store";
import { Modal, PageHeader, StatCard, btnDanger, btnPrimary, btnSecondary, useCollecte } from "./ui";

export function ReportPage() {
  const data = useCollecte();
  const s = statsOf(data);
  const [pending, setPending] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);

  const guard = async (fn: () => Promise<void>) => {
    try {
      await fn();
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      const message = err instanceof Error ? err.message : "erreur";
      toast("Action impossible : " + message, "error");
    }
  };

  return (
    <>
      <PageHeader eyebrow="Synthèse" title="Rapports opérationnels" sub="Exporter les données enregistrées sur cet appareil" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Points" value={s.total} note="Total" />
        <StatCard label="Collectés" value={s.collected} note="État actuel" />
        <StatCard label="Ignorés" value={s.skipped} note="État actuel" />
        <StatCard label="Incidents" value={s.totalIncidents} note="Total enregistré" />
      </div>

      <section className="mt-5 rounded-2xl border border-line bg-surface p-4 shadow-sm md:p-5">
        <h2 className="mb-4 text-base font-bold">Exporter</h2>
        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap">
          <button
            type="button"
            className={btnPrimary}
            disabled={busy}
            onClick={() =>
              void guard(async () => {
                setBusy(true);
                try {
                  const backup = await exportBackup();
                  downloadText("albayda-sauvegarde.json", JSON.stringify(backup, null, 2), "application/json");
                  toast("Sauvegarde exportée");
                } finally {
                  setBusy(false);
                }
              })
            }
          >
            Exporter une sauvegarde JSON
          </button>
          <button
            type="button"
            className={btnSecondary}
            onClick={() =>
              void guard(async () => {
                const rows: Array<Array<string | number>> = [
                  ["ID", "Nom", "Secteur", "Adresse", "Latitude", "Longitude", "Statut", "Remplissage (%)"],
                  ...data.points.map((p) => [
                    p.id,
                    p.name,
                    p.neighborhood,
                    p.address,
                    p.lat,
                    p.lng,
                    STATUS_LABELS[p.status] ?? p.status,
                    p.fillLevel,
                  ]),
                ];
                downloadText("albayda-points.csv", toCsv(rows), "text/csv;charset=utf-8");
                toast("CSV exporté");
              })
            }
          >
            Exporter les points CSV
          </button>
          <button
            type="button"
            className={btnSecondary}
            onClick={() =>
              void guard(async () => {
                const live = statsOf(data);
                await shareText(
                  "Rapport SOS Al Bayda",
                  `SOS AL BAYDA\nPoints: ${live.total}\nCollectés: ${live.collected}\nIncidents: ${live.totalIncidents}`,
                );
              })
            }
          >
            Partager le résumé
          </button>
          <label className={`${btnSecondary} cursor-pointer`}>
            Importer une sauvegarde
            <input
              type="file"
              accept=".json,application/json"
              className="sr-only"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                e.target.value = "";
                if (!file) return;
                try {
                  const parsed: unknown = JSON.parse(await file.text());
                  if (!parsed || typeof parsed !== "object" || !Array.isArray((parsed as { points?: unknown }).points)) {
                    throw new Error("invalide");
                  }
                  setPending(parsed);
                } catch {
                  toast("Fichier de sauvegarde invalide", "error");
                }
              }}
            />
          </label>
        </div>
        <p className="mt-4 text-sm text-muted">
          Conservez régulièrement une sauvegarde. Les données restent sur cet appareil et ne sont pas synchronisées entre téléphones.
        </p>
      </section>

      {pending ? (
        <Modal
          title="Importer cette sauvegarde ?"
          onClose={() => setPending(null)}
          footer={
            <>
              <button type="button" className={btnSecondary} onClick={() => setPending(null)}>
                Annuler
              </button>
              <button
                type="button"
                className={btnDanger}
                onClick={() =>
                  void guard(async () => {
                    await importBackup(pending);
                    setPending(null);
                    toast("Sauvegarde importée");
                  })
                }
              >
                Importer
              </button>
            </>
          }
        >
          <p>
            Les données actuelles ({data.points.length} points, {data.incidents.length} constats) seront remplacées par celles du
            fichier.
          </p>
        </Modal>
      ) : null}
    </>
  );
}
