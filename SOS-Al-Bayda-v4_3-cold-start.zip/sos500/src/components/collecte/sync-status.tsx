import { useEffect, useState } from "react";
import {
  clearFailedMutations,
  flushPendingMutations,
  getOutboxSnapshot,
  getPendingCount,
  subscribe,
  toast,
} from "@/lib/collecte/store";
import { useCollecte } from "./ui";

/**
 * Indicateur de synchronisation hors-ligne.
 * Affiche le nombre d'éléments en file + bouton forcer la sync.
 */
export function SyncStatusBar() {
  const { sync } = useCollecte();
  const [count, setCount] = useState(0);
  const [busy, setBusy] = useState(false);
  const [detail, setDetail] = useState("");
  const [failed, setFailed] = useState(0);
  const [lastError, setLastError] = useState("");

  useEffect(() => {
    const refresh = () => {
      const snap = getOutboxSnapshot();
      setCount(snap.count);
      setFailed(snap.failed);
      setLastError(snap.lastError ?? "");
      if (snap.count === 0) {
        setDetail("");
        return;
      }
      const parts: string[] = [];
      if (snap.kinds.incident) parts.push(`${snap.kinds.incident} constat${snap.kinds.incident > 1 ? "s" : ""}`);
      if (snap.kinds.point) parts.push(`${snap.kinds.point} point${snap.kinds.point > 1 ? "s" : ""}`);
      if (snap.kinds.pointDelete) parts.push(`${snap.kinds.pointDelete} suppression${snap.kinds.pointDelete > 1 ? "s" : ""}`);
      if (snap.kinds.photo) parts.push(`${snap.kinds.photo} photo${snap.kinds.photo > 1 ? "s" : ""}`);
      if (snap.kinds.saving) parts.push(`${snap.kinds.saving} économie${snap.kinds.saving > 1 ? "s" : ""}`);
      setDetail(parts.join(" · "));
    };
    refresh();
    return subscribe(refresh);
  }, []);

  // Retry périodique si online et file non vide
  useEffect(() => {
    const tick = () => {
      if (typeof navigator !== "undefined" && !navigator.onLine) return;
      if (getPendingCount() === 0) return;
      void flushPendingMutations();
    };
    const id = window.setInterval(tick, 45_000);
    return () => window.clearInterval(id);
  }, []);

  const onSync = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const result = await flushPendingMutations({ force: true });
      if (result.remaining === 0) {
        toast(result.flushed ? "Synchronisation terminée" : "Rien à synchroniser");
      } else {
        toast(`${result.remaining} élément(s) encore en attente`, "error");
      }
      setCount(getPendingCount());
    } finally {
      setBusy(false);
    }
  };

  const auth = sync === "auth";

  if (sync === "ok" && count === 0 && failed === 0) return null;

  if (failed > 0 && count === 0 && !auth) {
    return (
      <div
        className="flex flex-wrap items-center justify-between gap-2 border-b border-red-200 bg-red-50 px-4 py-2 text-xs font-semibold text-red-900 md:px-6"
        role="alert"
      >
        <span>
          {failed} modification{failed > 1 ? "s" : ""} refusée{failed > 1 ? "s" : ""} par le serveur (droits ou données). L'écran a été réaligné sur le serveur.
        </span>
        <button
          type="button"
          onClick={clearFailedMutations}
          className="rounded-lg border border-current/20 bg-white/70 px-2.5 py-1 text-[11px] font-extrabold tracking-wide uppercase hover:bg-white"
        >
          Compris
        </button>
      </div>
    );
  }

  const label = auth
    ? "Session expirée — reconnectez-vous"
    : count > 0
      ? `${count} en attente de sync${detail ? ` (${detail})` : ""}${lastError ? ` · ${lastError}` : ""}`
      : sync === "offline"
        ? "Hors ligne — modifications locales"
        : "Synchronisation…";

  const color = auth
    ? "bg-red-50 text-red-900 border-red-200"
    : count > 0
      ? "bg-amber-50 text-amber-950 border-amber-200"
      : "bg-mint text-pine border-line";

  return (
    <div
      className={`flex flex-wrap items-center justify-between gap-2 border-b px-4 py-2 text-xs font-semibold md:px-6 ${color}`}
      role="status"
      aria-live="polite"
    >
      <span>{label}</span>
      {!auth && (
        <button
          type="button"
          disabled={busy || (typeof navigator !== "undefined" && !navigator.onLine && count === 0)}
          onClick={() => void onSync()}
          className="rounded-lg border border-current/20 bg-white/70 px-2.5 py-1 text-[11px] font-extrabold tracking-wide uppercase hover:bg-white disabled:opacity-50"
        >
          {busy ? "Sync…" : "Synchroniser"}
        </button>
      )}
    </div>
  );
}
