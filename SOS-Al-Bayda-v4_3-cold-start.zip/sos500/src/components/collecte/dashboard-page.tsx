import { useNavigate } from "@tanstack/react-router";
import { SECTORS } from "@/lib/collecte/config";
import { setUi, statsOf } from "@/lib/collecte/store";
import { PageHeader, Progress, StatCard, btnPrimary, btnSecondary, useCollecte } from "./ui";

export function DashboardPage() {
  const data = useCollecte();
  const navigate = useNavigate();
  const s = statsOf(data);

  return (
    <>
      <PageHeader eyebrow="Vue générale" title="Tableau de bord" sub="Suivi opérationnel de la collecte à Casablanca" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Points enregistrés" value={s.total} note="Base de points chargée" />
        <StatCard label="Points collectés" value={s.collected} note={`${s.collectedPct}% du parc`} />
        <StatCard label="Points prioritaires" value={s.priority} note="À traiter en priorité" />
        <StatCard label="Constats ouverts" value={s.openIncidents} note="Incidents non clôturés" />
      </div>

      <section className="mt-5 rounded-2xl border border-line bg-surface p-4 shadow-sm md:p-5">
        <h2 className="mb-4 text-base font-bold">Suivi par secteur</h2>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
          {SECTORS.map((sector) => {
            const pts = data.points.filter((p) => p.neighborhood === sector);
            const done = pts.filter((p) => p.status === "collected").length;
            const pct = pts.length ? (done / pts.length) * 100 : 0;
            return (
              <button
                key={sector}
                type="button"
                className="rounded-xl border border-line bg-surface p-4 text-left hover:border-pine-2"
                onClick={() => {
                  setUi({ sectorFilter: sector, search: "" });
                  void navigate({ to: "/points" });
                }}
              >
                <b className="block font-display">{sector}</b>
                <small className="text-muted">
                  {done} / {pts.length} points collectés
                </small>
                <Progress value={pct} />
              </button>
            );
          })}
        </div>
      </section>

      <section className="mt-5 rounded-2xl border border-line bg-surface p-4 shadow-sm md:p-5">
        <h2 className="mb-4 text-base font-bold">Accès rapides</h2>
        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap">
          <button type="button" className={btnPrimary} onClick={() => void navigate({ to: "/tournee" })}>
            Démarrer une tournée
          </button>
          <button type="button" className={btnSecondary} onClick={() => void navigate({ to: "/constats" })}>
            Signaler un incident
          </button>
          <button type="button" className={btnSecondary} onClick={() => void navigate({ to: "/points" })}>
            Consulter les points
          </button>
        </div>
      </section>
    </>
  );
}
