import { useMemo, useState } from "react";
import { SECTORS, urgencyScore, type Incident } from "@/lib/collecte/config";
import {
  rankCandidates,
  remainingLabel,
  sortIncidentsForDispatch,
  type AgentLike,
  type TeamLike,
} from "@/lib/collecte/dispatch";
import { assignIncident, toast, updateIncidentStatus } from "@/lib/collecte/store";
import {
  PageHeader,
  Pill,
  btnPrimary,
  btnSecondary,
  btnSmall,
  fieldClass,
  useCollecte,
} from "./ui";

export function DispatchPage() {
  const data = useCollecte();
  const [sector, setSector] = useState("Tous");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const now = Date.now();

  const teams: TeamLike[] = (data.teams ?? []).map((t) => ({
    id: t.id,
    name: t.name,
    sector: t.sector,
    openLoad: (data.incidents ?? []).filter(
      (i) =>
        i.assignedTeamId === t.id &&
        i.status !== "clôturé" &&
        i.status !== "cloture" &&
        i.status !== "annule",
    ).length,
  }));

  const agents: AgentLike[] = [];

  const list = useMemo(() => {
    let rows = sortIncidentsForDispatch(data.incidents ?? [], now);
    if (sector !== "Tous") rows = rows.filter((i) => i.sector === sector);
    return rows;
  }, [data.incidents, sector, now]);

  const selected = list.find((i) => i.id === selectedId) ?? null;
  const candidates = selected ? rankCandidates(selected, teams, agents, 6) : [];

  const assign = (
    inc: Incident,
    teamId: string,
    teamName: string,
    basis: "live-gps" | "sector-estimate" | "manual",
  ) => {
    assignIncident(inc.id, { teamId, teamName, basis });
    toast(`Constat ${inc.id} → ${teamName}`);
  };

  return (
    <>
      <PageHeader
        eyebrow="Opérations"
        title="Dispatch"
        sub="Affectation intelligente des constats selon urgence, proximité et charge"
      />

      <div className="mb-4 flex flex-wrap items-end gap-3">
        <label className="grid gap-1 text-xs font-bold text-muted">
          Secteur
          <select className={fieldClass} value={sector} onChange={(e) => setSector(e.target.value)}>
            <option>Tous</option>
            {SECTORS.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </label>
        <p className="text-sm text-muted">
          <strong>{list.length}</strong> constat{list.length > 1 ? "s" : ""} ouvert
          {list.length > 1 ? "s" : ""}
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <section className="space-y-3 lg:col-span-3">
          {list.length === 0 && (
            <div className="rounded-2xl border border-line bg-surface p-6 text-center text-muted">
              Aucun constat ouvert à dispatcher.
            </div>
          )}
          {list.map((inc) => {
            const rem = remainingLabel(inc.dueAt, now);
            const active = selectedId === inc.id;
            const score = urgencyScore(inc, now);
            return (
              <button
                key={inc.id}
                type="button"
                onClick={() => setSelectedId(inc.id)}
                className={`w-full rounded-2xl border p-4 text-left shadow-sm transition ${
                  active ? "border-pine bg-mint/40" : "border-line bg-surface hover:border-pine-2"
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <b className="font-display text-sm">{inc.type}</b>
                    <p className="text-xs text-muted">
                      {inc.sector} · {inc.id} · priorité {inc.priority ?? "—"}
                      {inc.slaMinutes ? ` · SLA ${inc.slaMinutes} min` : ""}
                    </p>
                  </div>
                  <span
                    className={`rounded-full px-2 py-1 text-xs font-extrabold ${
                      rem.kind === "overdue"
                        ? "bg-red-100 text-red-800"
                        : rem.kind === "critical"
                          ? "bg-amber-100 text-amber-900"
                          : "bg-emerald-100 text-emerald-800"
                    }`}
                  >
                    {rem.kind === "overdue" ? "⚠ " : ""}
                    {rem.text}
                  </span>
                </div>
                <p className="mt-2 line-clamp-2 text-sm">{inc.description}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Pill
                    kind={
                      inc.status === "en_intervention" || inc.status === "en intervention"
                        ? "priority"
                        : "toCollect"
                    }
                  >
                    {inc.status}
                  </Pill>
                  {inc.assignedTeamName && (
                    <span className="text-xs font-semibold text-muted">→ {inc.assignedTeamName}</span>
                  )}
                  <span className="text-xs text-faint">score {Math.round(score)}</span>
                </div>
              </button>
            );
          })}
        </section>

        <aside className="lg:col-span-2">
          <div className="sticky top-24 rounded-2xl border border-line bg-surface p-4 shadow-sm">
            {!selected ? (
              <p className="text-sm text-muted">
                Sélectionnez un constat pour voir les propositions d&apos;affectation.
              </p>
            ) : (
              <>
                <h2 className="mb-1 font-display text-base font-bold">Affecter</h2>
                <p className="mb-3 text-xs text-muted">
                  {selected.type} · {selected.sector}
                  {selected.assignmentBasis ? ` · base : ${selected.assignmentBasis}` : ""}
                </p>

                {candidates.length === 0 ? (
                  <p className="text-sm text-muted">
                    Aucune équipe configurée. Ajoutez des équipes (secteur + chef) pour activer le
                    ranking.
                  </p>
                ) : (
                  <ul className="space-y-2">
                    {candidates.map((c, idx) => (
                      <li
                        key={`${c.team.id}-${c.agent?.id ?? "t"}-${idx}`}
                        className="rounded-xl border border-line p-3"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <b className="text-sm">{c.agent?.name ?? c.team.name}</b>
                            <p className="text-xs text-muted">
                              {c.team.name} · {c.team.sector}
                            </p>
                            <p className="mt-1 text-xs">
                              ≈ {c.distanceKm.toFixed(1)} km · charge {c.load} ·{" "}
                              <span className="font-semibold">
                                {c.basis === "live-gps" ? "GPS live" : "centre secteur"}
                              </span>
                            </p>
                          </div>
                          {idx === 0 && (
                            <span className="rounded-full bg-mint px-2 py-0.5 text-[10px] font-extrabold text-pine">
                              BEST
                            </span>
                          )}
                        </div>
                        <button
                          type="button"
                          className={`${btnSmall} mt-2 w-full`}
                          onClick={() =>
                            assign(
                              selected,
                              c.team.id,
                              c.agent ? `${c.agent.name} (${c.team.name})` : c.team.name,
                              c.basis,
                            )
                          }
                        >
                          Affecter
                        </button>
                      </li>
                    ))}
                  </ul>
                )}

                <div className="mt-4 flex flex-col gap-2">
                  <button
                    type="button"
                    className={btnSecondary}
                    onClick={() => updateIncidentStatus(selected.id, "en_intervention")}
                  >
                    Marquer en intervention
                  </button>
                  <button
                    type="button"
                    className={btnPrimary}
                    onClick={() => {
                      updateIncidentStatus(selected.id, "clôturé");
                      toast("Constat clôturé");
                      setSelectedId(null);
                    }}
                  >
                    Clôturer
                  </button>
                </div>
              </>
            )}
          </div>
        </aside>
      </div>
    </>
  );
}
