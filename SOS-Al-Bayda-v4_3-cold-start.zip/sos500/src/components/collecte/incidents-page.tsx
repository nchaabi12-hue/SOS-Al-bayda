import { useEffect, useRef, useState } from "react";
import { INCIDENT_STATUS, INCIDENT_TYPES, SECTORS, type Incident } from "@/lib/collecte/config";
import { compressAnomalyPhoto, dataUrlByteLength } from "@/lib/collecte/photos";
import { getPosition } from "@/lib/collecte/geo";
import {
  addIncident,
  attachIncidentPhoto,
  closeIncident,
  updateIncidentStatus,
  formatDateTime,
  getIncidentPhoto,
  toast,
} from "@/lib/collecte/store";
import { Modal, PageHeader, Pill, btnPrimary, btnSecondary, btnSmall, fieldClass, useCollecte } from "./ui";

export function IncidentsPage() {
  const { incidents } = useCollecte();
  const [sector, setSector] = useState<string>(SECTORS[0]);
  const [type, setType] = useState<string>(INCIDENT_TYPES[0]);
  const [description, setDescription] = useState("");
  const [photo, setPhoto] = useState("");
  const [lat, setLat] = useState<number | "">("");
  const [lng, setLng] = useState<number | "">("");
  const [gpsBusy, setGpsBusy] = useState(false);
  const [saving, setSaving] = useState(false);
  const [viewer, setViewer] = useState<string | null>(null);
  const [clock, setClock] = useState(Date.now());

  useEffect(() => {
    const timer = window.setInterval(() => setClock(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, []);

  const history = [...incidents].sort((a, b) => String(b.date).localeCompare(String(a.date)));

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      setPhoto((await compressAnomalyPhoto(file)).dataUrl);
    } catch {
      toast("Image illisible", "error");
    }
  };

  const grabGps = async () => {
    setGpsBusy(true);
    try {
      const pos = await getPosition();
      setLat(pos.lat);
      setLng(pos.lng);
      toast("Position enregistrée dans le formulaire");
    } catch (err) {
      const message =
        err instanceof Error && err.message === "unavailable"
          ? "GPS non disponible"
          : "Position GPS inaccessible";
      toast(message, "error");
    } finally {
      setGpsBusy(false);
    }
  };

  const submit = async () => {
    const text = description.trim();
    if (!text) {
      toast("La description est obligatoire", "error");
      return;
    }
    setSaving(true);
    try {
      await addIncident({ sector, type, description: text, photo, lat, lng });
      setDescription("");
      setPhoto("");
      setLat("");
      setLng("");
      toast("Constat enregistré");
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <PageHeader
        eyebrow="Terrain"
        title="Constats & incidents"
        sub="Enregistrer et suivre les anomalies opérationnelles — photo à la création ou sur le terrain"
      />

      <section className="mb-4 rounded-2xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-950">
        <strong>Photo d&apos;anomalie :</strong> joignable à la création du constat, ou plus tard par le
        chef de secteur / chef d&apos;équipe via <em>Ajouter photo</em> ou <em>Photo</em> dans
        l&apos;historique. SLA selon le type d&apos;anomalie.
      </section>

      <section className="rounded-2xl border border-line bg-surface p-4 shadow-sm md:p-5">
        <h2 className="mb-4 text-base font-bold">Nouveau constat</h2>
        <form
          className="grid gap-3 sm:grid-cols-2"
          onSubmit={(e) => {
            e.preventDefault();
            void submit();
          }}
        >
          <label className="grid gap-1 text-xs font-bold text-muted">
            Secteur
            <select className={fieldClass} value={sector} onChange={(e) => setSector(e.target.value)}>
              {SECTORS.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
          <label className="grid gap-1 text-xs font-bold text-muted">
            Type
            <select className={fieldClass} value={type} onChange={(e) => setType(e.target.value)}>
              {INCIDENT_TYPES.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </label>
          <label className="grid gap-1 text-xs font-bold text-muted sm:col-span-2">
            Description
            <textarea
              className={fieldClass}
              rows={3}
              required
              placeholder="Décrire précisément l'anomalie..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </label>
          <div className="grid gap-2 text-xs font-bold text-muted sm:col-span-2">
            Photo d&apos;anomalie
            <div className="flex flex-wrap gap-2">
              <label className={`${btnSecondary} cursor-pointer`}>
                Prendre / choisir une photo
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="sr-only"
                  onChange={(e) => {
                    void onFile(e.target.files?.[0]);
                    e.target.value = "";
                  }}
                />
              </label>
              {photo ? (
                <button type="button" className={btnSmall} onClick={() => setPhoto("")}>
                  Retirer
                </button>
              ) : null}
            </div>
            {photo ? (
              <>
                <img src={photo} alt="Aperçu de la photo" className="max-h-52 w-full rounded-xl object-cover" />
                <small className="font-medium text-faint">
                  Compressée · ~{Math.max(1, Math.round(dataUrlByteLength(photo) / 1024))} Ko
                </small>
              </>
            ) : null}
          </div>
          <div className="grid gap-2 text-xs font-bold text-muted sm:col-span-2">
            Position GPS
            <button type="button" className={btnSecondary} disabled={gpsBusy} onClick={() => void grabGps()}>
              {gpsBusy ? "Recherche…" : "Récupérer ma position"}
            </button>
            <small className="font-medium text-faint">
              {lat !== "" && lng !== ""
                ? `GPS récupéré (${Number(lat).toFixed(5)}, ${Number(lng).toFixed(5)})`
                : "Position non récupérée"}
            </small>
          </div>
          <div className="sm:col-span-2">
            <button type="submit" className={btnPrimary} disabled={saving}>
              Enregistrer le constat
            </button>
          </div>
        </form>
      </section>

      <section className="mt-5 rounded-2xl border border-line bg-surface p-4 shadow-sm md:p-5">
        <h2 className="mb-4 text-base font-bold">Historique ({incidents.length})</h2>
        {history.length === 0 ? (
          <p className="rounded-xl bg-paper px-4 py-8 text-center text-muted">Aucun constat enregistré.</p>
        ) : (
          <ul className="divide-y divide-line">
            {history.map((t) => (
              <IncidentRow
                key={t.id}
                incident={t}
                onStart={() => {
                  updateIncidentStatus(t.id, "en_intervention");
                  toast("Constat marqué en intervention dans le suivi");
                }}
                onClose={() => {
                  closeIncident(t.id);
                  toast("Constat clôturé");
                }}
                onPhoto={() => setViewer(t.id)}
                now={clock}
              />
            ))}
          </ul>
        )}
      </section>

      {viewer ? (
        <PhotoDialog
          id={viewer}
          incidents={incidents}
          onClose={() => setViewer(null)}
        />
      ) : null}
    </>
  );
}

function IncidentRow({
  incident: t,
  onStart,
  onClose,
  onPhoto,
  now,
}: {
  incident: Incident;
  onStart: () => void;
  onClose: () => void;
  onPhoto: () => void;
  now: number;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const open = t.status !== INCIDENT_STATUS.closed;
  const inProgress = t.status === "en intervention" || t.status === "en_intervention";
  const remaining = t.dueAt ? new Date(t.dueAt).getTime() - now : null;
  const overdue = open && remaining !== null && remaining <= 0;
  const slaText =
    remaining === null
      ? "Échéance non définie"
      : overdue
        ? `Délai dépassé de ${Math.floor(-remaining / 3_600_000)} h ${Math.floor((-remaining % 3_600_000) / 60_000)} min`
        : `Intervention avant ${new Date(t.dueAt!).toLocaleTimeString("fr-FR", {
            hour: "2-digit",
            minute: "2-digit",
          })} · ${Math.floor(remaining / 3_600_000)} h ${Math.floor((remaining % 3_600_000) / 60_000)} min restantes`;
  const hasPhoto = Boolean(t.photo || t.photoId || t.hasPhoto);
  const hasGps = t.lat !== "" && t.lat != null && t.lng !== "" && t.lng != null;

  const onAttach = async (file: File | undefined) => {
    if (!file) return;
    setUploading(true);
    try {
      const { dataUrl } = await compressAnomalyPhoto(file);
      await attachIncidentPhoto(t.id, dataUrl);
      toast(hasPhoto ? "Photo d'anomalie remplacée" : "Photo d'anomalie ajoutée");
    } catch {
      toast("Impossible d'enregistrer la photo", "error");
    } finally {
      setUploading(false);
    }
  };

  return (
    <li className="flex flex-col gap-2 py-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <p className="text-xs font-semibold text-faint">{formatDateTime(t.date)}</p>
        <p className="font-bold">
          {t.type} · {t.sector}
        </p>
        <p className="text-sm">{t.description}</p>
        <p
          className={`mt-1 inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-extrabold ${
            overdue
              ? "bg-red-100 text-red-800"
              : open
                ? "bg-amber-100 text-amber-900"
                : "bg-emerald-100 text-emerald-800"
          }`}
        >
          {overdue
            ? "⚠ DÉLAI DÉPASSÉ"
            : inProgress
              ? "↗ INTERVENTION EN COURS"
              : open
                ? "● À INTERVENIR"
                : "✓ INTERVENTION CLÔTURÉE"}{" "}
          · {slaText}
        </p>
        {t.assignedTeamName ? (
          <p className="mt-1 text-xs font-semibold text-muted">
            Équipe proposée : {t.assignedTeamName} (proximité estimée par secteur)
          </p>
        ) : (
          <p className="mt-1 text-xs text-muted">
            Aucune équipe affectée : configurer les équipes d&apos;intervention.
          </p>
        )}
        {hasGps ? (
          <p className="text-xs text-muted">
            GPS {Number(t.lat).toFixed(5)}, {Number(t.lng).toFixed(5)}
          </p>
        ) : null}
        {!hasPhoto ? (
          <p className="mt-1 text-xs font-semibold text-amber-800">Pas encore de photo d&apos;anomalie</p>
        ) : null}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Pill kind={open ? "priority" : "collected"}>{t.status}</Pill>
        {hasPhoto ? (
          <button type="button" className={btnSmall} onClick={onPhoto}>
            Voir photo
          </button>
        ) : null}
        <label className={`${btnSmall} cursor-pointer ${uploading ? "opacity-50" : ""}`}>
          {uploading ? "Envoi…" : hasPhoto ? "Remplacer photo" : "Ajouter photo"}
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="sr-only"
            disabled={uploading}
            onChange={(e) => {
              void onAttach(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
        </label>
        {open && !inProgress ? (
          <button type="button" className={`${btnSmall} border border-amber-400 text-amber-900`} onClick={onStart}>
            ⚑ Signaler à l&apos;équipe
          </button>
        ) : null}
        {open ? (
          <button type="button" className={btnSmall} onClick={onClose}>
            Clôturer
          </button>
        ) : null}
      </div>
    </li>
  );
}

function PhotoDialog({
  id,
  incidents,
  onClose,
}: {
  id: string;
  incidents: Incident[];
  onClose: () => void;
}) {
  const inc = incidents.find((i) => i.id === id);
  const [src, setSrc] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    let cancel = false;
    if (!inc) {
      setSrc("");
      return;
    }
    void getIncidentPhoto(inc).then((s) => {
      if (!cancel) setSrc(s);
    });
    return () => {
      cancel = true;
    };
  }, [inc]);

  const onReplace = async (file: File | undefined) => {
    if (!file || !inc) return;
    setUploading(true);
    try {
      const { dataUrl } = await compressAnomalyPhoto(file);
      await attachIncidentPhoto(inc.id, dataUrl);
      setSrc(dataUrl);
      toast("Photo d'anomalie mise à jour");
    } catch {
      toast("Impossible d'enregistrer la photo", "error");
    } finally {
      setUploading(false);
    }
  };

  return (
    <Modal
      title="Photo d'anomalie"
      onClose={onClose}
      footer={
        <>
          <label className={`${btnSecondary} cursor-pointer ${uploading ? "opacity-50" : ""}`}>
            {uploading ? "Envoi…" : src ? "Remplacer la photo" : "Ajouter une photo"}
            <input
              type="file"
              accept="image/*"
              capture="environment"
              className="sr-only"
              disabled={uploading}
              onChange={(e) => {
                void onReplace(e.target.files?.[0]);
                e.target.value = "";
              }}
            />
          </label>
          <button type="button" className={btnPrimary} onClick={onClose}>
            Fermer
          </button>
        </>
      }
    >
      {src === null ? (
        <p className="text-muted">Chargement…</p>
      ) : src ? (
        <img src={src} alt="Photo de l'anomalie" className="w-full rounded-xl" />
      ) : (
        <p className="text-muted">Aucune photo pour ce constat. Utilisez le bouton ci-dessous pour en ajouter une.</p>
      )}
    </Modal>
  );
}
