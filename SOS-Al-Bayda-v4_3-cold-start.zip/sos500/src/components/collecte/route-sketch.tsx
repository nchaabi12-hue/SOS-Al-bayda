import { DEPOT, MAP_BBOX, type Point } from "@/lib/collecte/config";

const W = 640;
const H = 380;
const PAD = 36;

export function RouteSketch({ points, route }: { points: Point[]; route: Point[] }) {
  const [west, south, east, north] = MAP_BBOX;
  const X = (lng: number) => PAD + ((lng - west) / (east - west)) * (W - PAD * 2);
  const Y = (lat: number) => PAD + ((north - lat) / (north - south)) * (H - PAD * 2);
  const onRoute = new Set(route.map((p) => p.id));
  const line =
    route.length > 0
      ? [DEPOT, ...route, DEPOT]
          .map((p, i) => `${i === 0 ? "M" : "L"} ${X(p.lng).toFixed(1)} ${Y(p.lat).toFixed(1)}`)
          .join(" ")
      : "";

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full rounded-2xl bg-mint" role="img" aria-label="Schéma géographique des points">
      <rect width={W} height={H} fill="var(--color-mint)" />
      {[0.25, 0.5, 0.75].map((t) => (
        <g key={t} stroke="var(--color-line)" strokeWidth="1">
          <line x1={PAD} x2={W - PAD} y1={PAD + t * (H - PAD * 2)} y2={PAD + t * (H - PAD * 2)} />
          <line y1={PAD} y2={H - PAD} x1={PAD + t * (W - PAD * 2)} x2={PAD + t * (W - PAD * 2)} />
        </g>
      ))}
      {line ? <path d={line} fill="none" stroke="var(--color-pine)" strokeWidth="2.25" strokeLinejoin="round" /> : null}
      {points
        .filter((p) => !onRoute.has(p.id))
        .map((p) => (
          <circle key={p.id} cx={X(p.lng)} cy={Y(p.lat)} r="3.5" fill="var(--color-muted)" opacity="0.7">
            <title>{p.name}</title>
          </circle>
        ))}
      {route.map((p, i) => (
        <g key={p.id}>
          <circle cx={X(p.lng)} cy={Y(p.lat)} r="10" fill="var(--color-pine)" />
          <text x={X(p.lng)} y={Y(p.lat) + 3.5} textAnchor="middle" fontSize="10" fontWeight="700" fill="white">
            {i + 1}
          </text>
          <title>{`${i + 1}. ${p.name}`}</title>
        </g>
      ))}
      <rect x={X(DEPOT.lng) - 6} y={Y(DEPOT.lat) - 6} width="12" height="12" rx="2" fill="var(--color-ink)" />
      <text x={X(DEPOT.lng) + 12} y={Y(DEPOT.lat) + 4} fontSize="12" fontWeight="700" fill="var(--color-ink)">
        Dépôt
      </text>
    </svg>
  );
}
