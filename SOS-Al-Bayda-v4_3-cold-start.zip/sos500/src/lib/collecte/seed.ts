import { SECTOR_INFO, SECTORS, type Point } from "./config";

/** 63 points initiaux, complétés à 500 emplacements GPS provisoires à confirmer. */
export const SEED_POINTS: Array<
  Pick<Point, "id" | "name" | "neighborhood" | "address" | "lat" | "lng" | "status" | "inTodayTour">
> = [
  { id: "p1", name: "Benne Belvédère 01", neighborhood: "Belvédère", address: "Belvédère – point 01", lat: 33.59217, lng: -7.5893, status: "toCollect", inTodayTour: true },
  { id: "p2", name: "Benne Belvédère 02", neighborhood: "Belvédère", address: "Belvédère – point 02", lat: 33.58951, lng: -7.58407, status: "toCollect", inTodayTour: true },
  { id: "p3", name: "Conteneur Belvédère 03", neighborhood: "Belvédère", address: "Belvédère – point 03", lat: 33.59548, lng: -7.58334, status: "priority", inTodayTour: true },
  { id: "p4", name: "Benne Belvédère 04", neighborhood: "Belvédère", address: "Belvédère – point 04", lat: 33.59159, lng: -7.5863, status: "toCollect", inTodayTour: true },
  { id: "p5", name: "Benne Belvédère 05", neighborhood: "Belvédère", address: "Belvédère – point 05", lat: 33.59146, lng: -7.58421, status: "toCollect", inTodayTour: true },
  { id: "p6", name: "Conteneur Belvédère 06", neighborhood: "Belvédère", address: "Belvédère – point 06", lat: 33.59381, lng: -7.58624, status: "toCollect", inTodayTour: true },
  { id: "p7", name: "Benne Belvédère 07", neighborhood: "Belvédère", address: "Belvédère – point 07", lat: 33.58975, lng: -7.58867, status: "toCollect", inTodayTour: true },
  { id: "p8", name: "Benne Belvédère 08", neighborhood: "Belvédère", address: "Belvédère – point 08", lat: 33.59012, lng: -7.58676, status: "toCollect", inTodayTour: true },
  { id: "p9", name: "Conteneur Belvédère 09", neighborhood: "Belvédère", address: "Belvédère – point 09", lat: 33.59407, lng: -7.59185, status: "toCollect", inTodayTour: true },
  { id: "p10", name: "Benne Belvédère 10", neighborhood: "Belvédère", address: "Belvédère – point 10", lat: 33.59219, lng: -7.59078, status: "toCollect", inTodayTour: true },
  { id: "p11", name: "Benne Belvédère 11", neighborhood: "Belvédère", address: "Belvédère – point 11", lat: 33.59652, lng: -7.58818, status: "toCollect", inTodayTour: true },
  { id: "p12", name: "Conteneur Belvédère 12", neighborhood: "Belvédère", address: "Belvédère – point 12", lat: 33.59611, lng: -7.58558, status: "toCollect", inTodayTour: true },
  { id: "p13", name: "Benne Belvédère 13", neighborhood: "Belvédère", address: "Belvédère – point 13", lat: 33.59424, lng: -7.58351, status: "toCollect", inTodayTour: true },
  { id: "p14", name: "Benne Belvédère 14", neighborhood: "Belvédère", address: "Belvédère – point 14", lat: 33.58947, lng: -7.59194, status: "toCollect", inTodayTour: true },
  { id: "p15", name: "Benne Roches Noires 01", neighborhood: "Roches Noires", address: "Roches Noires – point 01", lat: 33.60142, lng: -7.57776, status: "toCollect", inTodayTour: true },
  { id: "p16", name: "Benne Roches Noires 02", neighborhood: "Roches Noires", address: "Roches Noires – point 02", lat: 33.59764, lng: -7.58478, status: "toCollect", inTodayTour: true },
  { id: "p17", name: "Conteneur Roches Noires 03", neighborhood: "Roches Noires", address: "Roches Noires – point 03", lat: 33.59996, lng: -7.58523, status: "priority", inTodayTour: true },
  { id: "p18", name: "Benne Roches Noires 04", neighborhood: "Roches Noires", address: "Roches Noires – point 04", lat: 33.60299, lng: -7.57343, status: "toCollect", inTodayTour: true },
  { id: "p19", name: "Benne Roches Noires 05", neighborhood: "Roches Noires", address: "Roches Noires – point 05", lat: 33.59939, lng: -7.57793, status: "toCollect", inTodayTour: true },
  { id: "p20", name: "Conteneur Roches Noires 06", neighborhood: "Roches Noires", address: "Roches Noires – point 06", lat: 33.5984, lng: -7.58115, status: "toCollect", inTodayTour: true },
  { id: "p21", name: "Benne Roches Noires 07", neighborhood: "Roches Noires", address: "Roches Noires – point 07", lat: 33.59839, lng: -7.57711, status: "toCollect", inTodayTour: true },
  { id: "p22", name: "Benne Roches Noires 08", neighborhood: "Roches Noires", address: "Roches Noires – point 08", lat: 33.6016, lng: -7.57399, status: "toCollect", inTodayTour: true },
  { id: "p23", name: "Conteneur Roches Noires 09", neighborhood: "Roches Noires", address: "Roches Noires – point 09", lat: 33.59967, lng: -7.58092, status: "toCollect", inTodayTour: true },
  { id: "p24", name: "Benne Roches Noires 10", neighborhood: "Roches Noires", address: "Roches Noires – point 10", lat: 33.60346, lng: -7.58156, status: "toCollect", inTodayTour: true },
  { id: "p25", name: "Benne Roches Noires 11", neighborhood: "Roches Noires", address: "Roches Noires – point 11", lat: 33.59952, lng: -7.57341, status: "toCollect", inTodayTour: true },
  { id: "p26", name: "Conteneur Roches Noires 12", neighborhood: "Roches Noires", address: "Roches Noires – point 12", lat: 33.60179, lng: -7.58164, status: "toCollect", inTodayTour: true },
  { id: "p27", name: "Benne Roches Noires 13", neighborhood: "Roches Noires", address: "Roches Noires – point 13", lat: 33.59835, lng: -7.57458, status: "toCollect", inTodayTour: true },
  { id: "p28", name: "Benne Roches Noires 14", neighborhood: "Roches Noires", address: "Roches Noires – point 14", lat: 33.60293, lng: -7.58448, status: "toCollect", inTodayTour: true },
  { id: "p29", name: "Benne Hay Adil 01", neighborhood: "Hay Adil", address: "Hay Adil – point 01", lat: 33.58914, lng: -7.55649, status: "priority", inTodayTour: true },
  { id: "p30", name: "Benne Hay Adil 02", neighborhood: "Hay Adil", address: "Hay Adil – point 02", lat: 33.58558, lng: -7.554, status: "toCollect", inTodayTour: true },
  { id: "p31", name: "Conteneur Hay Adil 03", neighborhood: "Hay Adil", address: "Hay Adil – point 03", lat: 33.58706, lng: -7.55321, status: "toCollect", inTodayTour: true },
  { id: "p32", name: "Benne Hay Adil 04", neighborhood: "Hay Adil", address: "Hay Adil – point 04", lat: 33.58943, lng: -7.55814, status: "toCollect", inTodayTour: true },
  { id: "p33", name: "Benne Hay Adil 05", neighborhood: "Hay Adil", address: "Hay Adil – point 05", lat: 33.58477, lng: -7.55926, status: "toCollect", inTodayTour: true },
  { id: "p34", name: "Conteneur Hay Adil 06", neighborhood: "Hay Adil", address: "Hay Adil – point 06", lat: 33.58998, lng: -7.5544, status: "toCollect", inTodayTour: true },
  { id: "p35", name: "Benne Hay Adil 07", neighborhood: "Hay Adil", address: "Hay Adil – point 07", lat: 33.58944, lng: -7.55073, status: "toCollect", inTodayTour: true },
  { id: "p36", name: "Benne Hay Adil 08", neighborhood: "Hay Adil", address: "Hay Adil – point 08", lat: 33.58711, lng: -7.5513, status: "toCollect", inTodayTour: true },
  { id: "p37", name: "Conteneur Hay Adil 09", neighborhood: "Hay Adil", address: "Hay Adil – point 09", lat: 33.58765, lng: -7.55592, status: "toCollect", inTodayTour: true },
  { id: "p38", name: "Benne Hay Adil 10", neighborhood: "Hay Adil", address: "Hay Adil – point 10", lat: 33.58538, lng: -7.55555, status: "toCollect", inTodayTour: true },
  { id: "p39", name: "Benne Hay Adil 11", neighborhood: "Hay Adil", address: "Hay Adil – point 11", lat: 33.58766, lng: -7.55804, status: "toCollect", inTodayTour: true },
  { id: "p40", name: "Benne Aïn Borja 01", neighborhood: "Aïn Borja", address: "Aïn Borja – point 01", lat: 33.59312, lng: -7.56492, status: "toCollect", inTodayTour: true },
  { id: "p41", name: "Benne Aïn Borja 02", neighborhood: "Aïn Borja", address: "Aïn Borja – point 02", lat: 33.59301, lng: -7.56926, status: "toCollect", inTodayTour: true },
  { id: "p42", name: "Conteneur Aïn Borja 03", neighborhood: "Aïn Borja", address: "Aïn Borja – point 03", lat: 33.59288, lng: -7.56658, status: "toCollect", inTodayTour: true },
  { id: "p43", name: "Benne Aïn Borja 04", neighborhood: "Aïn Borja", address: "Aïn Borja – point 04", lat: 33.59545, lng: -7.56673, status: "toCollect", inTodayTour: true },
  { id: "p44", name: "Benne Aïn Borja 05", neighborhood: "Aïn Borja", address: "Aïn Borja – point 05", lat: 33.59315, lng: -7.5626, status: "priority", inTodayTour: true },
  { id: "p45", name: "Conteneur Aïn Borja 06", neighborhood: "Aïn Borja", address: "Aïn Borja – point 06", lat: 33.59583, lng: -7.56245, status: "toCollect", inTodayTour: true },
  { id: "p46", name: "Benne Aïn Borja 07", neighborhood: "Aïn Borja", address: "Aïn Borja – point 07", lat: 33.5976, lng: -7.5669, status: "toCollect", inTodayTour: true },
  { id: "p47", name: "Benne Aïn Borja 08", neighborhood: "Aïn Borja", address: "Aïn Borja – point 08", lat: 33.59508, lng: -7.56549, status: "toCollect", inTodayTour: true },
  { id: "p48", name: "Conteneur Aïn Borja 09", neighborhood: "Aïn Borja", address: "Aïn Borja – point 09", lat: 33.59469, lng: -7.56869, status: "toCollect", inTodayTour: true },
  { id: "p49", name: "Benne Aïn Borja 10", neighborhood: "Aïn Borja", address: "Aïn Borja – point 10", lat: 33.59797, lng: -7.56348, status: "toCollect", inTodayTour: true },
  { id: "p50", name: "Benne Aïn Borja 11", neighborhood: "Aïn Borja", address: "Aïn Borja – point 11", lat: 33.59698, lng: -7.56534, status: "toCollect", inTodayTour: true },
  { id: "p51", name: "Point d'apport Hay Mohammadi 01", neighborhood: "Hay Mohammadi", address: "Hay Mohammadi – repère 01", lat: 33.5904, lng: -7.5634, status: "toCollect", inTodayTour: true },
  { id: "p52", name: "Point d'apport Hay Mohammadi 02", neighborhood: "Hay Mohammadi", address: "Hay Mohammadi – repère 02", lat: 33.5876, lng: -7.5598, status: "toCollect", inTodayTour: true },
  { id: "p53", name: "Point d'apport Aïn Sebaâ 01", neighborhood: "Aïn Sebaâ", address: "Aïn Sebaâ – repère 01", lat: 33.6048, lng: -7.5356, status: "toCollect", inTodayTour: true },
  { id: "p54", name: "Point d'apport Aïn Sebaâ 02", neighborhood: "Aïn Sebaâ", address: "Aïn Sebaâ – repère 02", lat: 33.6016, lng: -7.5288, status: "priority", inTodayTour: true },
  { id: "p55", name: "Point d'apport Aïn Sebaâ 03", neighborhood: "Aïn Sebaâ", address: "Aïn Sebaâ – repère 03", lat: 33.6072, lng: -7.5412, status: "toCollect", inTodayTour: true },
  { id: "p56", name: "Point d'apport Al Bayda 01", neighborhood: "Al Bayda", address: "Al Bayda – repère 01", lat: 33.6002, lng: -7.5504, status: "toCollect", inTodayTour: true },
  { id: "p57", name: "Point d'apport Al Bayda 02", neighborhood: "Al Bayda", address: "Al Bayda – repère 02", lat: 33.5981, lng: -7.5462, status: "toCollect", inTodayTour: true },
  { id: "p58", name: "Point d'apport Sidi Bernoussi 01", neighborhood: "Sidi Bernoussi", address: "Sidi Bernoussi – repère 01", lat: 33.6144, lng: -7.4968, status: "toCollect", inTodayTour: true },
  { id: "p59", name: "Point d'apport Sidi Bernoussi 02", neighborhood: "Sidi Bernoussi", address: "Sidi Bernoussi – repère 02", lat: 33.6186, lng: -7.4884, status: "priority", inTodayTour: true },
  { id: "p60", name: "Point d'apport Sidi Bernoussi 03", neighborhood: "Sidi Bernoussi", address: "Sidi Bernoussi – repère 03", lat: 33.6118, lng: -7.5022, status: "toCollect", inTodayTour: true },
  { id: "p61", name: "Point d'apport Sidi Moumen 01", neighborhood: "Sidi Moumen", address: "Sidi Moumen – repère 01", lat: 33.5876, lng: -7.5088, status: "toCollect", inTodayTour: true },
  { id: "p62", name: "Point d'apport Sidi Moumen 02", neighborhood: "Sidi Moumen", address: "Sidi Moumen – repère 02", lat: 33.5834, lng: -7.5016, status: "toCollect", inTodayTour: true },
  { id: "p63", name: "Point d'apport Sidi Moumen 03", neighborhood: "Sidi Moumen", address: "Sidi Moumen – repère 03", lat: 33.5908, lng: -7.5124, status: "toCollect", inTodayTour: true },
];

/**
 * Complète le catalogue à 500 emplacements de travail.
 * Les coordonnées générées autour des centres de secteurs sont provisoires :
 * elles doivent être confirmées sur le terrain avant toute intervention réelle.
 */
const generatedLocations = Array.from({ length: Math.max(0, 500 - SEED_POINTS.length) }, (_, index) => {
  const sector = SECTORS[index % SECTORS.length];
  const info = SECTOR_INFO[sector];
  const n = index + 1;
  // Répartition déterministe en spirale compacte autour du centre du secteur.
  const angle = n * 2.399963229728653;
  const radius = 0.0012 + (Math.sqrt(n) % 12) * 0.00013;
  const lat = (info?.lat ?? 33.5995) + Math.cos(angle) * radius;
  const lng = (info?.lng ?? -7.5488) + Math.sin(angle) * radius * 1.25;
  const id = `loc-${String(SEED_POINTS.length + n).padStart(3, "0")}`;
  return {
    id,
    name: `Emplacement à confirmer ${String(SEED_POINTS.length + n).padStart(3, "0")}`,
    neighborhood: sector,
    address: `${sector} — GPS provisoire à confirmer sur le terrain`,
    lat: Number(lat.toFixed(6)),
    lng: Number(lng.toFixed(6)),
    status: "toCollect" as const,
    inTodayTour: false,
  };
});

SEED_POINTS.push(...generatedLocations);

