import { SECTOR_INFO, urgencyScore, type Incident } from "./config";
import { haversine } from "./geo";

export type TeamLike = {
  id: string;
  name: string;
  sector: string;
  openLoad?: number;
  liveLat?: number;
  liveLng?: number;
};

export type AgentLike = {
  id: string;
  name: string;
  teamId: string;
  sector: string;
  liveLat?: number;
  liveLng?: number;
  openLoad?: number;
};

export type DispatchCandidate = {
  team: TeamLike;
  agent?: AgentLike;
  distanceKm: number;
  load: number;
  score: number;
  basis: "live-gps" | "sector-estimate";
};

function originOf(inc: Incident): { lat: number; lng: number } | null {
  if (typeof inc.lat === "number" && typeof inc.lng === "number") {
    return { lat: inc.lat, lng: inc.lng };
  }
  const c = SECTOR_INFO[inc.sector];
  return c ? { lat: c.lat, lng: c.lng } : null;
}

export function rankCandidates(
  incident: Incident,
  teams: TeamLike[],
  agents: AgentLike[] = [],
  limit = 5,
): DispatchCandidate[] {
  const origin = originOf(incident);
  if (!origin) return [];

  const candidates: DispatchCandidate[] = [];

  for (const agent of agents) {
    if (agent.liveLat == null || agent.liveLng == null) continue;
    const distanceKm = haversine(origin, { lat: agent.liveLat, lng: agent.liveLng }) / 1000;
    const load = agent.openLoad ?? 0;
    const team = teams.find((t) => t.id === agent.teamId);
    candidates.push({
      team: team ?? { id: agent.teamId, name: "Équipe", sector: agent.sector },
      agent,
      distanceKm,
      load,
      score: distanceKm * 1.2 + load * 0.8,
      basis: "live-gps",
    });
  }

  for (const team of teams) {
    const center = SECTOR_INFO[team.sector];
    if (!center) continue;
    if (candidates.some((c) => c.team.id === team.id && c.basis === "live-gps")) continue;
    const distanceKm = haversine(origin, center) / 1000;
    const load = team.openLoad ?? 0;
    candidates.push({
      team,
      distanceKm,
      load,
      score: distanceKm * 1.2 + load * 0.8 + 2,
      basis: "sector-estimate",
    });
  }

  return candidates.sort((a, b) => a.score - b.score).slice(0, limit);
}

export function sortIncidentsForDispatch(incidents: Incident[], now = Date.now()): Incident[] {
  const open = incidents.filter(
    (i) => i.status !== "clôturé" && i.status !== "cloture" && i.status !== "annule",
  );
  return [...open].sort((a, b) => urgencyScore(b, now) - urgencyScore(a, now));
}

export function remainingLabel(dueAt: string | undefined, now = Date.now()): {
  text: string;
  kind: "ok" | "critical" | "overdue" | "unknown";
} {
  if (!dueAt) return { text: "Échéance non définie", kind: "unknown" };
  const ms = new Date(dueAt).getTime() - now;
  if (ms <= 0) {
    const lateMin = Math.floor(-ms / 60_000);
    return { text: `Dépassé de ${lateMin} min`, kind: "overdue" };
  }
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  if (ms < 30 * 60_000) return { text: `${h > 0 ? `${h} h ` : ""}${m} min restantes`, kind: "critical" };
  return { text: `${h > 0 ? `${h} h ` : ""}${m} min restantes`, kind: "ok" };
}
