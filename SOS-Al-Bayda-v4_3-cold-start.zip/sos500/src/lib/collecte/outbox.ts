/**
 * File d'attente hors ligne (outbox) — logique pure, sans React ni serveur.
 *
 * Garanties :
 *  - une mutation par `id` (la plus récente remplace l'ancienne) ;
 *  - une mutation n'est retirée qu'APRÈS un envoi réussi, et seulement si
 *    elle n'a pas été remplacée pendant l'envoi (aucune perte si l'utilisateur
 *    agit pendant une synchro) ;
 *  - un seul envoi à la fois (single-flight) ;
 *  - 401 : on s'arrête, rien n'est perdu ;
 *  - refus définitif du serveur (droits, données invalides) : la mutation
 *    passe dans une liste « refusées » visible, elle ne boucle pas à l'infini.
 */

export type OutboxItem = {
  id: string;
  kind: string;
  queuedAt: string;
  /** Version de la mutation (change à chaque mise en file). */
  rev?: string;
  attempts?: number;
  lastError?: string;
  /** Identifiant de l'objet visé (point, constat…). */
  ref?: string;
  payload?: unknown;
  incidentId?: string;
  photoId?: string;
  /** Photo embarquée (fallback si IndexedDB indisponible). */
  dataUrl?: string;
};

export type KeyValueStore = {
  get(key: string): string | null;
  set(key: string, value: string): void;
};

export type OutboxOptions<T extends OutboxItem> = {
  storage: KeyValueStore;
  key: string;
  failedKey: string;
  send: (item: T) => Promise<void>;
  isUnauthorized?: (err: unknown) => boolean;
  isPermanent?: (err: unknown) => boolean;
  isOnline?: () => boolean;
  /** Ordre d'envoi : rang le plus bas d'abord (ex. constat avant photo). */
  rank?: (item: T) => number;
  onChange?: () => void;
};

export type FlushResult = {
  flushed: number;
  remaining: number;
  rejected: number;
  unauthorized: boolean;
  /** false si rien n'a été tenté (hors ligne, sans `force`). */
  ran: boolean;
};

const MAX_FAILED = 50;
let seq = 0;

const messageOf = (err: unknown) => (err instanceof Error ? err.message : String(err));

export function createOutbox<T extends OutboxItem>(opts: OutboxOptions<T>) {
  const { storage, key, failedKey } = opts;
  let inflight: Promise<FlushResult> | null = null;

  const readList = (k: string): T[] => {
    try {
      const raw = storage.get(k);
      if (!raw) return [];
      const value = JSON.parse(raw) as unknown;
      return Array.isArray(value) ? (value as T[]) : [];
    } catch {
      return [];
    }
  };

  const writeList = (k: string, list: T[]): boolean => {
    try {
      storage.set(k, JSON.stringify(list));
      return true;
    } catch {
      return false;
    }
  };

  const changed = () => opts.onChange?.();

  function read(): T[] {
    return readList(key);
  }

  function count(): number {
    return readList(key).length;
  }

  /** Met une mutation en file. Retourne false si le stockage est plein/indisponible. */
  function enqueue(item: T): boolean {
    const stamped = {
      ...item,
      queuedAt: item.queuedAt ?? new Date().toISOString(),
      rev: `${Date.now()}-${++seq}`,
      attempts: 0,
      lastError: undefined,
    } as T;
    const list = readList(key).filter((i) => i.id !== item.id);
    list.push(stamped);
    const ok = writeList(key, list);
    if (ok) changed();
    return ok;
  }

  function removeIfSame(item: T) {
    const list = readList(key);
    const next = list.filter((i) => !(i.id === item.id && i.rev === item.rev));
    if (next.length !== list.length) {
      writeList(key, next);
      changed();
    }
  }

  function markFailed(item: T, err: unknown) {
    const list = readList(key);
    const idx = list.findIndex((i) => i.id === item.id && i.rev === item.rev);
    if (idx < 0) return; // remplacée entre-temps : on ne touche pas à la nouvelle version
    list[idx] = { ...list[idx], attempts: (list[idx].attempts ?? 0) + 1, lastError: messageOf(err) };
    writeList(key, list);
    changed();
  }

  function moveToFailed(item: T, err: unknown) {
    removeIfSame(item);
    const failed = readList(failedKey);
    failed.push({ ...item, lastError: messageOf(err) });
    writeList(failedKey, failed.slice(-MAX_FAILED));
    changed();
  }

  async function run(): Promise<FlushResult> {
    const snapshot = readList(key);
    const ordered = opts.rank
      ? snapshot
          .map((item, index) => ({ item, index }))
          .sort((a, b) => opts.rank!(a.item) - opts.rank!(b.item) || a.index - b.index)
          .map((x) => x.item)
      : snapshot;

    let flushed = 0;
    let rejected = 0;
    let unauthorized = false;

    for (const queued of ordered) {
      // Relecture : la mutation a pu être remplacée ou retirée depuis le snapshot.
      const item = readList(key).find((i) => i.id === queued.id);
      if (!item) continue;
      try {
        await opts.send(item);
        removeIfSame(item);
        flushed += 1;
      } catch (err) {
        if (opts.isUnauthorized?.(err)) {
          unauthorized = true;
          break;
        }
        if (opts.isPermanent?.(err)) {
          moveToFailed(item, err);
          rejected += 1;
          continue;
        }
        markFailed(item, err);
      }
    }
    return { flushed, remaining: count(), rejected, unauthorized, ran: true };
  }

  function flush(options?: { force?: boolean }): Promise<FlushResult> {
    if (inflight) return inflight;
    if (!options?.force && opts.isOnline && !opts.isOnline()) {
      return Promise.resolve({ flushed: 0, remaining: count(), rejected: 0, unauthorized: false, ran: false });
    }
    const p = run().finally(() => {
      inflight = null;
    });
    inflight = p;
    return p;
  }

  function snapshot(): {
    count: number;
    kinds: Record<string, number>;
    oldestAt?: string;
    failed: number;
    lastError?: string;
  } {
    const list = readList(key);
    const kinds: Record<string, number> = {};
    let oldestAt: string | undefined;
    let lastError: string | undefined;
    for (const m of list) {
      kinds[m.kind] = (kinds[m.kind] ?? 0) + 1;
      if (!oldestAt || m.queuedAt < oldestAt) oldestAt = m.queuedAt;
      if (m.lastError) lastError = m.lastError;
    }
    return { count: list.length, kinds, oldestAt, failed: readList(failedKey).length, lastError };
  }

  return {
    read,
    count,
    enqueue,
    flush,
    snapshot,
    failed: () => readList(failedKey),
    clearFailed: () => {
      writeList(failedKey, []);
      changed();
    },
  };
}

export type Outbox<T extends OutboxItem> = ReturnType<typeof createOutbox<T>>;

/** Identifiant de l'objet visé par une mutation (compatible avec les files v4.1/v4.2). */
export function refOf(m: OutboxItem): string | undefined {
  if (m.ref) return m.ref;
  if (m.incidentId) return m.incidentId;
  const p = m.payload as { id?: string } | undefined;
  return p?.id;
}

/**
 * Applique les mutations encore en file par-dessus un état serveur fraîchement
 * lu : le serveur ne doit jamais écraser ce qui n'est pas encore parti.
 */
export function overlayPending<
  P extends { id: string },
  I extends { id: string; hasPhoto?: boolean; photoId?: string },
  S extends { date: string; sector: string },
>(
  server: { points: P[]; incidents: I[]; savings: S[] },
  pending: OutboxItem[],
  local: { points: P[]; incidents: I[] },
): { points: P[]; incidents: I[]; savings: S[] } {
  let points = [...server.points];
  let incidents = [...server.incidents];
  const savings = [...server.savings];

  for (const m of pending) {
    const ref = refOf(m);
    if (m.kind === "point") {
      const next = local.points.find((p) => p.id === ref) ?? (m.payload as P | undefined);
      if (!next) continue;
      const i = points.findIndex((p) => p.id === next.id);
      if (i >= 0) points[i] = next;
      else points.push(next);
    } else if (m.kind === "pointDelete") {
      points = points.filter((p) => p.id !== ref);
    } else if (m.kind === "incident") {
      const next = local.incidents.find((i) => i.id === ref);
      if (!next) continue;
      const i = incidents.findIndex((x) => x.id === next.id);
      if (i >= 0) incidents[i] = next;
      else incidents.unshift(next);
    } else if (m.kind === "photo") {
      incidents = incidents.map((i) =>
        i.id === ref ? { ...i, hasPhoto: true, photoId: m.photoId ?? i.photoId } : i,
      );
    } else if (m.kind === "saving") {
      const entry = m.payload as S | undefined;
      if (!entry) continue;
      const i = savings.findIndex((s) => s.date === entry.date && s.sector === entry.sector);
      if (i >= 0) savings[i] = entry;
      else savings.push(entry);
    }
  }
  return { points, incidents, savings };
}
