import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createOutbox, overlayPending, refOf } from "./outbox.ts";
import type { OutboxItem } from "./outbox.ts";

function memoryStorage(initial: Record<string, string> = {}) {
  const map = new Map(Object.entries(initial));
  return {
    map,
    get: (k: string) => map.get(k) ?? null,
    set: (k: string, v: string) => {
      map.set(k, v);
    },
  };
}

const item = (id: string, kind = "point", extra: Partial<OutboxItem> = {}): OutboxItem => ({
  id,
  kind,
  ref: id.split(":")[1],
  queuedAt: "2026-01-01T00:00:00.000Z",
  ...extra,
});

function make(
  send: (m: OutboxItem) => Promise<void>,
  extra: Partial<Parameters<typeof createOutbox<OutboxItem>>[0]> = {},
  storage = memoryStorage(),
) {
  const outbox = createOutbox<OutboxItem>({
    storage,
    key: "q",
    failedKey: "f",
    send,
    isUnauthorized: (e) => e instanceof Error && e.message === "Unauthorized",
    isPermanent: (e) => e instanceof Error && /Réservé/.test(e.message),
    ...extra,
  });
  return { outbox, storage };
}

describe("outbox — mise en file", () => {
  it("garde une seule mutation par id (la plus récente)", () => {
    const { outbox } = make(async () => {});
    outbox.enqueue(item("point:1", "point", { payload: { v: 1 } }));
    outbox.enqueue(item("point:1", "point", { payload: { v: 2 } }));
    const q = outbox.read();
    assert.equal(q.length, 1);
    assert.deepEqual(q[0].payload, { v: 2 });
  });

  it("survit à un redémarrage : une nouvelle instance relit la même file", () => {
    const storage = memoryStorage();
    make(async () => {}, {}, storage).outbox.enqueue(item("point:1"));
    const reopened = make(async () => {}, {}, storage).outbox;
    assert.equal(reopened.count(), 1);
  });

  it("signale un stockage plein au lieu de le taire", () => {
    const full = { get: () => null, set: () => { throw new Error("quota"); } };
    const { outbox } = make(async () => {}, {}, full as never);
    assert.equal(outbox.enqueue(item("point:1")), false);
  });
});

describe("outbox — envoi", () => {
  it("retire la mutation seulement après un envoi réussi", async () => {
    const sent: string[] = [];
    const { outbox } = make(async (m) => { sent.push(m.id); });
    outbox.enqueue(item("point:1"));
    const r = await outbox.flush();
    assert.deepEqual(sent, ["point:1"]);
    assert.equal(r.flushed, 1);
    assert.equal(r.remaining, 0);
  });

  it("garde la mutation en échec réseau, compte les essais, continue avec les autres", async () => {
    const { outbox } = make(async (m) => {
      if (m.id === "point:1") throw new Error("Failed to fetch");
    });
    outbox.enqueue(item("point:1"));
    outbox.enqueue(item("point:2"));
    const r = await outbox.flush();
    assert.equal(r.flushed, 1);
    assert.equal(r.remaining, 1);
    const [left] = outbox.read();
    assert.equal(left.id, "point:1");
    assert.equal(left.attempts, 1);
    assert.equal(left.lastError, "Failed to fetch");
  });

  it("ne perd pas une mutation remplacée PENDANT l'envoi", async () => {
    let release!: () => void;
    const gate = new Promise<void>((r) => { release = r; });
    const sent: unknown[] = [];
    const { outbox } = make(async (m) => {
      sent.push(m.payload);
      await gate;
    });
    outbox.enqueue(item("point:1", "point", { payload: "v1" }));
    const flushing = outbox.flush();
    await Promise.resolve();
    outbox.enqueue(item("point:1", "point", { payload: "v2" })); // l'utilisateur agit pendant la synchro
    outbox.enqueue(item("point:9", "point", { payload: "autre" }));
    release();
    await flushing;
    // v1 est parti, mais v2 et l'autre point doivent toujours être en file
    assert.deepEqual(outbox.read().map((m) => m.payload).sort(), ["autre", "v2"]);
  });

  it("n'envoie qu'une synchro à la fois", async () => {
    let calls = 0;
    const { outbox } = make(async () => { calls += 1; await new Promise((r) => setTimeout(r, 5)); });
    outbox.enqueue(item("point:1"));
    const [a, b] = await Promise.all([outbox.flush(), outbox.flush()]);
    assert.equal(calls, 1);
    assert.equal(a, b);
  });

  it("401 : s'arrête et ne perd rien", async () => {
    const { outbox } = make(async () => { throw new Error("Unauthorized"); });
    outbox.enqueue(item("point:1"));
    outbox.enqueue(item("point:2"));
    const r = await outbox.flush();
    assert.equal(r.unauthorized, true);
    assert.equal(r.remaining, 2);
  });

  it("refus définitif : sort de la file et apparaît dans les refusées", async () => {
    const { outbox } = make(async () => { throw new Error("Réservé au superviseur"); });
    outbox.enqueue(item("point:1"));
    const r = await outbox.flush();
    assert.equal(r.rejected, 1);
    assert.equal(r.remaining, 0);
    assert.equal(outbox.failed().length, 1);
    assert.match(outbox.failed()[0].lastError ?? "", /Réservé/);
    outbox.clearFailed();
    assert.equal(outbox.failed().length, 0);
  });

  it("hors ligne sans force : rien n'est tenté ; avec force : oui", async () => {
    let calls = 0;
    const { outbox } = make(async () => { calls += 1; }, { isOnline: () => false });
    outbox.enqueue(item("point:1"));
    const idle = await outbox.flush();
    assert.equal(idle.ran, false);
    assert.equal(calls, 0);
    await outbox.flush({ force: true });
    assert.equal(calls, 1);
  });

  it("envoie le constat avant sa photo, même si le constat a été remis en file après", async () => {
    const order: string[] = [];
    const rank = (m: OutboxItem) => (m.kind === "photo" ? 1 : 0);
    const { outbox } = make(async (m) => { order.push(m.kind); }, { rank });
    outbox.enqueue(item("incident:A", "incident"));
    outbox.enqueue(item("photo:A", "photo", { incidentId: "A" }));
    outbox.enqueue(item("incident:A", "incident")); // statut modifié : repasse en fin de file
    await outbox.flush();
    assert.deepEqual(order, ["incident", "photo"]);
  });

  it("lit les files de l'ancien format (sans rev ni ref)", async () => {
    const legacy = [
      { id: "point:p1", kind: "point", payload: { id: "p1" }, queuedAt: "2026-01-01T00:00:00Z" },
      { id: "photo:INC-1", kind: "photo", incidentId: "INC-1", photoId: "ph-INC-1", queuedAt: "2026-01-01T00:00:00Z" },
    ];
    const storage = memoryStorage({ q: JSON.stringify(legacy) });
    const sent: string[] = [];
    const { outbox } = make(async (m) => { sent.push(m.id); }, {}, storage);
    const r = await outbox.flush();
    assert.equal(r.flushed, 2);
    assert.equal(r.remaining, 0);
    assert.equal(refOf(legacy[0]), "p1");
    assert.equal(refOf(legacy[1]), "INC-1");
  });
});

describe("overlayPending — le serveur n'écrase pas ce qui n'est pas parti", () => {
  type P = { id: string; status: string };
  type I = { id: string; status: string; hasPhoto?: boolean; photoId?: string };
  type S = { date: string; sector: string; km: number };

  const server = {
    points: [{ id: "a", status: "toCollect" }, { id: "b", status: "toCollect" }] as P[],
    incidents: [{ id: "INC-1", status: "ouvert" }] as I[],
    savings: [{ date: "2026-11-14", sector: "Tous", km: 1 }] as S[],
  };

  it("garde le statut local d'un point en attente", () => {
    const local = { points: [{ id: "a", status: "collected" }] as P[], incidents: [] as I[] };
    const out = overlayPending(server, [item("point:a", "point")], local);
    assert.equal(out.points.find((p) => p.id === "a")?.status, "collected");
    assert.equal(out.points.find((p) => p.id === "b")?.status, "toCollect");
  });

  it("ajoute un point créé hors ligne et retire un point supprimé en attente", () => {
    const local = { points: [{ id: "new", status: "toCollect" }] as P[], incidents: [] as I[] };
    const out = overlayPending(
      server,
      [item("point:new", "point"), item("point:b", "pointDelete")],
      local,
    );
    assert.deepEqual(out.points.map((p) => p.id).sort(), ["a", "new"]);
  });

  it("garde un constat créé ou modifié hors ligne, et sa photo", () => {
    const local = {
      points: [] as P[],
      incidents: [
        { id: "INC-1", status: "affecte" },
        { id: "INC-2", status: "ouvert", photoId: "ph-INC-2" },
      ] as I[],
    };
    const out = overlayPending(
      server,
      [item("incident:INC-1", "incident"), item("incident:INC-2", "incident"), item("photo:INC-2", "photo", { photoId: "ph-INC-2" })],
      local,
    );
    assert.equal(out.incidents.find((i) => i.id === "INC-1")?.status, "affecte");
    assert.equal(out.incidents.find((i) => i.id === "INC-2")?.hasPhoto, true);
  });

  it("marque la photo en attente même si le constat est déjà sur le serveur", () => {
    const out = overlayPending(server, [item("photo:INC-1", "photo", { photoId: "ph-INC-1" })], { points: [], incidents: [] });
    const inc = out.incidents.find((i) => i.id === "INC-1");
    assert.equal(inc?.hasPhoto, true);
    assert.equal(inc?.photoId, "ph-INC-1");
  });

  it("applique une économie en attente sans doublon", () => {
    const pending: OutboxItem = { ...item("saving:x", "saving"), payload: { date: "2026-11-14", sector: "Tous", km: 7 } };
    const out = overlayPending(server, [pending], { points: [], incidents: [] });
    assert.equal(out.savings.length, 1);
    assert.equal(out.savings[0].km, 7);
  });

  it("sans file, l'état serveur est rendu tel quel", () => {
    const out = overlayPending(server, [], { points: [], incidents: [] });
    assert.deepEqual(out.points, server.points);
  });
});
