import type { KvBackend } from "./kv";

const DB_NAME = "cc_kv";
const STORE = "kv";

function open(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB indisponible"));
      return;
    }
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("IndexedDB: ouverture impossible"));
  });
}

let dbPromise: Promise<IDBDatabase> | null = null;
const db = () => (dbPromise ??= open());

function run<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return db().then(
    (d) =>
      new Promise<T>((resolve, reject) => {
        const tx = d.transaction(STORE, mode);
        const req = fn(tx.objectStore(STORE));
        tx.oncomplete = () => resolve(req.result);
        tx.onerror = () => reject(tx.error ?? new Error("IndexedDB: transaction échouée"));
        tx.onabort = () => reject(tx.error ?? new Error("IndexedDB: transaction annulée"));
      }),
  );
}

export const idbBackend: KvBackend = {
  async loadAll() {
    const [keys, values] = await Promise.all([
      run("readonly", (s) => s.getAllKeys()),
      run("readonly", (s) => s.getAll()),
    ]);
    const out: Record<string, string> = {};
    keys.forEach((k, i) => {
      if (typeof values[i] === "string") out[String(k)] = values[i] as string;
    });
    return out;
  },
  async put(key, value) {
    await run("readwrite", (s) => s.put(value, key));
  },
  async remove(key) {
    await run("readwrite", (s) => s.delete(key));
  },
};
