import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  DEPOT,
  ROLES,
  SECTOR_INFO,
  SECTORS,
  type AssignmentBasis,
  type IncidentHistoryEntry,
  type Point,
  type PointStatus,
  type Role,
  type Saving,
} from "./config";
import { SEED_POINTS } from "./seed";
import { isStale, resolveIncidentWrite } from "./conflict";

type Sql = Awaited<ReturnType<typeof import("@/lib/db").getSql>>;

export type Team = { id: string; name: string; sector: string; chief: string };
export type Vehicle = { id: string; plate: string; kind: string; teamId: string };
export type Sweeper = { id: string; name: string; sector: string; teamId: string };
export type Operation = {
  id: string;
  kind: string;
  sector: string;
  teamId: string;
  sweeperId: string;
  street: string;
  startedAt: string;
  endedAt: string;
  status: string;
  note: string;
};
export type Circuit = {
  id: string;
  name: string;
  sector: string;
  teamId: string;
  vehicleId: string;
  serviceDate: string;
  pointIds: string[];
  km: number;
  roadKm: number | null;
  minutes: number;
  geometry: Array<[number, number]>;
};
export type Member = { userId: string; role: Role; displayName: string; email: string };
export type Depot = { name: string; lat: number; lng: number };

export type IncidentInput = {
  id: string;
  date: string;
  dueAt?: string;
  sector: string;
  type: string;
  description: string;
  lat: number | "";
  lng: number | "";
  status: string;
  assignedTeamId?: string;
  assignedAgentId?: string;
  assignedAgentName?: string;
  assignmentBasis?: AssignmentBasis;
  validatedGps?: boolean;
  priority?: number;
  slaMinutes?: number;
  closedAt?: string;
  closedBy?: string;
  history?: IncidentHistoryEntry[];
  updatedAt?: string;
};

/** Photo compressée côté client : cible ~280 Ko, soit ~375 000 caractères en data-URL. */
const MAX_PHOTO_CHARS = 450_000;

function parseHistory(raw: string | null | undefined): IncidentHistoryEntry[] {
  try {
    const value = JSON.parse(raw || "[]") as unknown;
    return Array.isArray(value) ? (value as IncidentHistoryEntry[]) : [];
  } catch {
    return [];
  }
}


async function db() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

function asRole(value: string): Role {
  return (ROLES as readonly string[]).includes(value) ? (value as Role) : "controleur";
}

async function requireMember(sql: Sql, userId: string) {
  const rows = await sql<{ user_id: string; role: string; display_name: string }>`
    select user_id, role, display_name from members where user_id = ${userId}`;
  const row = rows[0];
  if (!row) throw new Error("Accès refusé");
  return { userId: row.user_id, role: asRole(row.role), displayName: row.display_name };
}

function assertStaff(role: Role) {
  if (role !== "admin" && role !== "superviseur") throw new Error("Réservé au superviseur ou à l'administrateur");
}

async function ensureMember(sql: Sql, userId: string) {
  const existing = await sql<{ user_id: string }>`select user_id from members where user_id = ${userId}`;
  if (!existing.length) {
    const counts = await sql<{ n: number }>`select count(*)::int as n from members`;
    const n = Number(counts[0]?.n ?? 0);
    const users = await sql<{ name: string | null }>`select name from "user" where id = ${userId}`;
    const role: Role = n === 0 ? "admin" : "controleur";
    await sql`insert into members (user_id, role, display_name) values (${userId}, ${role}, ${users[0]?.name ?? ""})`;
  }
  await seedIfNeeded(sql, userId);
  return requireMember(sql, userId);
}

async function seedIfNeeded(sql: Sql, userId: string) {
  const flag = await sql<{ value: string }>`select value from app_meta where key = 'seeded'`;
  if (flag.length) {
    const expanded = await sql<{ value: string }>`select value from app_meta where key = 'seeded-500-locations'`;
    if (!expanded.length) {
      for (const p of SEED_POINTS) {
        await sql`insert into points (id, name, sector, address, lat, lng, status, fill_level, priority_level, in_today)
          values (${p.id}, ${p.name}, ${p.neighborhood}, ${p.address}, ${p.lat}, ${p.lng}, ${p.status}, 0, ${p.status === "priority" ? 3 : 1}, false)
          on conflict (id) do nothing`;
      }
      await sql`insert into app_meta (key, value) values ('seeded-500-locations', '1') on conflict (key) do nothing`;
    }
    return;
  }
  for (const name of SECTORS) {
    const info = SECTOR_INFO[name];
    await sql`insert into sectors (id, name, grp, lat, lng) values (${name}, ${name}, ${info?.group ?? ""}, ${info?.lat ?? 0}, ${info?.lng ?? 0})
      on conflict (id) do nothing`;
  }
  await sql`insert into depot (id, name, lat, lng) values (1, ${DEPOT.name}, ${DEPOT.lat}, ${DEPOT.lng}) on conflict (id) do nothing`;
  for (const p of SEED_POINTS) {
    await sql`insert into points (id, name, sector, address, lat, lng, status, fill_level, priority_level, in_today)
      values (${p.id}, ${p.name}, ${p.neighborhood}, ${p.address}, ${p.lat}, ${p.lng}, ${p.status}, 0, ${p.status === "priority" ? 3 : 1}, true)
      on conflict (id) do nothing`;
  }
  const teams = [
    ["t-belv", "Équipe Belvédère", "Belvédère"],
    ["t-rn", "Équipe Roches Noires", "Roches Noires"],
    ["t-adil", "Équipe Hay Adil", "Hay Adil"],
    ["t-sebaa", "Équipe Aïn Sebaâ", "Aïn Sebaâ"],
    ["t-bern", "Équipe Sidi Bernoussi", "Sidi Bernoussi"],
    ["t-moumen", "Équipe Sidi Moumen", "Sidi Moumen"],
  ];
  for (const [id, name, sector] of teams) {
    await sql`insert into teams (id, name, sector, chief, created_by) values (${id}, ${name}, ${sector}, '', ${userId}) on conflict (id) do nothing`;
  }
  const vehicles = [
    ["v1", "45210-A-6", "BOM", "t-belv"],
    ["v2", "31880-A-6", "Benne", "t-rn"],
    ["v3", "12044-A-6", "Balayeuse", "t-adil"],
    ["v4", "66701-A-1", "BOM", "t-sebaa"],
  ];
  for (const [id, plate, kind, team] of vehicles) {
    await sql`insert into vehicles (id, plate, kind, team_id, created_by) values (${id}, ${plate}, ${kind}, ${team}, ${userId}) on conflict (id) do nothing`;
  }
  const sweepers = [
    ["s1", "Poste balayage 1", "Belvédère", "t-belv"],
    ["s2", "Poste balayage 2", "Roches Noires", "t-rn"],
    ["s3", "Poste balayage 3", "Hay Adil", "t-adil"],
    ["s4", "Poste balayage 4", "Sidi Moumen", "t-moumen"],
  ];
  for (const [id, name, sector, team] of sweepers) {
    await sql`insert into sweepers (id, name, sector, team_id, created_by) values (${id}, ${name}, ${sector}, ${team}, ${userId}) on conflict (id) do nothing`;
  }
  await sql`insert into app_meta (key, value) values ('seeded', '1'), ('seeded-500-locations', '1') on conflict (key) do nothing`;
}

function num(value: unknown, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function parseIds(raw: string): string[] {
  try {
    const value = JSON.parse(raw) as unknown;
    return Array.isArray(value) ? value.map(String) : [];
  } catch {
    return [];
  }
}

function parseLine(raw: string): Array<[number, number]> {
  try {
    const value = JSON.parse(raw) as unknown;
    if (!Array.isArray(value)) return [];
    return value
      .filter((p): p is [number, number] => Array.isArray(p) && p.length >= 2)
      .map((p) => [num(p[0]), num(p[1])] as [number, number]);
  } catch {
    return [];
  }
}

export const getWorkspace = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await db();
    const me = await ensureMember(sql, context.userId);
    const points = await sql<{
      id: string;
      name: string;
      sector: string;
      address: string;
      lat: number;
      lng: number;
      status: string;
      fill_level: number;
      priority_level: number;
      in_today: boolean;
      gps_validated_at: string | null;
      gps_source: string | null;
      gps_accuracy_m: number | null;
      client_updated_at: string | null;
    }>`select id, name, sector, address, lat, lng, status, fill_level, priority_level, in_today,
        gps_validated_at, gps_source, gps_accuracy_m, client_updated_at
        from points order by sector, name`;
    const incidents = await sql<{
      id: string;
      created_at: string;
      sector: string;
      type: string;
      description: string;
      lat: number | null;
      lng: number | null;
      status: string;
      has_photo: boolean;
      due_at: string | null;
      assigned_team_id: string | null;
      assigned_agent_id: string | null;
      assigned_agent_name: string | null;
      assignment_basis: string | null;
      validated_gps: boolean;
      priority: number | null;
      sla_minutes: number | null;
      closed_at: string | null;
      closed_by: string | null;
      history: string;
      client_updated_at: string | null;
    }>`select id, created_at, sector, type, description, lat, lng, status, (photo <> '') as has_photo,
        due_at, assigned_team_id, assigned_agent_id, assigned_agent_name, assignment_basis, validated_gps,
        priority, sla_minutes, closed_at, closed_by, history, client_updated_at
        from incidents order by created_at desc`;
    const teams = await sql<Team>`select id, name, sector, chief from teams order by name`;
    const vehicles = await sql<{ id: string; plate: string; kind: string; team_id: string }>`
      select id, plate, kind, team_id from vehicles order by plate`;
    const sweepers = await sql<{ id: string; name: string; sector: string; team_id: string }>`
      select id, name, sector, team_id from sweepers order by name`;
    const operations = await sql<{
      id: string;
      kind: string;
      sector: string;
      team_id: string;
      sweeper_id: string;
      street: string;
      started_at: string;
      ended_at: string;
      status: string;
      note: string;
    }>`select id, kind, sector, team_id, sweeper_id, street, started_at, ended_at, status, note from operations order by started_at desc`;
    const circuits = await sql<{
      id: string;
      name: string;
      sector: string;
      team_id: string;
      vehicle_id: string;
      service_date: string;
      point_ids: string;
      km: number;
      road_km: number | null;
      minutes: number;
      geometry: string;
    }>`select id, name, sector, team_id, vehicle_id, service_date, point_ids, km, road_km, minutes, geometry from circuits order by service_date desc`;
    const savings = await sql<{ service_date: string; sector: string; km: number; points: number }>`
      select service_date, sector, km, points from savings order by service_date desc`;
    const depotRows = await sql<Depot>`select name, lat, lng from depot where id = 1`;
    const memberRows =
      me.role === "controleur"
        ? []
        : await sql<{ user_id: string; role: string; display_name: string; email: string | null; name: string | null }>`
            select m.user_id, m.role, m.display_name, u.email, u.name
            from members m left join "user" u on u.id = m.user_id
            order by m.created_at`;
    return {
      me,
      depot: depotRows[0] ?? DEPOT,
      points: points.map(
        (p): Point => ({
          id: p.id,
          name: p.name,
          neighborhood: p.sector,
          address: p.address,
          lat: num(p.lat),
          lng: num(p.lng),
          status: (p.status as PointStatus) || "toCollect",
          fillLevel: num(p.fill_level),
          priorityLevel: num(p.priority_level, 1),
          inTodayTour: Boolean(p.in_today),
          gpsValidatedAt: p.gps_validated_at || undefined,
          gpsSource: (p.gps_source as Point["gpsSource"]) || undefined,
          gpsAccuracyM: p.gps_accuracy_m == null ? undefined : num(p.gps_accuracy_m),
          updatedAt: p.client_updated_at || undefined,
        }),
      ),
      incidents: incidents.map((i) => ({
        id: i.id,
        date: i.created_at,
        sector: i.sector,
        type: i.type,
        description: i.description,
        lat: i.lat == null ? "" : num(i.lat),
        lng: i.lng == null ? "" : num(i.lng),
        status: i.status,
        dueAt: i.due_at || undefined,
        assignedTeamId: i.assigned_team_id || undefined,
        assignedTeamName: teams.find((t) => t.id === i.assigned_team_id)?.name,
        assignedAgentId: i.assigned_agent_id || undefined,
        assignedAgentName: i.assigned_agent_name || undefined,
        assignmentBasis: (i.assignment_basis || "sector-estimate") as AssignmentBasis,
        validatedGps: Boolean(i.validated_gps),
        priority: i.priority ?? undefined,
        slaMinutes: i.sla_minutes ?? undefined,
        closedAt: i.closed_at || undefined,
        closedBy: i.closed_by || undefined,
        history: parseHistory(i.history),
        updatedAt: i.client_updated_at || undefined,
        // La photo n'est plus embarquée dans chaque chargement : on la récupère à la demande.
        hasPhoto: Boolean(i.has_photo),
      })),
      teams,
      vehicles: vehicles.map((v) => ({ id: v.id, plate: v.plate, kind: v.kind, teamId: v.team_id })),
      sweepers: sweepers.map((s) => ({ id: s.id, name: s.name, sector: s.sector, teamId: s.team_id })),
      operations: operations.map((o) => ({
        id: o.id,
        kind: o.kind,
        sector: o.sector,
        teamId: o.team_id,
        sweeperId: o.sweeper_id,
        street: o.street,
        startedAt: o.started_at,
        endedAt: o.ended_at,
        status: o.status,
        note: o.note,
      })),
      circuits: circuits.map((c) => ({
        id: c.id,
        name: c.name,
        sector: c.sector,
        teamId: c.team_id,
        vehicleId: c.vehicle_id,
        serviceDate: c.service_date,
        pointIds: parseIds(c.point_ids),
        km: num(c.km),
        roadKm: c.road_km == null ? null : num(c.road_km),
        minutes: num(c.minutes),
        geometry: parseLine(c.geometry),
      })),
      savings: savings.map(
        (s): Saving => ({ date: s.service_date, sector: s.sector, km: num(s.km), points: num(s.points) }),
      ),
      members: memberRows.map((m) => ({
        userId: m.user_id,
        role: asRole(m.role),
        displayName: m.display_name || m.name || "",
        email: me.role === "admin" ? m.email || "" : "",
      })),
    };
  });

export const savePoint = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((p: Point) => p)
  .handler(async ({ context, data }) => {
    const sql = await db();
    const me = await requireMember(sql, context.userId);
    if (!data?.id || !data.name) throw new Error("Point incomplet");
    const existing = await sql<{ id: string; client_updated_at: string | null }>`
      select id, client_updated_at from points where id = ${data.id}`;
    if (!existing.length) assertStaff(me.role);
    // Un appareil resté hors ligne ne doit pas écraser une modification plus récente.
    const known = existing[0]?.client_updated_at;
    if (isStale(data.updatedAt, known)) return { ok: true, stale: true };
    await sql`insert into points (id, name, sector, address, lat, lng, status, fill_level, priority_level, in_today,
        gps_validated_at, gps_source, gps_accuracy_m, client_updated_at)
      values (${data.id}, ${data.name}, ${data.neighborhood}, ${data.address}, ${data.lat}, ${data.lng}, ${data.status}, ${data.fillLevel}, ${data.priorityLevel}, ${data.inTodayTour},
        ${data.gpsValidatedAt ?? null}, ${data.gpsSource ?? null}, ${data.gpsAccuracyM ?? null}, ${data.updatedAt ?? null})
      on conflict (id) do update set
        name = excluded.name, sector = excluded.sector, address = excluded.address,
        lat = excluded.lat, lng = excluded.lng, status = excluded.status,
        fill_level = excluded.fill_level, priority_level = excluded.priority_level, in_today = excluded.in_today,
        gps_validated_at = excluded.gps_validated_at, gps_source = excluded.gps_source,
        gps_accuracy_m = excluded.gps_accuracy_m, client_updated_at = excluded.client_updated_at`;
    return { ok: true };
  });

export const removePoint = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    const sql = await db();
    const me = await requireMember(sql, context.userId);
    assertStaff(me.role);
    await sql`delete from points where id = ${id}`;
    return { ok: true };
  });

export const resetTodayFlags = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await db();
    const me = await requireMember(sql, context.userId);
    assertStaff(me.role);
    await sql`update points set in_today = true`;
    return { ok: true };
  });

export const saveCircuit = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((c: Circuit) => c)
  .handler(async ({ context, data }) => {
    const sql = await db();
    await requireMember(sql, context.userId);
    if (!data?.id) throw new Error("Circuit incomplet");
    await sql`insert into circuits (id, name, sector, team_id, vehicle_id, service_date, point_ids, km, road_km, minutes, geometry, created_by)
      values (${data.id}, ${data.name}, ${data.sector}, ${data.teamId}, ${data.vehicleId}, ${data.serviceDate}, ${JSON.stringify(data.pointIds)}, ${data.km}, ${data.roadKm}, ${data.minutes}, ${JSON.stringify(data.geometry)}, ${context.userId})
      on conflict (id) do update set
        name = excluded.name, sector = excluded.sector, team_id = excluded.team_id, vehicle_id = excluded.vehicle_id,
        point_ids = excluded.point_ids, km = excluded.km, road_km = excluded.road_km, minutes = excluded.minutes, geometry = excluded.geometry`;
    return { ok: true };
  });

export const saveSaving = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((s: Saving) => s)
  .handler(async ({ context, data }) => {
    const sql = await db();
    await requireMember(sql, context.userId);
    const id = `${data.date}:${data.sector}`;
    await sql`insert into savings (id, service_date, sector, km, points, author_id)
      values (${id}, ${data.date}, ${data.sector}, ${data.km}, ${data.points ?? 0}, ${context.userId})
      on conflict (id) do update set km = excluded.km, points = excluded.points`;
    return { ok: true };
  });

export const saveIncident = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((i: IncidentInput) => i)
  .handler(async ({ context, data }) => {
    const sql = await db();
    await requireMember(sql, context.userId);
    if (!data?.id || !data.sector || !data.type) throw new Error("Constat incomplet");
    const lat = data.lat === "" ? null : data.lat;
    const lng = data.lng === "" ? null : data.lng;
    const rows = await sql<{ client_updated_at: string | null; history: string }>`
      select client_updated_at, history from incidents where id = ${data.id}`;
    const decision = resolveIncidentWrite(
      rows.length ? { updatedAt: rows[0].client_updated_at, history: parseHistory(rows[0].history) } : null,
      data,
    );
    const history = JSON.stringify(decision.history);
    if (decision.kind === "insert") {
      await sql`insert into incidents (id, created_at, sector, type, description, lat, lng, status, photo, author_id,
          due_at, assigned_team_id, assigned_agent_id, assigned_agent_name, assignment_basis, validated_gps,
          priority, sla_minutes, closed_at, closed_by, history, client_updated_at)
        values (${data.id}, ${data.date}, ${data.sector}, ${data.type}, ${data.description}, ${lat}, ${lng}, ${data.status}, '', ${context.userId},
          ${data.dueAt || null}, ${data.assignedTeamId || null}, ${data.assignedAgentId || null}, ${data.assignedAgentName || null}, ${data.assignmentBasis || null}, ${Boolean(data.validatedGps)},
          ${data.priority ?? null}, ${data.slaMinutes ?? null}, ${data.closedAt || null}, ${data.closedBy || null}, ${history}, ${data.updatedAt ?? null})
        on conflict (id) do nothing`;
      return { ok: true };
    }
    if (decision.kind === "history-only") {
      // Version plus ancienne que celle du serveur : champs inchangés, historique fusionné sans perte.
      await sql`update incidents set history = ${history} where id = ${data.id}`;
      return { ok: true, stale: true };
    }
    await sql`update incidents set
        status = ${data.status}, due_at = ${data.dueAt || null},
        assigned_team_id = ${data.assignedTeamId || null}, assigned_agent_id = ${data.assignedAgentId || null},
        assigned_agent_name = ${data.assignedAgentName || null}, assignment_basis = ${data.assignmentBasis || null},
        validated_gps = ${Boolean(data.validatedGps)}, lat = ${lat}, lng = ${lng},
        priority = ${data.priority ?? null}, sla_minutes = ${data.slaMinutes ?? null},
        closed_at = ${data.closedAt || null}, closed_by = ${data.closedBy || null},
        history = ${history}, client_updated_at = ${data.updatedAt ?? null}
      where id = ${data.id}`;
    return { ok: true };
  });

export const saveIncidentPhoto = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((i: { id: string; photo: string }) => i)
  .handler(async ({ context, data }) => {
    const sql = await db();
    await requireMember(sql, context.userId);
    if (!data?.id || typeof data.photo !== "string" || !data.photo.startsWith("data:image/")) {
      throw new Error("Photo invalide");
    }
    if (data.photo.length > MAX_PHOTO_CHARS) throw new Error("Photo trop volumineuse");
    const rows = await sql<{ id: string }>`update incidents set photo = ${data.photo} where id = ${data.id} returning id`;
    // Le constat n'est pas encore arrivé : erreur transitoire, la photo sera renvoyée à la prochaine synchro.
    if (!rows.length) throw new Error("Constat introuvable côté serveur");
    return { ok: true };
  });

export const getIncidentPhotoRemote = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    const sql = await db();
    await requireMember(sql, context.userId);
    const rows = await sql<{ photo: string }>`select photo from incidents where id = ${id}`;
    return { photo: rows[0]?.photo ?? "" };
  });

export const saveOperation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((o: Operation) => o)
  .handler(async ({ context, data }) => {
    const sql = await db();
    await requireMember(sql, context.userId);
    await sql`insert into operations (id, kind, sector, team_id, sweeper_id, street, started_at, ended_at, status, note, author_id)
      values (${data.id}, ${data.kind}, ${data.sector}, ${data.teamId}, ${data.sweeperId}, ${data.street}, ${data.startedAt}, ${data.endedAt}, ${data.status}, ${data.note}, ${context.userId})
      on conflict (id) do update set ended_at = excluded.ended_at, status = excluded.status, note = excluded.note`;
    return { ok: true };
  });

export const saveTeam = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((t: Team) => t)
  .handler(async ({ context, data }) => {
    const sql = await db();
    const me = await requireMember(sql, context.userId);
    assertStaff(me.role);
    await sql`insert into teams (id, name, sector, chief, created_by) values (${data.id}, ${data.name}, ${data.sector}, ${data.chief}, ${context.userId})
      on conflict (id) do update set name = excluded.name, sector = excluded.sector, chief = excluded.chief`;
    return { ok: true };
  });

export const removeTeam = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    const sql = await db();
    const me = await requireMember(sql, context.userId);
    assertStaff(me.role);
    await sql`delete from teams where id = ${id}`;
    return { ok: true };
  });

export const saveVehicle = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((v: Vehicle) => v)
  .handler(async ({ context, data }) => {
    const sql = await db();
    const me = await requireMember(sql, context.userId);
    assertStaff(me.role);
    await sql`insert into vehicles (id, plate, kind, team_id, created_by) values (${data.id}, ${data.plate}, ${data.kind}, ${data.teamId}, ${context.userId})
      on conflict (id) do update set plate = excluded.plate, kind = excluded.kind, team_id = excluded.team_id`;
    return { ok: true };
  });

export const saveSweeper = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((s: Sweeper) => s)
  .handler(async ({ context, data }) => {
    const sql = await db();
    const me = await requireMember(sql, context.userId);
    assertStaff(me.role);
    await sql`insert into sweepers (id, name, sector, team_id, created_by) values (${data.id}, ${data.name}, ${data.sector}, ${data.teamId}, ${context.userId})
      on conflict (id) do update set name = excluded.name, sector = excluded.sector, team_id = excluded.team_id`;
    return { ok: true };
  });

export const saveDepot = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: Depot) => d)
  .handler(async ({ context, data }) => {
    const sql = await db();
    const me = await requireMember(sql, context.userId);
    if (me.role !== "admin") throw new Error("Réservé à l'administrateur");
    await sql`insert into depot (id, name, lat, lng) values (1, ${data.name}, ${data.lat}, ${data.lng})
      on conflict (id) do update set name = excluded.name, lat = excluded.lat, lng = excluded.lng`;
    return { ok: true };
  });

export const setMemberRole = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId: string; role: Role }) => input)
  .handler(async ({ context, data }) => {
    const sql = await db();
    const me = await requireMember(sql, context.userId);
    if (me.role !== "admin") throw new Error("Réservé à l'administrateur");
    if (data.userId === context.userId) throw new Error("Vous ne pouvez pas changer votre propre rôle");
    if (!(ROLES as readonly string[]).includes(data.role)) throw new Error("Rôle inconnu");
    await sql`update members set role = ${data.role} where user_id = ${data.userId}`;
    return { ok: true };
  });

export const createAccess = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { email: string; password: string; name: string; role: Role }) => input)
  .handler(async ({ context, data }) => {
    const sql = await db();
    const me = await requireMember(sql, context.userId);
    if (me.role !== "admin") throw new Error("Réservé à l'administrateur");
    const email = data.email.trim().toLowerCase();
    const name = data.name.trim();
    if (!email.includes("@") || data.password.length < 8 || !name) throw new Error("E-mail, nom et mot de passe (8 caractères) requis");
    if (!(ROLES as readonly string[]).includes(data.role)) throw new Error("Rôle inconnu");
    const { auth } = await import("@/lib/auth/server");
    const result = await auth.api.signUpEmail({ body: { email, password: data.password, name } });
    const userId = result?.user?.id;
    if (!userId) throw new Error("Compte non créé");
    await sql`insert into members (user_id, role, display_name) values (${userId}, ${data.role}, ${name})
      on conflict (user_id) do update set role = excluded.role, display_name = excluded.display_name`;
    return { ok: true };
  });

export const roadRoute = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { points: Array<{ lat: number; lng: number }> }) => input)
  .handler(async ({ context, data }) => {
    const sql = await db();
    await requireMember(sql, context.userId);
    const pts = (data.points ?? []).filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lng)).slice(0, 25);
    if (pts.length < 2) throw new Error("Pas assez de points pour un itinéraire");
    const path = pts.map((p) => `${p.lng},${p.lat}`).join(";");
    const url = `https://router.project-osrm.org/route/v1/driving/${path}?overview=full&geometries=geojson`;
    const res = await fetch(url);
    if (!res.ok) throw new Error("Service d'itinéraire indisponible");
    const body = (await res.json()) as {
      code?: string;
      routes?: Array<{ distance: number; duration: number; geometry?: { coordinates?: Array<[number, number]> } }>;
    };
    const route = body.routes?.[0];
    if (!route || body.code !== "Ok") throw new Error("Aucun itinéraire routier trouvé");
    return {
      km: Math.round((route.distance / 1000) * 10) / 10,
      minutes: Math.max(1, Math.round(route.duration / 60)),
      geometry: (route.geometry?.coordinates ?? []).slice(0, 800),
    };
  });
