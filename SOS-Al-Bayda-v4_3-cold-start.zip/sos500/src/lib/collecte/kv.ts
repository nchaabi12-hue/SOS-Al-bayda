/**
 * Stockage local durable : miroir mémoire (lecture synchrone) + écriture asynchrone
 * dans un backend (IndexedDB en production). Remplace localStorage (~5 Mo) pour la
 * file hors ligne et le cache de l'espace de travail.
 *
 * - get/set restent synchrones : le reste de l'app n'a pas à changer ;
 * - les écritures sont regroupées par clé (la dernière gagne) et sérialisées ;
 * - premier chargement : les anciennes clés localStorage sont migrées puis supprimées ;
 * - si le backend est indisponible (navigation privée…), repli sur localStorage.
 */
export type KvBackend = {
  loadAll(): Promise<Record<string, string>>;
  put(key: string, value: string): Promise<void>;
  remove(key: string): Promise<void>;
};

export type LegacyStore = {
  get(key: string): string | null;
  set(key: string, value: string): void;
  remove(key: string): void;
};

export type KvOptions = {
  backend: KvBackend;
  legacy?: LegacyStore;
  /** Clés à migrer depuis `legacy` au premier chargement. */
  legacyKeys?: string[];
  onError?: (err: unknown) => void;
};

export function createKv(opts: KvOptions) {
  const mem = new Map<string, string | null>(); // null = suppression en attente
  const dirty = new Set<string>();
  let degraded = false;
  let draining: Promise<void> | null = null;
  let loaded: Promise<void> | null = null;

  async function drain() {
    while (dirty.size) {
      const key = dirty.values().next().value as string;
      dirty.delete(key);
      const value = mem.get(key);
      try {
        if (value === null || value === undefined) await opts.backend.remove(key);
        else await opts.backend.put(key, value);
      } catch (err) {
        opts.onError?.(err);
      }
    }
  }

  function schedule(key: string) {
    if (degraded) return;
    dirty.add(key);
    if (!draining) {
      draining = drain().finally(() => {
        draining = null;
        if (dirty.size) schedule([...dirty][0]);
      });
    }
  }

  function load(): Promise<void> {
    if (!loaded) {
      loaded = (async () => {
        let stored: Record<string, string> = {};
        try {
          stored = await opts.backend.loadAll();
        } catch (err) {
          degraded = true;
          opts.onError?.(err);
        }
        for (const [k, v] of Object.entries(stored)) if (!mem.has(k)) mem.set(k, v);
        // Migration localStorage -> backend (jamais d'écrasement d'une valeur déjà présente).
        for (const k of opts.legacyKeys ?? []) {
          const old = opts.legacy?.get(k) ?? null;
          if (old === null) continue;
          if (!mem.has(k)) mem.set(k, old);
          if (degraded) continue; // en repli, localStorage reste la mémoire
          try {
            await opts.backend.put(k, mem.get(k) as string);
            opts.legacy?.remove(k);
          } catch (err) {
            opts.onError?.(err);
          }
        }
      })();
    }
    return loaded;
  }

  function get(key: string): string | null {
    const v = mem.get(key);
    if (v !== undefined) return v;
    return degraded ? (opts.legacy?.get(key) ?? null) : null;
  }

  function set(key: string, value: string) {
    mem.set(key, value);
    if (degraded) {
      try {
        opts.legacy?.set(key, value);
      } catch (err) {
        opts.onError?.(err);
      }
      return;
    }
    schedule(key);
  }

  function remove(key: string) {
    mem.set(key, null);
    if (degraded) {
      opts.legacy?.remove(key);
      return;
    }
    schedule(key);
  }

  return {
    load,
    get,
    set,
    remove,
    /** Attend que toutes les écritures en cours soient enregistrées. */
    idle: async () => {
      while (draining) await draining;
    },
    isDegraded: () => degraded,
  };
}

export type Kv = ReturnType<typeof createKv>;
