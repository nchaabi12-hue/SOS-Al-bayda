/**
 * Règles de conflit côté serveur (pures, testables sans base de données).
 *
 * - Valeurs (statut, équipe, GPS…) : la modification la plus récente gagne,
 *   comparée par `updatedAt` (ISO, horloge du téléphone).
 * - Historique d'un constat : union des deux versions, jamais de perte.
 *
 * NOTE : ce fichier a été RECONSTRUIT à partir de conflict.test.ts et de ses
 * usages dans api.ts (l'original a été écrasé par erreur). À comparer avec
 * toute copie antérieure.
 */

export type HistoryEntry = {
  at: string;
  by?: string;
  action: string;
  from?: string;
  to?: string;
  note?: string;
};

const keyOf = (e: HistoryEntry) => `${e.at}|${e.action}|${e.from ?? ""}|${e.to ?? ""}|${e.by ?? ""}`;

/** Union de deux historiques, sans doublon, triée (date puis clé : même résultat quel que soit l'ordre). */
export function mergeHistory(a: HistoryEntry[], b: HistoryEntry[]): HistoryEntry[] {
  const seen = new Map<string, HistoryEntry>();
  for (const e of [...a, ...b]) seen.set(keyOf(e), e);
  return [...seen.entries()]
    .sort(([ka, x], [kb, y]) => (x.at < y.at ? -1 : x.at > y.at ? 1 : ka < kb ? -1 : ka > kb ? 1 : 0))
    .map(([, e]) => e);
}

/** Vrai si la version entrante est PLUS ANCIENNE que celle déjà connue. Sans horodatage : jamais périmée. */
export function isStale(incoming: string | null | undefined, known: string | null | undefined): boolean {
  return Boolean(incoming && known && incoming < known);
}

export type IncidentWriteDecision = {
  kind: "insert" | "update" | "history-only";
  history: HistoryEntry[];
};

export function resolveIncidentWrite(
  server: { updatedAt?: string | null; history: HistoryEntry[] } | null,
  incoming: { updatedAt?: string | null; history?: HistoryEntry[] },
): IncidentWriteDecision {
  const history = mergeHistory(server?.history ?? [], incoming.history ?? []);
  if (!server) return { kind: "insert", history };
  if (isStale(incoming.updatedAt, server.updatedAt)) return { kind: "history-only", history };
  return { kind: "update", history };
}
