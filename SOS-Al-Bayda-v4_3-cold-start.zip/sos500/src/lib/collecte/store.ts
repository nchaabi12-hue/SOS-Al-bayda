import {
  DEPOT,
  INCIDENT_STATUS,
  SECTOR_INFO,
  SECTORS,
  STORAGE_PREFIX,
  buildIncidentDefaults,
  type AppData,
  type AssignmentBasis,
  type Incident,
  type IncidentHistoryEntry,
  type Point,
  type PointStatus,
  type Role,
  type Saving,
  type TourSession,
} from "./config";
import { SEED_POINTS } from "./seed";
import { haversine } from "./geo";
import { clearPhotos, getPhoto, putPhoto } from "./photos";
import { createKv, type Kv } from "./kv";
import { idbBackend } from "./kv-idb";
import { createOutbox, overlayPending, refOf, type Outbox, type OutboxItem } from "./outbox";
import {
  createAccess,
  getIncidentPhotoRemote,
  getWorkspace,
  removePoint,
  removeTeam,
  resetTodayFlags,
  roadRoute,
  saveCircuit,
  saveDepot,
  saveIncident,
  saveIncidentPhoto,
  saveOperation,
  savePoint,
  saveSaving,
  saveSweeper,
  saveTeam,
  saveVehicle,
  setMemberRole,
  type Circuit,
  type Depot,
  type IncidentInput,
  type Member,
  type Operation,
  type Sweeper,
  type Team,
  type Vehicle,
} from "./api";

const VALID_STATUS: PointStatus[] = ["toCollect", "priority", "collected", "skipped"];

const clamp = (n: number, min: number, max: number) => Math.min(max, Math.max(min, n));

export function normalizePoint(p: Partial<Point> & { id?: string }): Point {
  const status = VALID_STATUS.includes(p.status as PointStatus) ? (p.status as PointStatus) : "toCollect";
  return {
    id: String(p.id),
    name: String(p.name ?? p.id),
    neighborhood: p.neighborhood ?? SECTORS[0],
    address: p.address ?? p.name ?? "",
    lat: Number(p.lat),
    lng: Number(p.lng),
    status,
    inTodayTour: p.inTodayTour !== false,
    fillLevel: clamp(Number(p.fillLevel) || 0, 0, 100),
    priorityLevel: clamp(Number(p.priorityLevel) || 1, 1, 5),
    gpsValidatedAt: p.gpsValidatedAt,
    gpsSource: p.gpsSource,
    gpsAccuracyM: p.gpsAccuracyM,
    updatedAt: p.updatedAt,
  };
}

const isValidPoint = (p: unknown): p is Partial<Point> & { id: string } => {
  if (!p || typeof p !== "object") return false;
  const row = p as Partial<Point>;
  return row.id != null && Number.isFinite(Number(row.lat)) && Number.isFinite(Number(row.lng));
};

export type UiState = {
  search: string;
  sectorFilter: string;
  tourSector: string;
};

export type ToastItem = { id: number; message: string; kind: "info" | "error" };

export type FullState = AppData & {
  ui: UiState;
  toasts: ToastItem[];
  teams: Team[];
  vehicles: Vehicle[];
  sweepers: Sweeper[];
  operations: Operation[];
  circuits: Circuit[];
  members: Member[];
  depot: Depot;
  role: Role | "";
  sync: "idle" | "ok" | "offline" | "auth";
  loaded: boolean;
};

function seedData(): AppData {
  return {
    points: SEED_POINTS.map((p) => normalizePoint(p)),
    incidents: [],
    savings: [],
    session: null,
  };
}

const INITIAL: FullState = {
  ...seedData(),
  ui: { search: "", sectorFilter: "Tous", tourSector: "Tous" },
  toasts: [],
  teams: [],
  vehicles: [],
  sweepers: [],
  operations: [],
  circuits: [],
  members: [],
  depot: DEPOT,
  role: "",
  sync: "idle",
  loaded: false,
};

let current: FullState = INITIAL;
let hydrated = false;
const listeners = new Set<() => void>();
let toastSeq = 1;

function emit() {
  listeners.forEach((l) => l());
}

export function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function getSnapshot() {
  return current;
}

export function getServerSnapshot() {
  return INITIAL;
}

const KV_KEYS = ["workspace", "pending-mutations-v1", "pending-failed-v1", "points", "incidents", "savings", "session"];
let kvInstance: Kv | null = null;
let storageReady: Promise<void> | null = null;

/** Stockage durable (IndexedDB, repli localStorage). Les anciennes clés `cc_*` sont migrées au premier chargement. */
function getKv(): Kv {
  if (!kvInstance) {
    kvInstance = createKv({
      backend: idbBackend,
      legacy: {
        get: (k) => localStorage.getItem(STORAGE_PREFIX + k),
        set: (k, v) => localStorage.setItem(STORAGE_PREFIX + k, v),
        remove: (k) => localStorage.removeItem(STORAGE_PREFIX + k),
      },
      legacyKeys: KV_KEYS,
      onError: (err) => {
        console.error("[storage]", err);
        toast("Stockage local en difficulté : données peut-être non sauvegardées", "error");
      },
    });
  }
  return kvInstance;
}

/** À attendre avant de lire ou d'envoyer quoi que ce soit : sinon la file semblerait vide. */
export function initStorage(): Promise<void> {
  if (typeof window === "undefined") return Promise.resolve();
  storageReady ??= getKv().load().then(() => emit());
  return storageReady;
}

function readKey<T>(key: string, fallback: T): T {
  try {
    const raw = getKv().get(key);
    if (raw === null) return fallback;
    return (JSON.parse(raw) as T) ?? fallback;
  } catch {
    return fallback;
  }
}

function writeKey(key: string, value: unknown) {
  try {
    getKv().set(key, JSON.stringify(value));
    return true;
  } catch (err) {
    console.error("[storage]", key, err);
    return false;
  }
}

/**
 * Une seule mémoire locale : `cc_workspace`. C'est elle que `hydrate()` relit au
 * démarrage, donc tout ce qui est écrit ici survit à la fermeture de l'app.
 */
function persist() {
  const ok = writeKey("workspace", {
    points: current.points,
    incidents: current.incidents,
    savings: current.savings,
    session: current.session,
    teams: current.teams,
    vehicles: current.vehicles,
    sweepers: current.sweepers,
    operations: current.operations,
    circuits: current.circuits,
    depot: current.depot,
    role: current.role,
  });
  if (!ok) toast("Stockage plein ou indisponible : données non sauvegardées", "error");
  return ok;
}

export function toast(message: string, kind: ToastItem["kind"] = "info") {
  const id = toastSeq++;
  current = { ...current, toasts: [...current.toasts, { id, message, kind }] };
  emit();
  setTimeout(() => {
    current = { ...current, toasts: current.toasts.filter((t) => t.id !== id) };
    emit();
  }, 2800);
}

// ---------------------------------------------------------------------------
// File d'attente hors ligne — la logique (ordre, relecture, anti-perte) est
// dans ./outbox.ts et couverte par outbox.test.ts. Ici : le branchement.
// ---------------------------------------------------------------------------

type PendingMutation = OutboxItem & {
  kind: "incident" | "point" | "pointDelete" | "photo" | "saving";
  /** Photo embarquée si IndexedDB est indisponible. */
  dataUrl?: string;
};

const OUTBOX_KEY = "pending-mutations-v1";
const FAILED_KEY = "pending-failed-v1";

/** Refus définitifs du serveur : inutile de réessayer, on les signale. */
const PERMANENT_ERROR = /Réservé|Accès refusé|incomplet|invalide|trop volumineuse|Photo locale introuvable|Photo invalide/i;

/** Incrémenté à chaque changement de la file : détecte une action locale pendant un chargement serveur. */
let localEpoch = 0;
let lastRefreshAt = 0;
let refreshing: Promise<void> | null = null;
let outboxInstance: Outbox<PendingMutation> | null = null;

function getOutbox(): Outbox<PendingMutation> {
  if (!outboxInstance) {
    outboxInstance = createOutbox<PendingMutation>({
      storage: { get: (k) => getKv().get(k), set: (k, v) => getKv().set(k, v) },
      key: OUTBOX_KEY,
      failedKey: FAILED_KEY,
      send: sendMutation,
      isUnauthorized: (e) => e instanceof Error && e.message === "Unauthorized",
      isPermanent: (e) => e instanceof Error && PERMANENT_ERROR.test(e.message),
      isOnline: () => typeof navigator === "undefined" || navigator.onLine !== false,
      // Un constat doit exister sur le serveur avant que sa photo n'arrive.
      rank: (m) => (m.kind === "photo" ? 1 : 0),
      onChange: () => {
        localEpoch += 1;
        emit();
      },
    });
  }
  return outboxInstance;
}

/** Nombre d'éléments en attente de sync (UI badge). */
export function getPendingCount(): number {
  return getOutbox().count();
}

/** Snapshot de la file pour l'indicateur de sync. */
export function getOutboxSnapshot() {
  return getOutbox().snapshot();
}

/** Modifications que le serveur a refusées (droits, données invalides). */
export function getFailedMutations(): PendingMutation[] {
  return getOutbox().failed();
}

export function clearFailedMutations() {
  getOutbox().clearFailed();
}

async function sendMutation(m: PendingMutation) {
  const ref = refOf(m);
  switch (m.kind) {
    case "incident": {
      // Les anciennes files (v4.1) pouvaient porter une photo inline : elle part séparément.
      const { photo: _photo, ...rest } = m.payload as IncidentInput & { photo?: string };
      await saveIncident(rest);
      return;
    }
    case "point":
      await savePoint(m.payload as Point);
      return;
    case "pointDelete":
      if (ref) await removePoint(ref);
      return;
    case "saving":
      await saveSaving(m.payload as Saving);
      return;
    case "photo": {
      const id = m.incidentId ?? ref;
      if (!id) {
        throw new Error("Photo invalide : identifiant de constat manquant");
      }
      const dataUrl = m.dataUrl ?? (m.photoId ? await getPhoto(m.photoId) : undefined);
      if (!dataUrl) {
        // Photo locale disparue (IndexedDB purgée, quota, etc.) → refus définitif,
        // pas un succès silencieux qui ferait perdre la mutation sans feedback.
        throw new Error("Photo locale introuvable — re-prendre la photo sur le terrain");
      }
      await saveIncidentPhoto({ id, photo: dataUrl });
      return;
    }
  }
}

function enqueue(m: Omit<PendingMutation, "queuedAt" | "rev">): boolean {
  const ok = getOutbox().enqueue({ ...m, queuedAt: new Date().toISOString() } as PendingMutation);
  if (!ok) toast("Stockage plein : modification non enregistrée pour l'envoi", "error");
  return ok;
}

type FlushOutcome = Awaited<ReturnType<Outbox<PendingMutation>["flush"]>>;
const handledFlushes = new WeakSet<object>();

/** Effets de bord d'une synchro, appliqués une seule fois même si plusieurs appelants l'attendent. */
function settleFlush(res: FlushOutcome) {
  if (handledFlushes.has(res)) return;
  handledFlushes.add(res);
  if (res.unauthorized) {
    current = { ...current, sync: "auth" };
    emit();
  } else if (res.ran) {
    if (res.remaining > 0) current = { ...current, sync: "offline" };
    else if (res.flushed > 0) current = { ...current, sync: "ok" };
    emit();
  }
  if (res.rejected > 0) {
    toast(`${res.rejected} modification(s) refusée(s) par le serveur — voir le bandeau`, "error");
    if (!refreshing) void refreshFromServer(); // réaligne l'écran sur le serveur
  }
}

export async function flushPendingMutations(options?: { force?: boolean }) {
  await initStorage();
  const res = await getOutbox().flush(options);
  settleFlush(res);
  return { flushed: res.flushed, remaining: res.remaining };
}

function persistPointForSync(point: Point) {
  enqueue({ id: `point:${point.id}`, kind: "point", ref: point.id, payload: point });
  void flushPendingMutations();
}

function persistPointDeleteForSync(id: string) {
  // Même id que l'upsert : la suppression remplace une modification encore en attente.
  enqueue({ id: `point:${id}`, kind: "pointDelete", ref: id });
  void flushPendingMutations();
}

function persistSavingForSync(entry: Saving) {
  enqueue({ id: `saving:${entry.date}:${entry.sector}`, kind: "saving", ref: entry.date, payload: entry });
  void flushPendingMutations();
}

function incidentPayload(i: Incident): IncidentInput {
  const last = i.history && i.history.length ? i.history[i.history.length - 1].at : undefined;
  return {
    id: i.id,
    date: i.date,
    dueAt: i.dueAt ?? "",
    sector: i.sector,
    type: i.type,
    description: i.description,
    lat: i.lat,
    lng: i.lng,
    status: i.status,
    assignedTeamId: i.assignedTeamId ?? "",
    assignedAgentId: i.assignedAgentId,
    assignedAgentName: i.assignedAgentName,
    assignmentBasis: i.assignmentBasis,
    validatedGps: i.validatedGps,
    priority: i.priority,
    slaMinutes: i.slaMinutes,
    closedAt: i.closedAt,
    closedBy: i.closedBy,
    history: i.history ?? [],
    updatedAt: i.updatedAt ?? last ?? i.date,
  };
}

/** `photo: true` seulement quand la photo vient d'être ajoutée ou remplacée (pas à chaque changement de statut). */
function persistIncidentForSync(incident: Incident, opts?: { photo?: boolean }) {
  enqueue({ id: `incident:${incident.id}`, kind: "incident", ref: incident.id, payload: incidentPayload(incident) });
  if (opts?.photo) {
    if (incident.photoId) {
      enqueue({
        id: `photo:${incident.id}`,
        kind: "photo",
        ref: incident.id,
        incidentId: incident.id,
        photoId: incident.photoId,
      });
    } else if (typeof incident.photo === "string" && incident.photo.startsWith("data:")) {
      enqueue({ id: `photo:${incident.id}`, kind: "photo", ref: incident.id, incidentId: incident.id, dataUrl: incident.photo });
    }
  }
  void flushPendingMutations();
}

// ---------------------------------------------------------------------------
// Chargement serveur : on REJOUE la file d'abord, puis on relit, puis on
// repose par-dessus tout ce qui n'est pas encore parti.
// ---------------------------------------------------------------------------

type WorkspaceData = Awaited<ReturnType<typeof getWorkspace>>;

function applyServerData(data: WorkspaceData) {
  const pending = getOutbox().read();
  const merged = overlayPending(
    {
      points: data.points.map((p) => normalizePoint(p)),
      incidents: data.incidents as Incident[],
      savings: data.savings,
    },
    pending,
    { points: current.points, incidents: current.incidents },
  );
  current = {
    ...current,
    points: merged.points,
    incidents: merged.incidents,
    savings: merged.savings,
    teams: data.teams,
    vehicles: data.vehicles,
    sweepers: data.sweepers,
    operations: data.operations,
    circuits: data.circuits,
    members: data.members,
    depot: data.depot,
    role: data.me.role,
    // « ok » seulement si plus rien n'attend d'être envoyé.
    sync: pending.length ? "offline" : "ok",
    loaded: true,
  };
  lastRefreshAt = Date.now();
  persist();
  emit();
}

async function doRefresh() {
  // 1) Rejouer la file avant toute relecture : au démarrage, réseau déjà là, ça part tout de suite.
  const res = await getOutbox().flush();
  settleFlush(res);
  if (res.unauthorized) return;

  // 2) Relire le serveur. Si l'utilisateur agit pendant le chargement, on relit (2 essais max).
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const epoch = localEpoch;
    let data: WorkspaceData;
    try {
      data = await getWorkspace();
    } catch (err) {
      const message = err instanceof Error ? err.message : "";
      current = { ...current, sync: message === "Unauthorized" ? "auth" : "offline", loaded: true };
      emit();
      return;
    }
    if (epoch !== localEpoch && attempt < 2) continue;
    // 3) Poser les modifications locales encore en file par-dessus les données serveur.
    applyServerData(data);
    return;
  }
}

export function refreshFromServer(): Promise<void> {
  if (!refreshing) {
    refreshing = initStorage().then(doRefresh).finally(() => {
      refreshing = null;
    });
  }
  return refreshing;
}

/** Relit le serveur seulement si la dernière lecture est ancienne (retour d'onglet, par ex.). */
export function refreshIfStale(maxAgeMs: number) {
  if (Date.now() - lastRefreshAt > maxAgeMs) void refreshFromServer();
}

// ---------------------------------------------------------------------------
// Démarrage : on relit la mémoire locale (là où les modifications sont écrites)
// ---------------------------------------------------------------------------

type WorkspaceCache = Partial<
  Pick<FullState, "points" | "incidents" | "savings" | "session" | "teams" | "vehicles" | "sweepers" | "operations" | "circuits" | "depot" | "role">
>;

const LEGACY_KEYS = ["points", "incidents", "savings", "session"] as const;

const pointSignature = (p: Partial<Point>) =>
  JSON.stringify([p.name, p.address, p.neighborhood, p.status, p.lat, p.lng, p.fillLevel, p.priorityLevel, p.gpsValidatedAt]);

export function hydrate() {
  if (hydrated || typeof window === "undefined") return;
  hydrated = true;

  const cache = readKey<WorkspaceCache | null>("workspace", null);
  const legacyPoints = readKey<unknown>("points", null);
  const hasLegacy = Array.isArray(legacyPoints);

  let source: WorkspaceCache | null = cache && Array.isArray(cache.points) ? cache : null;
  if (hasLegacy) {
    // Anciennes versions : les modifications locales étaient dans cc_points / cc_incidents,
    // plus récentes que cc_workspace. On les reprend, puis on les envoie une fois.
    source = {
      ...(source ?? {}),
      points: legacyPoints as Point[],
      incidents: readKey<Incident[]>("incidents", []),
      savings: readKey<Saving[]>("savings", []),
      session: readKey<TourSession | null>("session", null),
    };
  }
  if (!source || !Array.isArray(source.points)) return;

  current = {
    ...current,
    points: source.points.filter(isValidPoint).map((p) => normalizePoint(p)),
    incidents: Array.isArray(source.incidents) ? source.incidents : [],
    savings: Array.isArray(source.savings) ? source.savings : [],
    session: source.session && Array.isArray(source.session.ids) ? source.session : null,
    teams: source.teams ?? [],
    vehicles: source.vehicles ?? [],
    sweepers: source.sweepers ?? [],
    operations: source.operations ?? [],
    circuits: source.circuits ?? [],
    depot: source.depot ?? DEPOT,
    role: source.role ?? "",
    sync: "offline",
  };

  if (hasLegacy) {
    const base = new Map((cache?.points ?? []).map((p) => [p.id, pointSignature(p)]));
    for (const point of current.points) {
      const known = base.get(point.id);
      const changed = known === undefined ? Boolean(cache) || Boolean(point.gpsValidatedAt) : known !== pointSignature(point);
      if (changed) enqueue({ id: `point:${point.id}`, kind: "point", ref: point.id, payload: point });
    }
    for (const incident of current.incidents) {
      enqueue({ id: `incident:${incident.id}`, kind: "incident", ref: incident.id, payload: incidentPayload(incident) });
      if (incident.photoId) {
        enqueue({ id: `photo:${incident.id}`, kind: "photo", ref: incident.id, incidentId: incident.id, photoId: incident.photoId });
      }
    }
    if (persist()) {
      for (const key of LEGACY_KEYS) getKv().remove(key);
    }
  }
  emit();
}

async function migrateLegacyPhotos() {
  let changed = false;
  const next: Incident[] = [];
  for (const inc of current.incidents) {
    if (typeof inc.photo === "string" && inc.photo.startsWith("data:")) {
      try {
        const photoId = "ph-" + inc.id;
        await putPhoto(photoId, inc.photo);
        const { photo: _drop, ...rest } = inc;
        next.push({ ...rest, photoId });
        changed = true;
        continue;
      } catch (err) {
        console.warn("[migration]", inc.id, err);
      }
    } else if ("photo" in inc && !inc.photo) {
      const { photo: _drop, ...rest } = inc;
      next.push(rest);
      changed = true;
      continue;
    }
    next.push(inc);
  }
  if (changed) {
    current = { ...current, incidents: next };
    persist();
    emit();
  }
}

export function setUi(patch: Partial<UiState>) {
  current = { ...current, ui: { ...current.ui, ...patch } };
  emit();
}

export function setPointStatus(id: string, status: PointStatus) {
  if (!VALID_STATUS.includes(status)) return;
  const updatedAt = new Date().toISOString();
  current = {
    ...current,
    points: current.points.map((p) => (p.id === id ? { ...p, status, updatedAt } : p)),
  };
  persist();
  emit();
  // Collecté / prioritaire / ignoré : c'est l'action terrain la plus fréquente, elle doit partir.
  const point = current.points.find((p) => p.id === id);
  if (point) persistPointForSync(point);
}

export function addPoint(data: Partial<Point>) {
  const p = normalizePoint({ ...data, id: "p" + Date.now(), updatedAt: new Date().toISOString() });
  current = {
    ...current,
    points: [...current.points, p],
    ui: { ...current.ui, search: "", sectorFilter: p.neighborhood },
  };
  persist();
  emit();
  persistPointForSync(p);
  return p;
}

export function updatePoint(id: string, data: Partial<Point>) {
  current = {
    ...current,
    points: current.points.map((p) =>
      p.id === id ? normalizePoint({ ...p, ...data, id, updatedAt: new Date().toISOString() }) : p,
    ),
  };
  persist();
  emit();
  const point = current.points.find((p) => p.id === id);
  if (point) persistPointForSync(point);
}

export function deletePoint(id: string) {
  const exists = current.points.some((point) => point.id === id);
  if (!exists) return;
  const session = current.session
    ? { ...current.session, ids: current.session.ids.filter((x) => x !== id) }
    : null;
  current = {
    ...current,
    points: current.points.filter((point) => point.id !== id),
    session: session && session.ids.length ? session : null,
  };
  persist();
  emit();
  // Plus d'appel serveur direct : la suppression passe par la file (rejouée si le réseau échoue).
  persistPointDeleteForSync(id);
}

export function setSession(session: TourSession) {
  current = { ...current, session };
  persist();
  emit();
}

export function resetTour() {
  current = {
    ...current,
    points: current.points.map((p) => ({ ...p, inTodayTour: true })),
    session: null,
    ui: { ...current.ui, tourSector: "Tous" },
  };
  persist();
  emit();
}

export function recordSaving(entry: Saving) {
  const idx = current.savings.findIndex((s) => s.date === entry.date && s.sector === entry.sector);
  const savings = [...current.savings];
  if (idx >= 0) savings[idx] = entry;
  else savings.push(entry);
  current = { ...current, savings };
  persist();
  emit();
  persistSavingForSync(entry);
}

export async function addIncident(input: {
  sector: string;
  type: string;
  description: string;
  photo?: string;
  lat: number | "";
  lng: number | "";
}) {
  const id = "INC-" + Date.now();
  const createdAt = new Date();
  const defaults = buildIncidentDefaults(input.type, createdAt);
  const origin = input.lat !== "" && input.lng !== ""
    ? { lat: Number(input.lat), lng: Number(input.lng) }
    : SECTOR_INFO[input.sector];
  const nearestTeam = origin
    ? [...current.teams]
        .map((team) => {
          const center = SECTOR_INFO[team.sector];
          return { team, distance: center ? haversine(origin, center) : Number.POSITIVE_INFINITY };
        })
        .sort((a, b) => a.distance - b.distance)[0]
    : undefined;
  const history: IncidentHistoryEntry[] = [
    {
      at: createdAt.toISOString(),
      action: "created",
      note: `${defaults.type} · SLA ${defaults.slaMinutes} min · priorité ${defaults.priority}`,
    },
  ];
  if (nearestTeam) {
    history.push({
      at: createdAt.toISOString(),
      action: "assigned",
      to: nearestTeam.team.name,
      note: "Proposition auto (centre secteur)",
    });
  }
  const incident: Incident = {
    id,
    date: createdAt.toISOString(),
    dueAt: defaults.dueAt,
    sector: input.sector,
    type: defaults.type,
    description: input.description,
    lat: input.lat,
    lng: input.lng,
    validatedGps: false,
    status: nearestTeam ? INCIDENT_STATUS.assigned : INCIDENT_STATUS.open,
    priority: defaults.priority,
    slaMinutes: defaults.slaMinutes,
    assignedTeamId: nearestTeam?.team.id,
    assignedTeamName: nearestTeam?.team.name,
    assignmentBasis: nearestTeam ? "sector-estimate" : undefined,
    history,
    updatedAt: createdAt.toISOString(),
  };
  if (input.photo) {
    try {
      await putPhoto("ph-" + id, input.photo);
      incident.photoId = "ph-" + id;
    } catch {
      incident.photo = input.photo;
    }
  }
  current = { ...current, incidents: [...current.incidents, incident] };
  persist();
  emit();
  persistIncidentForSync(incident, { photo: Boolean(incident.photoId || incident.photo) });
  return incident;
}

export function updateIncidentStatus(id: string, status: string) {
  current = {
    ...current,
    incidents: current.incidents.map((i) => {
      if (i.id !== id) return i;
      const entry: IncidentHistoryEntry = {
        at: new Date().toISOString(),
        action: "status_changed",
        from: i.status,
        to: status,
      };
      const patch: Partial<Incident> = {
        status,
        history: [...(i.history ?? []), entry],
        updatedAt: entry.at,
      };
      if (status === INCIDENT_STATUS.closed || status === "cloture") {
        patch.closedAt = new Date().toISOString();
      }
      return { ...i, ...patch };
    }),
  };
  persist();
  emit();
  const incident = current.incidents.find((i) => i.id === id);
  if (incident) persistIncidentForSync(incident);
}

export function closeIncident(id: string) {
  updateIncidentStatus(id, INCIDENT_STATUS.closed);
}

export function assignIncident(
  id: string,
  opts: {
    teamId: string;
    teamName: string;
    agentId?: string;
    agentName?: string;
    basis: AssignmentBasis;
  },
) {
  current = {
    ...current,
    incidents: current.incidents.map((i) => {
      if (i.id !== id) return i;
      const entry: IncidentHistoryEntry = {
        at: new Date().toISOString(),
        action: "assigned",
        to: opts.agentName ?? opts.teamName,
        note: opts.basis,
      };
      return {
        ...i,
        status: INCIDENT_STATUS.assigned,
        assignedTeamId: opts.teamId,
        assignedTeamName: opts.teamName,
        assignedAgentId: opts.agentId,
        assignedAgentName: opts.agentName,
        assignmentBasis: opts.basis,
        history: [...(i.history ?? []), entry],
        updatedAt: entry.at,
      };
    }),
  };
  persist();
  emit();
  const incident = current.incidents.find((i) => i.id === id);
  if (incident) persistIncidentForSync(incident);
}

export function validatePointGps(
  id: string,
  coords: { lat: number; lng: number; accuracy?: number; source?: "device" | "manual" },
) {
  current = {
    ...current,
    points: current.points.map((p) => {
      if (p.id !== id) return p;
      return {
        ...p,
        lat: coords.lat,
        lng: coords.lng,
        gpsValidatedAt: new Date().toISOString(),
        gpsSource: coords.source ?? "device",
        gpsAccuracyM: coords.accuracy,
        updatedAt: new Date().toISOString(),
      };
    }),
  };
  persist();
  emit();
  const point = current.points.find((p) => p.id === id);
  if (point) persistPointForSync(point);
}

export async function getIncidentPhoto(inc: Incident) {
  if (inc.photo) return inc.photo;
  // 1) copie locale (IndexedDB) — l'identifiant est déterministe, il survit à un rechargement serveur
  const local = (inc.photoId ? await getPhoto(inc.photoId) : undefined) || (await getPhoto("ph-" + inc.id));
  if (local) return local;
  // 2) sinon, à la demande depuis le serveur (la photo n'est plus embarquée dans chaque chargement)
  if (!inc.hasPhoto) return "";
  try {
    const { photo } = await getIncidentPhotoRemote(inc.id);
    if (photo) await putPhoto("ph-" + inc.id, photo).catch(() => undefined);
    return photo;
  } catch {
    return "";
  }
}

/** Ajoute ou remplace la photo d'un constat existant (chef secteur / équipe sur le terrain). */
export async function attachIncidentPhoto(id: string, dataUrl: string) {
  const incident = current.incidents.find((i) => i.id === id);
  if (!incident) {
    toast("Constat introuvable", "error");
    return;
  }
  const photoId = "ph-" + id;
  try {
    await putPhoto(photoId, dataUrl);
  } catch (err) {
    console.warn("[photo]", err);
    // fallback inline si IndexedDB indisponible
    current = {
      ...current,
      incidents: current.incidents.map((i) =>
        i.id === id
          ? {
              ...i,
              photo: dataUrl,
              photoId: undefined,
              history: [
                ...(i.history ?? []),
                { at: new Date().toISOString(), action: "photo_attached", note: "Photo jointe (inline)" },
              ],
              updatedAt: new Date().toISOString(),
            }
          : i,
      ),
    };
    persist();
    emit();
    const inline = current.incidents.find((i) => i.id === id);
    if (inline) persistIncidentForSync(inline, { photo: true });
    return;
  }
  current = {
    ...current,
    incidents: current.incidents.map((i) =>
      i.id === id
        ? {
            ...i,
            photoId,
            photo: undefined,
            history: [
              ...(i.history ?? []),
              { at: new Date().toISOString(), action: "photo_attached", note: "Photo d'anomalie jointe" },
            ],
            updatedAt: new Date().toISOString(),
          }
        : i,
    ),
  };
  persist();
  emit();
  const updated = current.incidents.find((i) => i.id === id);
  if (updated) persistIncidentForSync(updated, { photo: true });
}

export async function exportBackup() {
  const incidents = [];
  for (const inc of current.incidents) {
    const { photoId: _id, ...rest } = inc;
    const photo = await getIncidentPhoto(inc);
    incidents.push(photo ? { ...rest, photo } : rest);
  }
  return {
    app: "albayda",
    points: current.points,
    incidents,
    savings: current.savings,
    session: current.session,
    exportedAt: new Date().toISOString(),
  };
}

export async function importBackup(data: unknown) {
  if (!data || typeof data !== "object" || !Array.isArray((data as { points?: unknown }).points)) {
    throw new Error("Fichier de sauvegarde invalide");
  }
  const raw = data as {
    points: unknown[];
    incidents?: Incident[];
    savings?: Saving[];
    session?: TourSession | null;
  };
  const points = raw.points.filter(isValidPoint).map((p) => normalizePoint(p));
  if (!points.length && raw.points.length) throw new Error("Fichier de sauvegarde invalide");
  await clearPhotos();
  const session = raw.session && Array.isArray(raw.session.ids) ? raw.session : null;
  current = {
    ...current,
    points,
    incidents: Array.isArray(raw.incidents) ? raw.incidents : [],
    savings: Array.isArray(raw.savings) ? raw.savings : [],
    session,
  };
  persist();
  emit();
  await migrateLegacyPhotos();
}

export function statsOf(data: AppData) {
  const { points, incidents } = data;
  const collected = points.filter((p) => p.status === "collected").length;
  const priority = points.filter((p) => p.priorityLevel >= 3 || p.fillLevel >= 80 || p.status === "priority").length;
  return {
    total: points.length,
    collected,
    skipped: points.filter((p) => p.status === "skipped").length,
    priority,
    openIncidents: incidents.filter((i) => i.status !== INCIDENT_STATUS.closed && i.status !== "cloture" && i.status !== "annule").length,
    totalIncidents: incidents.length,
    collectedPct: points.length ? Math.round((collected / points.length) * 100) : 0,
  };
}

export function isPriority(p: Point) {
  return p.status === "priority" || p.fillLevel >= 80 || p.priorityLevel >= 3;
}

export function todayISO() {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function formatDateTime(iso: string) {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "—" : d.toLocaleString("fr-FR");
}

export function toCsv(rows: Array<Array<string | number>>) {
  const cell = (v: string | number) => '"' + String(v ?? "").replaceAll('"', '""') + '"';
  return "\uFEFF" + rows.map((r) => r.map(cell).join(";")).join("\n");
}

export function downloadText(filename: string, content: string, mime: string) {
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export async function shareText(title: string, text: string) {
  if (typeof navigator !== "undefined" && navigator.share) {
    await navigator.share({ title, text });
    return;
  }
  downloadText("rapport-albayda.txt", text, "text/plain");
}
