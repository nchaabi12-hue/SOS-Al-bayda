export const APP = {
  name: "SOS Al Bayda",
  version: "4.1.0",
  label: "NOUVELLE DYNAMIQUE DURABLE",
} as const;

export const SECTORS = [
  "Hay Mohammadi",
  "Hay Adil",
  "Aïn Borja",
  "Belvédère",
  "Roches Noires",
  "Aïn Sebaâ",
  "Al Bayda",
  "Sidi Bernoussi",
  "Sidi Moumen",
] as const;

export type Sector = (typeof SECTORS)[number];

/** Dépôt de départ. Modifiable par l'administrateur. */
export const DEPOT = { name: "Dépôt Belvédère", lat: 33.5985, lng: -7.586 };

/** Lot SOS NDD : préfectures d'arrondissement réellement attribuées. */
export const SECTOR_INFO: Record<
  string,
  { group: string; lat: number; lng: number }
> = {
  "Hay Mohammadi": { group: "Aïn Sebaâ – Hay Mohammadi", lat: 33.5892, lng: -7.5618 },
  "Hay Adil": { group: "Aïn Sebaâ – Hay Mohammadi", lat: 33.5873, lng: -7.5552 },
  "Aïn Borja": { group: "Aïn Sebaâ – Hay Mohammadi", lat: 33.5949, lng: -7.5659 },
  Belvédère: { group: "Aïn Sebaâ – Hay Mohammadi", lat: 33.5925, lng: -7.5872 },
  "Roches Noires": { group: "Aïn Sebaâ – Hay Mohammadi", lat: 33.6008, lng: -7.5788 },
  "Aïn Sebaâ": { group: "Aïn Sebaâ – Hay Mohammadi", lat: 33.6035, lng: -7.5325 },
  "Al Bayda": { group: "Aïn Sebaâ – Hay Mohammadi", lat: 33.5995, lng: -7.5488 },
  "Sidi Bernoussi": { group: "Sidi Bernoussi", lat: 33.6152, lng: -7.4935 },
  "Sidi Moumen": { group: "Sidi Bernoussi", lat: 33.5868, lng: -7.5065 },
};

export const ROLES = ["admin", "superviseur", "controleur"] as const;
export type Role = (typeof ROLES)[number];
export const ROLE_LABELS: Record<Role, string> = {
  admin: "Administrateur",
  superviseur: "Superviseur",
  controleur: "Contrôleur",
};

export const VEHICLE_KINDS = ["BOM", "Benne", "Balayeuse", "Camion"] as const;
export const OP_KINDS = ["Balayage", "Lavage", "Collecte manuelle"] as const;

export const TOUR = {
  roadFactor: 1.3,
  speedKmh: 25,
  serviceMinPerPoint: 3,
} as const;

export const SAVINGS = {
  kmPerLiter: 10,
  madPerLiter: 13,
} as const;

export const STATUS_LABELS = {
  toCollect: "À collecter",
  priority: "Prioritaire",
  collected: "Collecté",
  skipped: "Ignoré",
} as const;

export const INCIDENT_TYPES = [
  "Dépôt sauvage",
  "Débordement de bacs",
  "Déchets verts",
  "Encombrants",
  "Salissures",
  "Défaut de balayage",
] as const;

export type IncidentType = (typeof INCIDENT_TYPES)[number];

/** SLA en minutes selon le type d'anomalie */
export const INCIDENT_SLA_MINUTES: Record<IncidentType, number> = {
  "Dépôt sauvage": 120,
  "Débordement de bacs": 90,
  "Déchets verts": 180,
  Encombrants: 240,
  Salissures: 180,
  "Défaut de balayage": 240,
};

/** Priorité métier 1 (basse) → 5 (critique) */
export const INCIDENT_PRIORITY: Record<IncidentType, number> = {
  "Dépôt sauvage": 4,
  "Débordement de bacs": 5,
  "Déchets verts": 3,
  Encombrants: 3,
  Salissures: 2,
  "Défaut de balayage": 2,
};

/** Cycle de vie du constat */
export const INCIDENT_STATUS = {
  open: "ouvert",
  assigned: "assigné",
  inProgress: "en_intervention",
  closed: "clôturé",
  cancelled: "annule",
} as const;

export type IncidentStatus = (typeof INCIDENT_STATUS)[keyof typeof INCIDENT_STATUS];

export const INCIDENT_STATUS_LABELS: Record<string, string> = {
  ouvert: "À intervenir",
  assigné: "Assigné",
  en_intervention: "En intervention",
  "en intervention": "En intervention",
  "clôturé": "Clôturé",
  cloture: "Clôturé",
  annule: "Annulé",
};

export type AssignmentBasis = "sector-estimate" | "live-gps" | "manual";

export type IncidentHistoryEntry = {
  at: string;
  by?: string;
  action: string;
  from?: string;
  to?: string;
  note?: string;
};

/** Ouest, sud, est, nord — emprise du lot (Belvédère → Sidi Bernoussi). */
export const MAP_BBOX = [-7.63, 33.56, -7.46, 33.64] as const;

export const STORAGE_PREFIX = "cc_";

export type PointStatus = keyof typeof STATUS_LABELS;

export type Point = {
  id: string;
  name: string;
  neighborhood: string;
  address: string;
  lat: number;
  lng: number;
  status: PointStatus;
  inTodayTour: boolean;
  fillLevel: number;
  priorityLevel: number;
  /** Position validée / corrigée sur le terrain */
  gpsValidatedAt?: string;
  gpsSource?: "seed" | "manual" | "device";
  gpsAccuracyM?: number;
  /** Dernière modification locale (ISO) — sert à ne pas écraser une version plus récente. */
  updatedAt?: string;
};

export type Incident = {
  id: string;
  date: string;
  dueAt?: string;
  sector: string;
  type: string;
  description: string;
  lat: number | "";
  lng: number | "";
  validatedGps?: boolean;
  status: string;
  priority?: number;
  slaMinutes?: number;
  assignedTeamId?: string;
  assignedTeamName?: string;
  assignedAgentId?: string;
  assignedAgentName?: string;
  assignmentBasis?: AssignmentBasis;
  photoId?: string;
  photo?: string;
  /** Le serveur détient une photo pour ce constat (récupérée à la demande). */
  hasPhoto?: boolean;
  /** Dernière modification locale (ISO). */
  updatedAt?: string;
  closedAt?: string;
  closedBy?: string;
  history?: IncidentHistoryEntry[];
};

export type Saving = {
  date: string;
  sector: string;
  km: number;
  points?: number;
};

export type TourSession = {
  ids: string[];
  km: number;
  minutes: number;
  savedKm: number;
  sector: string;
  teamId?: string;
  vehicleId?: string;
  roadKm?: number | null;
  geometry?: Array<[number, number]>;
  source?: "estime" | "route";
};

export type AppData = {
  points: Point[];
  incidents: Incident[];
  savings: Saving[];
  session: TourSession | null;
};

/** Calcule dueAt, priorité et SLA à partir du type */
export function buildIncidentDefaults(type: string, createdAt = new Date()) {
  const t = (INCIDENT_TYPES as readonly string[]).includes(type)
    ? (type as IncidentType)
    : ("Dépôt sauvage" as IncidentType);
  const slaMinutes = INCIDENT_SLA_MINUTES[t] ?? 120;
  const priority = INCIDENT_PRIORITY[t] ?? 3;
  const dueAt = new Date(createdAt.getTime() + slaMinutes * 60_000).toISOString();
  return { slaMinutes, priority, dueAt, type: t };
}

/** Score d'urgence pour tri dispatch (plus haut = plus urgent) */
export function urgencyScore(inc: Incident, now = Date.now()): number {
  const due = inc.dueAt ? new Date(inc.dueAt).getTime() : now + 3_600_000;
  const remainingMin = (due - now) / 60_000;
  const overdueBoost = remainingMin < 0 ? 1000 : 0;
  const criticalBoost = remainingMin >= 0 && remainingMin < 30 ? 200 : 0;
  return overdueBoost + criticalBoost + (inc.priority ?? 3) * 20 - remainingMin;
}
