const DB_NAME = "casabaia-collecte";
const STORE = "photos";

/** Réglages optimisés pour photos d'anomalie terrain (mobile). */
export const PHOTO_DEFAULTS = {
  /** Côté long max en pixels (détail suffisant pour dépôt / débordement). */
  maxSide: 1280,
  /** Qualité JPEG de départ (0–1). */
  quality: 0.72,
  /** Taille cible max de la data-URL (octets). ~280 Ko utiles hors préfixe. */
  maxBytes: 280_000,
  /** Qualité minimale si on doit rebaisser pour tenir la taille. */
  minQuality: 0.45,
  /** Pas de baisse de qualité entre deux essais. */
  qualityStep: 0.07,
} as const;

function openDb() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB indisponible"));
      return;
    }
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function tx<T>(mode: IDBTransactionMode, fn: (store: IDBObjectStore) => IDBRequest<T>) {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const t = db.transaction(STORE, mode);
        const req = fn(t.objectStore(STORE));
        t.oncomplete = () => {
          db.close();
          resolve(req.result);
        };
        t.onerror = () => {
          db.close();
          reject(t.error);
        };
        t.onabort = () => {
          db.close();
          reject(t.error);
        };
      }),
  );
}

export const putPhoto = (id: string, dataUrl: string) => tx("readwrite", (s) => s.put(dataUrl, id));
export const getPhoto = (id: string) =>
  tx<string | undefined>("readonly", (s) => s.get(id)).catch(() => undefined);
export const clearPhotos = () => tx("readwrite", (s) => s.clear()).catch(() => undefined);

/** Taille approximative en octets d'une data-URL base64. */
export function dataUrlByteLength(dataUrl: string): number {
  const i = dataUrl.indexOf(",");
  const b64 = i >= 0 ? dataUrl.slice(i + 1) : dataUrl;
  const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
  return Math.floor((b64.length * 3) / 4) - padding;
}

function loadImageFromFile(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Image illisible"));
    };
    img.src = url;
  });
}

/**
 * Orientation EXIF (1–8). Nécessaire pour les photos iPhone / Android
 * qui stockent la rotation dans les métadonnées plutôt que dans les pixels.
 */
async function readExifOrientation(file: File): Promise<number> {
  try {
    const buf = await file.slice(0, 64 * 1024).arrayBuffer();
    const view = new DataView(buf);
    if (view.byteLength < 2 || view.getUint16(0, false) !== 0xffd8) return 1;
    let offset = 2;
    while (offset + 4 < view.byteLength) {
      const marker = view.getUint16(offset, false);
      offset += 2;
      if (marker === 0xffe1) {
        // APP1 — EXIF
        const length = view.getUint16(offset, false);
        if (offset + length > view.byteLength) break;
        // "Exif\0\0"
        if (
          view.getUint32(offset + 2, false) !== 0x45786966 ||
          view.getUint16(offset + 6, false) !== 0
        ) {
          offset += length;
          continue;
        }
        const tiff = offset + 8;
        const little = view.getUint16(tiff, false) === 0x4949;
        if (view.getUint16(tiff + 2, little) !== 0x002a) break;
        const ifd0 = tiff + view.getUint32(tiff + 4, little);
        if (ifd0 + 2 > view.byteLength) break;
        const entries = view.getUint16(ifd0, little);
        for (let i = 0; i < entries; i++) {
          const entry = ifd0 + 2 + i * 12;
          if (entry + 12 > view.byteLength) break;
          const tag = view.getUint16(entry, little);
          if (tag === 0x0112) {
            return view.getUint16(entry + 8, little) || 1;
          }
        }
        break;
      }
      if ((marker & 0xff00) !== 0xff00) break;
      if (offset + 2 > view.byteLength) break;
      offset += view.getUint16(offset, false);
    }
  } catch {
    // ignore
  }
  return 1;
}

function drawOriented(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  orientation: number,
  w: number,
  h: number,
) {
  // w/h = dimensions déjà mises à l'échelle (canvas size peut être swapée)
  switch (orientation) {
    case 2:
      ctx.translate(w, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(img, 0, 0, w, h);
      break;
    case 3:
      ctx.translate(w, h);
      ctx.rotate(Math.PI);
      ctx.drawImage(img, 0, 0, w, h);
      break;
    case 4:
      ctx.translate(0, h);
      ctx.scale(1, -1);
      ctx.drawImage(img, 0, 0, w, h);
      break;
    case 5:
      ctx.rotate(0.5 * Math.PI);
      ctx.scale(1, -1);
      ctx.drawImage(img, 0, 0, h, w);
      break;
    case 6:
      ctx.rotate(0.5 * Math.PI);
      ctx.translate(0, -h);
      ctx.drawImage(img, 0, 0, h, w);
      break;
    case 7:
      ctx.rotate(0.5 * Math.PI);
      ctx.translate(w, -h);
      ctx.scale(-1, 1);
      ctx.drawImage(img, 0, 0, h, w);
      break;
    case 8:
      ctx.rotate(-0.5 * Math.PI);
      ctx.translate(-w, 0);
      ctx.drawImage(img, 0, 0, h, w);
      break;
    default:
      ctx.drawImage(img, 0, 0, w, h);
  }
}

function canvasSizeFor(orientation: number, drawW: number, drawH: number) {
  // orientations 5–8 : largeur/hauteur échangées sur le canvas final
  if (orientation >= 5 && orientation <= 8) {
    return { width: drawH, height: drawW };
  }
  return { width: drawW, height: drawH };
}

export type CompressOptions = {
  maxSide?: number;
  quality?: number;
  maxBytes?: number;
  minQuality?: number;
};

export type CompressResult = {
  dataUrl: string;
  width: number;
  height: number;
  bytes: number;
  quality: number;
};

/**
 * Compresse une photo terrain :
 * - redimensionnement (côté max)
 * - correction d'orientation EXIF
 * - JPEG avec baisse progressive de qualité jusqu'à maxBytes
 */
export async function compressImageDetailed(
  file: File,
  options: CompressOptions = {},
): Promise<CompressResult> {
  const maxSide = options.maxSide ?? PHOTO_DEFAULTS.maxSide;
  const maxBytes = options.maxBytes ?? PHOTO_DEFAULTS.maxBytes;
  const minQuality = options.minQuality ?? PHOTO_DEFAULTS.minQuality;
  let quality = options.quality ?? PHOTO_DEFAULTS.quality;

  // Fichiers déjà petits et JPEG : on peut parfois garder tel quel si < maxBytes et pas trop grands
  // (mais on recompresse quand même pour normaliser orientation + strip EXIF métadonnées lourdes)

  const [img, orientation] = await Promise.all([loadImageFromFile(file), readExifOrientation(file)]);

  const srcW = img.naturalWidth || img.width;
  const srcH = img.naturalHeight || img.height;
  if (!srcW || !srcH) {
    throw new Error("Image sans dimensions");
  }

  const scale = Math.min(1, maxSide / Math.max(srcW, srcH));
  const drawW = Math.max(1, Math.round(srcW * scale));
  const drawH = Math.max(1, Math.round(srcH * scale));
  const { width, height } = canvasSizeFor(orientation, drawW, drawH);

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    // Fallback très rare
    const reader = new FileReader();
    const dataUrl = await new Promise<string>((resolve, reject) => {
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
    return {
      dataUrl,
      width: srcW,
      height: srcH,
      bytes: dataUrlByteLength(dataUrl),
      quality: 1,
    };
  }

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  // Fond blanc (évite transparence → noir en JPEG)
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, width, height);
  drawOriented(ctx, img, orientation, drawW, drawH);

  let dataUrl = canvas.toDataURL("image/jpeg", quality);
  let bytes = dataUrlByteLength(dataUrl);

  while (bytes > maxBytes && quality > minQuality + 0.001) {
    quality = Math.max(minQuality, quality - PHOTO_DEFAULTS.qualityStep);
    dataUrl = canvas.toDataURL("image/jpeg", quality);
    bytes = dataUrlByteLength(dataUrl);
  }

  // Dernier recours : réduire encore la résolution si toujours trop lourd
  if (bytes > maxBytes && Math.max(width, height) > 640) {
    const shrink = Math.sqrt(maxBytes / bytes) * 0.95;
    const w2 = Math.max(320, Math.round(width * shrink));
    const h2 = Math.max(320, Math.round(height * shrink));
    const c2 = document.createElement("canvas");
    c2.width = w2;
    c2.height = h2;
    const ctx2 = c2.getContext("2d");
    if (ctx2) {
      ctx2.imageSmoothingEnabled = true;
      ctx2.imageSmoothingQuality = "high";
      ctx2.fillStyle = "#ffffff";
      ctx2.fillRect(0, 0, w2, h2);
      ctx2.drawImage(canvas, 0, 0, w2, h2);
      quality = Math.max(minQuality, quality);
      dataUrl = c2.toDataURL("image/jpeg", quality);
      bytes = dataUrlByteLength(dataUrl);
      return { dataUrl, width: w2, height: h2, bytes, quality };
    }
  }

  return { dataUrl, width, height, bytes, quality };
}

/**
 * API simple (rétrocompatible) : retourne uniquement la data-URL JPEG optimisée.
 */
export function compressImage(
  file: File,
  maxSide = PHOTO_DEFAULTS.maxSide,
  quality = PHOTO_DEFAULTS.quality,
): Promise<string> {
  return compressImageDetailed(file, { maxSide, quality }).then((r) => r.dataUrl);
}

/** Version terrain recommandée (taille cible + orientation). */
export function compressAnomalyPhoto(file: File): Promise<CompressResult> {
  return compressImageDetailed(file, {
    maxSide: PHOTO_DEFAULTS.maxSide,
    quality: PHOTO_DEFAULTS.quality,
    maxBytes: PHOTO_DEFAULTS.maxBytes,
  });
}
