import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createKv } from "./kv.ts";
import type { KvBackend } from "./kv.ts";

function fakeBackend(initial: Record<string, string> = {}, opts: { failLoad?: boolean; failPut?: boolean; delay?: number } = {}) {
  const data = { ...initial };
  const puts: string[] = [];
  const backend: KvBackend = {
    async loadAll() {
      if (opts.failLoad) throw new Error("IndexedDB indisponible");
      return { ...data };
    },
    async put(k, v) {
      await new Promise((r) => setTimeout(r, opts.delay ?? 1));
      if (opts.failPut) throw new Error("QuotaExceeded");
      puts.push(k);
      data[k] = v;
    },
    async remove(k) {
      delete data[k];
    },
  };
  return { backend, data, puts };
}

function fakeLegacy(initial: Record<string, string> = {}) {
  const m = new Map(Object.entries(initial));
  return { m, get: (k: string) => m.get(k) ?? null, set: (k: string, v: string) => void m.set(k, v), remove: (k: string) => void m.delete(k) };
}

describe("stockage durable (kv)", () => {
  it("lecture synchrone immédiate après écriture, persistée ensuite", async () => {
    const { backend, data } = fakeBackend();
    const kv = createKv({ backend });
    await kv.load();
    kv.set("queue", "[1]");
    assert.equal(kv.get("queue"), "[1]");
    await kv.idle();
    assert.equal(data.queue, "[1]");
  });

  it("regroupe les écritures d'une même clé : la dernière gagne", async () => {
    const { backend, data } = fakeBackend();
    const kv = createKv({ backend });
    await kv.load();
    for (let i = 0; i < 20; i++) kv.set("queue", `v${i}`);
    await kv.idle();
    assert.equal(data.queue, "v19");
  });

  it("relit après redémarrage ce qui avait été écrit", async () => {
    const { backend } = fakeBackend();
    const a = createKv({ backend });
    await a.load();
    a.set("workspace", "{\"points\":[]}");
    await a.idle();
    const b = createKv({ backend });
    await b.load();
    assert.equal(b.get("workspace"), "{\"points\":[]}");
  });

  it("migre les anciennes clés localStorage puis les supprime", async () => {
    const { backend, data } = fakeBackend();
    const legacy = fakeLegacy({ "cc_pending": "[{\"id\":\"x\"}]" });
    const kv = createKv({ backend, legacy: { get: (k) => legacy.get("cc_" + k), set: (k, v) => legacy.set("cc_" + k, v), remove: (k) => legacy.remove("cc_" + k) }, legacyKeys: ["pending"] });
    await kv.load();
    assert.equal(kv.get("pending"), "[{\"id\":\"x\"}]");
    assert.equal(data.pending, "[{\"id\":\"x\"}]");
    assert.equal(legacy.m.size, 0);
  });

  it("ne remplace jamais une valeur IndexedDB par une ancienne valeur localStorage", async () => {
    const { backend } = fakeBackend({ pending: "NOUVEAU" });
    const legacy = fakeLegacy({ "cc_pending": "ANCIEN" });
    const kv = createKv({ backend, legacy: { get: (k) => legacy.get("cc_" + k), set: () => {}, remove: (k) => legacy.remove("cc_" + k) }, legacyKeys: ["pending"] });
    await kv.load();
    assert.equal(kv.get("pending"), "NOUVEAU");
  });

  it("IndexedDB indisponible : repli sur localStorage, rien n'est perdu", async () => {
    const { backend } = fakeBackend({}, { failLoad: true });
    const legacy = fakeLegacy({ "cc_pending": "[1]" });
    const errors: unknown[] = [];
    const kv = createKv({
      backend,
      legacy: { get: (k) => legacy.get("cc_" + k), set: (k, v) => legacy.set("cc_" + k, v), remove: (k) => legacy.remove("cc_" + k) },
      legacyKeys: ["pending"],
      onError: (e) => errors.push(e),
    });
    await kv.load();
    assert.equal(kv.isDegraded(), true);
    assert.equal(kv.get("pending"), "[1]");
    kv.set("pending", "[1,2]");
    assert.equal(legacy.m.get("cc_pending"), "[1,2]");
    assert.equal(errors.length, 1);
  });

  it("échec d'écriture : signalé, la valeur reste lisible en mémoire", async () => {
    const { backend } = fakeBackend({}, { failPut: true });
    const errors: unknown[] = [];
    const kv = createKv({ backend, onError: (e) => errors.push(e) });
    await kv.load();
    kv.set("queue", "x");
    await kv.idle();
    assert.equal(kv.get("queue"), "x");
    assert.equal(errors.length, 1);
  });

  it("suppression persistée", async () => {
    const { backend, data } = fakeBackend({ a: "1" });
    const kv = createKv({ backend });
    await kv.load();
    kv.remove("a");
    assert.equal(kv.get("a"), null);
    await kv.idle();
    assert.equal("a" in data, false);
  });
});
