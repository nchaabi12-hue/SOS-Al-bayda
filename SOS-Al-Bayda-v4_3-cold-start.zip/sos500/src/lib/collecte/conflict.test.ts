import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { isStale, mergeHistory, resolveIncidentWrite } from "./conflict.ts";
import type { HistoryEntry } from "./conflict.ts";

const e = (at: string, action: string, to?: string): HistoryEntry => ({ at, action, to });

describe("conflits entre téléphones", () => {
  it("fusionne les historiques sans perte et sans doublon", () => {
    const a = [e("2026-11-14T08:00:00Z", "created"), e("2026-11-14T09:00:00Z", "assigned", "Équipe A")];
    const b = [e("2026-11-14T08:00:00Z", "created"), e("2026-11-14T08:30:00Z", "status_changed", "en_cours")];
    const m = mergeHistory(a, b);
    assert.deepEqual(m.map((x) => x.action), ["created", "status_changed", "assigned"]);
  });

  it("la fusion donne le même résultat quel que soit l'ordre d'arrivée", () => {
    const a = [e("2026-11-14T08:00:00Z", "created"), e("2026-11-14T10:00:00Z", "closed")];
    const b = [e("2026-11-14T09:00:00Z", "assigned", "B")];
    assert.deepEqual(mergeHistory(a, b), mergeHistory(b, a));
  });

  it("refuse une version plus ancienne, accepte égale / plus récente / sans horodatage", () => {
    assert.equal(isStale("2026-11-14T08:00:00Z", "2026-11-14T09:00:00Z"), true);
    assert.equal(isStale("2026-11-14T09:00:00Z", "2026-11-14T09:00:00Z"), false);
    assert.equal(isStale("2026-11-14T10:00:00Z", "2026-11-14T09:00:00Z"), false);
    assert.equal(isStale(undefined, "2026-11-14T09:00:00Z"), false);
    assert.equal(isStale("2026-11-14T09:00:00Z", null), false);
  });

  it("nouveau constat : insertion", () => {
    const r = resolveIncidentWrite(null, { history: [e("2026-11-14T08:00:00Z", "created")] });
    assert.equal(r.kind, "insert");
    assert.equal(r.history.length, 1);
  });

  it("deux contrôleurs modifient le même constat : le plus récent gagne, l'historique des deux est gardé", () => {
    // Serveur : modifié à 10:00 par le téléphone A (clôture).
    const server = {
      updatedAt: "2026-11-14T10:00:00Z",
      history: [e("2026-11-14T08:00:00Z", "created"), e("2026-11-14T10:00:00Z", "status_changed", "cloture")],
    };
    // Téléphone B, hors ligne, a changé le statut à 09:00 et se synchronise après.
    const fromB = { updatedAt: "2026-11-14T09:00:00Z", history: [e("2026-11-14T08:00:00Z", "created"), e("2026-11-14T09:00:00Z", "status_changed", "en_cours")] };
    const r = resolveIncidentWrite(server, fromB);
    assert.equal(r.kind, "history-only"); // le statut « clôturé » n'est pas écrasé
    assert.equal(r.history.length, 3); // mais la trace du téléphone B est conservée
  });

  it("une version plus récente met à jour les champs", () => {
    const server = { updatedAt: "2026-11-14T09:00:00Z", history: [] as HistoryEntry[] };
    const r = resolveIncidentWrite(server, { updatedAt: "2026-11-14T11:00:00Z", history: [e("2026-11-14T11:00:00Z", "closed")] });
    assert.equal(r.kind, "update");
  });

  it("la même mutation rejouée deux fois (réseau coupé après réception) est idempotente", () => {
    const incoming = { updatedAt: "2026-11-14T09:00:00Z", history: [e("2026-11-14T09:00:00Z", "assigned", "A")] };
    const first = resolveIncidentWrite({ updatedAt: null, history: [] }, incoming);
    const second = resolveIncidentWrite({ updatedAt: incoming.updatedAt, history: first.history }, incoming);
    assert.equal(second.kind, "update");
    assert.deepEqual(second.history, first.history);
  });
});
