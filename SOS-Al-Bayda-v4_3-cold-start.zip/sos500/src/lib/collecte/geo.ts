import { DEPOT, TOUR } from "./config";
import type { Point } from "./config";

const R = 6371e3;
const RAD = Math.PI / 180;

export type LatLng = { lat: number; lng: number };

/** Distance à vol d'oiseau, en mètres. */
export function haversine(a: LatLng, b: LatLng) {
  const dLat = (b.lat - a.lat) * RAD;
  const dLng = (b.lng - a.lng) * RAD;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(a.lat * RAD) * Math.cos(b.lat * RAD) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Plus proche voisin depuis le dépôt. Ne modifie pas le tableau reçu. */
export function nearestNeighbor<T extends LatLng>(points: T[], start: LatLng = DEPOT): T[] {
  const rest = [...points];
  const order: T[] = [];
  let current: LatLng = start;
  while (rest.length) {
    let best = 0;
    let bestDist = Infinity;
    for (let i = 0; i < rest.length; i++) {
      const d = haversine(current, rest[i]);
      if (d < bestDist) {
        bestDist = d;
        best = i;
      }
    }
    const next = rest.splice(best, 1)[0];
    order.push(next);
    current = next;
  }
  return order;
}

/** Distance routière estimée (km) : dépôt → points → dépôt, × facteur routier. */
export function routeKm(order: LatLng[], depot: LatLng = DEPOT) {
  if (!order.length) return 0;
  let meters = 0;
  let current = depot;
  for (const p of order) {
    meters += haversine(current, p);
    current = p;
  }
  meters += haversine(current, depot);
  return (meters * TOUR.roadFactor) / 1000;
}

export function estimateMinutes(km: number, stops: number) {
  return Math.round((km / TOUR.speedKmh) * 60 + stops * TOUR.serviceMinPerPoint);
}

export function planTour(points: Point[]) {
  const order = nearestNeighbor(points);
  const km = routeKm(order);
  const baselineKm = routeKm(points);
  return {
    order,
    km: Number(km.toFixed(1)),
    minutes: estimateMinutes(km, order.length),
    baselineKm: Number(baselineKm.toFixed(1)),
    savedKm: Math.max(0, Number((baselineKm - km).toFixed(1))),
  };
}

export async function getPosition(): Promise<LatLng> {
  try {
    const { Geolocation } = await import("@capacitor/geolocation");
    const pos = await Geolocation.getCurrentPosition({
      enableHighAccuracy: true,
      timeout: 12_000,
    });
    return { lat: pos.coords.latitude, lng: pos.coords.longitude };
  } catch {
    // fallback navigateur
  }
  if (!("geolocation" in navigator)) throw new Error("unavailable");
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      reject,
      { enableHighAccuracy: true, timeout: 12000 },
    );
  });
}
