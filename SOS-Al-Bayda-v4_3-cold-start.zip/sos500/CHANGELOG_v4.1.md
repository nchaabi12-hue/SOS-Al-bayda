# SOS AL BAYDA v4.1 — Intégration Android + Dispatch + GPS + Modèle constats

## Nouveautés

### Capacitor / Android
- `capacitor.config.ts` enrichi (Geolocation, Camera, Push, LocalNotifications, Splash)
- Dépendances plugins ajoutées dans `package.json`
- Workflow `.github/workflows/android-apk.yml` pour build APK debug
- Guide mis à jour (`GUIDE_ANDROID_SOS_AL_BAYDA.md`)

### Modèle constats
- SLA variable par type (`INCIDENT_SLA_MINUTES`)
- Priorité métier 1–5 (`INCIDENT_PRIORITY`)
- Statuts : ouvert → assigné → en_intervention → clôturé / annule
- Historique d'audit (`history[]`) sur chaque constat
- `buildIncidentDefaults()` + `urgencyScore()`

### Dispatch (`/dispatch`)
- Écran d'affectation trié par urgence
- Ranking équipes (distance + charge)
- Affectation manuelle / suggestion BEST
- Navigation desktop + mobile

### GPS terrain
- Composant `GpsValidatePanel` + `GpsBadge`
- Validation position sur édition de point
- Champs `gpsValidatedAt`, `gpsSource`, `gpsAccuracyM`
- `getPosition()` compatible Capacitor

## Fichiers principaux touchés / ajoutés
- `src/lib/collecte/config.ts`, `store.ts`, `dispatch.ts`, `geo.ts`
- `src/components/collecte/dispatch-page.tsx`, `gps-validation.tsx`, `shell.tsx`, `points-page.tsx`, `incidents-page.tsx`
- `src/routes/dispatch.tsx`, `src/routeTree.gen.ts`
- `capacitor.config.ts`, `package.json`, `.github/workflows/android-apk.yml`
