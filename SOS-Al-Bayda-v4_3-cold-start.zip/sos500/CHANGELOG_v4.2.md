# SOS AL BAYDA v4.2 — Offline queue renforcée

Base : v4.1 Offline-queue + améliorations terrain.

## Nouveautés v4.2

### Indicateur de synchronisation
- Bandeau `SyncStatusBar` sous le header
- Affiche le nombre d'éléments en attente (constats / points / photos)
- Bouton **Synchroniser** (force le flush même si l'événement `online` a été manqué)

### Retry périodique
- Flush automatique toutes les **45 secondes** si `navigator.onLine` et file non vide
- Flush aussi au retour d'onglet (`visibilitychange`)

### Upload photo séparé
- Les mutations `incident` ne portent plus la data-URL photo
- Nouvelle entrée de file `kind: "photo"` (photoId IndexedDB → serveur)
- Évite de bloquer / alourdir la sync des métadonnées de constats

### API file
- `getPendingCount()` / `getOutboxSnapshot()`
- `flushPendingMutations({ force?: boolean })` retourne `{ flushed, remaining }`
- Compteur d'attempts par mutation

## Limites toujours valables
- APK en mode `server.url` : pas d'ouverture offline au cold start
- Conflits multi-appareils non versionnés
- File limitée aux points, constats et photos de constats

## Fichiers touchés
- `src/lib/collecte/store.ts`
- `src/components/collecte/sync-status.tsx` (nouveau)
- `src/components/collecte/shell.tsx`

## Photo d'anomalie (complément)

- **Création** : formulaire Nouveau constat → « Prendre / choisir une photo »
- **Sur constat existant** : bouton **Ajouter photo** / **Remplacer photo** dans l'historique
- Dialogue photo : affichage + remplacement possible
- Store : `attachIncidentPhoto(id, dataUrl)` → IndexedDB + file offline (`kind: "photo"`)
- Mention terrain pour chef de secteur / chef d'équipe dans l'encadré d'aide

## Compression images optimisée
- Orientation EXIF (iPhone/Android) corrigée avant JPEG
- Redimensionnement côté max 1280 px
- Qualité adaptative jusqu'à ~280 Ko (min qualité 0.45)
- Second passage : réduction de résolution si toujours trop lourd
- API : `compressAnomalyPhoto()` + `compressImageDetailed()` + taille affichée en aperçu
