# SOS AL BAYDA — Guide Android APK (v4.3-cold)

## Contenu
- Configuration Capacitor (`capacitor.config.ts`) : GPS, caméra, notifications, Network, Splash allongé.
- Identifiant : `ma.sosalbayda.mobile` — nom : `SOS AL BAYDA`.
- Workflow GitHub Actions pour APK debug.
- Service Worker optimisé cold-start (`public/sw.js` v4.3-cold).

## Mode actuel : shell distant (`server.url`)

L'APK est une **enveloppe Capacitor** qui charge la PWA hébergée en HTTPS.

| Situation | Comportement |
|-----------|--------------|
| 1ère ouverture (téléphone neuf) | **Réseau obligatoire** (chargement distant + enregistrement SW) |
| Ouvertures suivantes, hors ligne | **OK** — SW sert pages + assets depuis le cache |
| Données app effacées | Repart comme une 1ère ouverture |
| Retour réseau | Outbox flush automatique + refresh |

## Cold-start optimisé (v4.3-cold)

1. **Service Worker** : cache des 7 routes + assets ; timeout réseau 3,5 s ; page de secours brandée.
2. **Enregistrement SW accéléré** : push des URLs à 0,8 s puis 5 s (chunks lazy inclus).
3. **Splash 2,2 s** : laisse le temps au 1er paint sur 4G lente.
4. **Capacitor Network** : détection online/offline plus fiable que `navigator.onLine` sur Android.
5. **`navigator.storage.persist()`** : réduit le risque de purge IndexedDB/cache par le système.

### Procédure terrain (agents)

1. Installer l'APK.
2. **Ouvrir une fois au dépôt / avec 4G** (30–60 s suffisent).
3. Vérifier que le bandeau de sync n'affiche plus d'erreur réseau.
4. Ensuite : usage hors ligne normal (constats, photos, GPS). La sync partira au retour réseau.

## Générer l'APK

1. Déployer l'app web sur une URL HTTPS publique.
2. Variable GitHub `SOS_APP_URL` = URL HTTPS (sans slash final).
3. Actions → `Android APK (debug)` → Run workflow.
4. Installer `app-debug.apk`.

### Local
```bash
npm install
export SOS_APP_URL="https://votre-url"
npx cap sync android
npx cap open android
# ou : npm run android:build
```

## Permissions (AndroidManifest)
- ACCESS_FINE_LOCATION / ACCESS_COARSE_LOCATION
- CAMERA / READ_MEDIA_IMAGES
- POST_NOTIFICATIONS
- INTERNET / ACCESS_NETWORK_STATE

## Roadmap : cold-start offline dès l'install (mode embarqué)

Pour un téléphone qui n'a **jamais** de réseau à la 1ère ouverture :

1. Produire un build client statique dans `www/` (HTML/JS/CSS de l'app).
2. Retirer le bloc `server: { url: appUrl }` de `capacitor.config.ts`.
3. Pointer les `createServerFn` / API vers l'URL HTTPS absolue du backend (uniquement quand online).
4. Garder l'outbox + IndexedDB inchangés.

Ce mode impose de republier l'APK à chaque release UI majeure, mais garantit l'ouverture hors ligne dès l'installation.

## Limites connues
- Mode `server.url` : pas d'UI native si le WebView n'a jamais chargé l'origine distante.
- Polices Google externes : peuvent manquer hors ligne (texte système en fallback). Self-host recommandé en v5.
