alter table incidents add column if not exists due_at text;
alter table incidents add column if not exists assigned_team_id text;
create index if not exists incidents_status_due_idx on incidents (status, due_at);
