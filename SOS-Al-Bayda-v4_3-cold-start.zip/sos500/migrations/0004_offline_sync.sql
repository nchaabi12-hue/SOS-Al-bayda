-- v4.3 : le serveur stocke enfin ce que l'écran affiche.
-- Points : validation GPS terrain + horodatage client (anti-écrasement par une donnée plus ancienne).
alter table points add column if not exists gps_validated_at text;
alter table points add column if not exists gps_source text;
alter table points add column if not exists gps_accuracy_m double precision;
alter table points add column if not exists client_updated_at text;

-- Constats : priorité, SLA, agent, base d'affectation, GPS validé, clôture, historique.
alter table incidents add column if not exists priority integer;
alter table incidents add column if not exists sla_minutes integer;
alter table incidents add column if not exists assigned_agent_id text;
alter table incidents add column if not exists assigned_agent_name text;
alter table incidents add column if not exists assignment_basis text;
alter table incidents add column if not exists validated_gps boolean not null default false;
alter table incidents add column if not exists closed_at text;
alter table incidents add column if not exists closed_by text;
alter table incidents add column if not exists history text not null default '[]';
alter table incidents add column if not exists client_updated_at text;
