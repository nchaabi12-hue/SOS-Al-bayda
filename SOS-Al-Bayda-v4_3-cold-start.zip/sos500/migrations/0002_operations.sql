create table if not exists members (
  user_id text primary key,
  role text not null,
  display_name text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists app_meta (
  key text primary key,
  value text not null
);

create table if not exists sectors (
  id text primary key,
  name text not null,
  grp text not null,
  lat double precision not null,
  lng double precision not null
);

create table if not exists depot (
  id integer primary key,
  name text not null,
  lat double precision not null,
  lng double precision not null
);

create table if not exists teams (
  id text primary key,
  name text not null,
  sector text not null,
  chief text not null default '',
  created_by text not null
);

create table if not exists vehicles (
  id text primary key,
  plate text not null,
  kind text not null,
  team_id text not null default '',
  created_by text not null
);

create table if not exists sweepers (
  id text primary key,
  name text not null,
  sector text not null,
  team_id text not null default '',
  created_by text not null
);

create table if not exists points (
  id text primary key,
  name text not null,
  sector text not null,
  address text not null default '',
  lat double precision not null,
  lng double precision not null,
  status text not null,
  fill_level integer not null default 0,
  priority_level integer not null default 1,
  in_today boolean not null default true
);

create table if not exists circuits (
  id text primary key,
  name text not null,
  sector text not null,
  team_id text not null default '',
  vehicle_id text not null default '',
  service_date text not null,
  point_ids text not null,
  km double precision not null default 0,
  road_km double precision,
  minutes integer not null default 0,
  geometry text not null default '[]',
  created_by text not null
);

create table if not exists incidents (
  id text primary key,
  created_at text not null,
  sector text not null,
  type text not null,
  description text not null,
  lat double precision,
  lng double precision,
  status text not null,
  photo text not null default '',
  author_id text not null
);

create table if not exists operations (
  id text primary key,
  kind text not null,
  sector text not null,
  team_id text not null default '',
  sweeper_id text not null default '',
  street text not null,
  started_at text not null,
  ended_at text not null default '',
  status text not null,
  note text not null default '',
  author_id text not null
);

create table if not exists savings (
  id text primary key,
  service_date text not null,
  sector text not null,
  km double precision not null,
  points integer not null default 0,
  author_id text not null
);

create index if not exists points_sector_idx on points (sector);
create index if not exists circuits_date_idx on circuits (service_date);
create index if not exists operations_status_idx on operations (status);
