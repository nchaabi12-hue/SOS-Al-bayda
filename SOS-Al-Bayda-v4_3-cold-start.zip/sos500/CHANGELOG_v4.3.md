# SOS AL BAYDA v4.3 — Offline-sync (corrections robustesse)

Base : v4.2 Offline queue renforcée.

## Corrections v4.3 (expert review)

### Photo offline
- **Avant** : si la photo locale (IndexedDB / dataUrl) avait disparu au moment du flush, la mutation était retirée en silence (« succès »). Risque de perte sans feedback terrain.
- **Après** : absence de photo → erreur permanente (« Photo locale introuvable — re-prendre la photo sur le terrain »), visible dans le bandeau des refus, l’opérateur peut ré-attacher la photo.

### Indicateur de sync
- Détail de file complet : constats, points, suppressions, photos **et économies**.
- Les kinds `pointDelete` et `saving` n’étaient pas affichés.

### Typage
- `dataUrl?: string` documenté sur `OutboxItem` (fallback photo quand IndexedDB indisponible).

### Regex refus définitifs
- Ajout des messages photo manquante / invalide pour qu’ils aillent bien dans la liste « refusées » (pas de retry infini).

## Fichiers touchés
- `src/lib/collecte/store.ts`
- `src/lib/collecte/outbox.ts`
- `src/components/collecte/sync-status.tsx`

## Tests
- 33/33 unitaires (outbox, conflict, kv) toujours verts.
