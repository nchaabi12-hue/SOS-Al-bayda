# SOS AL BAYDA v4.3-cold — Cold-start Capacitor optimisé

Base : v4.3 Offline-sync (corrections photo + sync bar).

## Objectif
Améliorer l'ouverture hors ligne de l'APK **après la première connexion**, et rendre le comportement terrain prévisible.

## Changements

### Service Worker (`public/sw.js`)
- Version cache `sos-albayda-v4.3-cold`
- Timeout navigation 3,5 s (réseau lent terrain)
- Page de secours brandée `/__offline` si aucune route en cache
- Revalidation assets en arrière-plan (stale-while-revalidate)
- Cache des routes métier + `__grok/` + brand

### Shell (`shell.tsx`)
- Enregistrement SW scope `/`
- Push des assets à **0,8 s** puis **5 s** (lazy chunks)
- Intégration **Capacitor Network** (listener + getStatus)
- `storage.persist()` conservé

### Capacitor
- Splash **2,2 s**, fullScreen / immersive
- Plugins Network + App déclarés
- Commentaires mode embarqué (roadmap)

### www/index.html
- Shell local brandé (utile si un jour `server.url` est retiré)

### Doc
- `GUIDE_ANDROID_SOS_AL_BAYDA.md` réécrit avec tableau de comportements + procédure agents

## Ce qui ne change pas
- Architecture `server.url` (mises à jour sans republier l'APK)
- 1ère ouverture sur téléphone neuf : réseau toujours requis
- Outbox / IndexedDB / résolution de conflits

## Fichiers touchés
- `public/sw.js`
- `src/components/collecte/shell.tsx`
- `capacitor.config.ts`
- `www/index.html`
- `GUIDE_ANDROID_SOS_AL_BAYDA.md`
- `CHANGELOG_v4.3-cold.md`
